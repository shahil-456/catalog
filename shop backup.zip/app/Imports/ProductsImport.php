<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Contracts\Queue\ShouldQueue;
use Maatwebsite\Excel\Concerns\WithChunkReading;

class ProductsImport implements ToModel, WithHeadingRow,WithChunkReading,ShouldQueue
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
   public function model(array $row)
    {
        return new Product([
            'name'        => $row['name'],
            'description' => $row['description'],
            'price'       => $row['price'],
            'stock'       => $row['stock'],
            'category_id' => $row['category_id'],
            'image' => !empty($row['image']) ? $row['image'] : 'default.png',
            'added_by' => 1,
            'type' => 'test',
   

        ]);

        
    }

     public function chunkSize(): int
        {
            return 1000; 
        }
}





