<?php

// namespace App\Models;




namespace App\Models;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'uid',
        'username',
        'email',
        'phone',
        'first_name',
        'last_name',
        'gender',
        'profile_photo',
        'password',
        'transaction_password',
        'placement_id',
        'sponsor_id',
        'package_id',
        'rank_id',
        'user_type',
        'position',
        'vacant',
        'status',
        'active',
        'block_status',
        'blocked_at',
        'twofa_enabled',
        'google_2fa_secret',
        'commission_balance',
        'registration_fee',
        'language',
        'country_id',
        'state_id',
        'city',
        'address',
        'total_referrals',
        'dashboard_theme',
        'popup_seen',
        'payment_proof_url',
        'qr_code_url',
        'ip_address',
    ];

    protected $hidden = [
        'password',
        'transaction_password',
        'google_2fa_secret',
        'password_reset_token',
    ];

    protected $casts = [
        'vacant' => 'boolean',
        'active' => 'boolean',
        'status' => 'boolean',
        'block_status' => 'boolean',
        'twofa_enabled' => 'boolean',
        'popup_seen' => 'boolean',
        'invested_amount' => 'decimal:2',
        'commission_balance' => 'decimal:2',
        'active_balance' => 'decimal:2',
        'balance_amount' => 'decimal:2',
        'registration_fee' => 'decimal:2',
        'blocked_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function package()
    {
        return $this->belongsTo(Package::class);
    }

    public function rank()
    {
        return $this->belongsTo(Rank::class);
    }

    public function referrals()
    {
        return $this->hasMany(User::class, 'sponsor_id');
    }

    public function sponsor()
    {
        return $this->belongsTo(User::class, 'sponsor_id');
    }

    public function placements()
    {
        return $this->belongsTo(User::class, 'placement_id');
    }

     public function packagePurchases()
    {
        return $this->hasMany(PackagePurchaseHistory::class,'user_id');
    }

    public function packageUpgrades()
    {
        return $this->hasMany(PackageUpgradeHistory::class,'user_id');
    }

     public function country()
    {
        return $this->belongsTo(Country::class,'country_id');
    }

    public function state()
    {
        return $this->belongsTo(State::class,'state_id');
    }

     public function language()
    {
        return $this->belongsTo(Language::class,'language_id');
    }

     public function wallets()
    {
        return $this->hasMany(UserWallet::class,'user_id');
    }

    public function earnings()
    {
        return $this->hasMany(Earning::class,'user_id');
    }

     public function invests()
    {
        return $this->hasMany(Investment::class,'user_id');
    }

      public function notifies()
    {
        return $this->hasMany(Notification::class,'user_id');
    }

    public function carts()
    {
        return $this->hasMany(Cart::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

     public function transfers()
    {
        return $this->hasMany(Transfer::class);
    }

    public function wishLists()
    {
        return $this->hasMany(WishList::class);
    }

    public function withdraws()
    {
        return $this->hasMany(Withdrawal::class);
    }

    public function productPurchases()
    {
        return $this->hasMany(ProductPurchaseHistory::class);
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }




    // public function orders()
    // {
    //     return $this->hasMany(Order::class);
    // }


    





}

