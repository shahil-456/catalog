<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    protected $fillable = [
        'name',
        'name_ar',
        'type',
        'style',
    ];

    public $timestamps = false;


    public function leads()
    {
        return $this->hasMany(Lead::class, 'status');
    }

    public function history()
    {
        return $this->hasMany(StatusHistory::class, 'status_id');
    }

}
