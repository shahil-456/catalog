<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;

class Admin extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'first_tname',
        'last_name',
        'about',
        'email',
        'password',
        'password_reset_token',
        'image',
        'last_login',
        'last_logout',
        'ip_address',
        'status',
        'is_admin',
    ];

    protected $hidden = [
        'password',
        'password_reset_token',
    ];

    protected $casts = [
        'status' => 'boolean',
        'is_admin' => 'boolean',
        'last_login' => 'datetime',
        'last_logout' => 'datetime',
    ];

      public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }
}
