<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Widget;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;

class WidgetController extends Controller
{
    public function getWidgets(Request $request)
    {
        $page = $request->input('page');
        $page_id = $request->input('page_id');
        $widgets = Widget::where(['page' => $page, 'page_id' => $page_id])->whereNull('deleted_at')
            ->orderBy('created_at', 'desc')->get();
        return response()->json([
            'data' => $widgets,
            "message" => "Widgets successfully retrieved."
        ], 200);
    }
    public function getWidgetById($id)
    {
        try {
            $widget = Widget::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'message' => 'Widget Not Found',
            ], 404);
        }
        return response()->json([
            'data' => [
                'widget' =>  $widget,
            ],
            'message' => 'Widget Data Retrieved Successfully!'
        ], 200);
    }
    public function createWidget(Request $request)
    {
        try {
            $request->validate([
                'title' => 'required',
                'description' => 'required',
            ]);

            $page = $request->input('page');
            $page_id = $request->input('page_id');

            $widget = Widget::create([
                'title' => $request->input('title'),
                'description' => $request->input('description'),
                'page' => $page,
                'page_id' => $page_id,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Widget Data Added Successfully!',
                'data' => $widget
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error inserting Widget: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the Widget. Please try again later.',
            ], 500);
        }
    }
    public function updateWidget(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|exists:widgets,id',
                'title' => 'required',
                'description' => 'required',
            ]);

            $widget = Widget::findOrFail($request->input('id'));

            $widget->update([
                'title' => $request->input('title'),
                'description' => $request->input('description'),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Widget Data Updated Successfully!',
                'data' => $widget
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Widget Not Found',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error updating Widget: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the Widget. Please try again later.',
            ], 500);
        }
    }
    public function delete(Request $request, $id)
    {

        try {
            $widget = Widget::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Widget id not found',
            ], 404);
        }
        $widget->delete();
        return response()->json([
            'success' => true,
            'message' => 'Widget Data Deleted Successfully!',
        ], 200);
    }
}
