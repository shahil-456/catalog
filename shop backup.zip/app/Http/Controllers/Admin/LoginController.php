<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;


class LoginController extends Controller
{
    public function index()
    {
        return view('admin.auth.login');
    }


   public function login(Request $request)
{
    try {
        $validated = Validator::make($request->all(), [
            'email'    => 'required|email|exists:admins,email',
            'password' => 'required|min:6',
        ]);

        if ($validated->fails()) {
            return response()->json([
                'success' => false,
                'errors'  => $validated->errors(),
            ], 422);
        }

        $credentials = $validated->validated();

        if (Auth::guard('admin')->attempt($credentials)) {
            return response()->json([
                'success' => true,
                'redirect' => route('admin.users'),
            ]);
        }

        return response()->json([
            'success' => false,
            'login_error' => 'The provided credentials do not match our records.',
        ], 401);

    } catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'success' => false,
            'errors'  => $e->errors(),
        ], 422);
    } catch (\Exception $e) {
        \Log::error('Admin login error: ', ['exception' => $e]);
        return response()->json([
            'success' => false,
            'login_error' => 'Something went wrong. Please try again later.',
        ], 500);
    }
}



    public function logout()
    {
        Auth::guard('admin')->logout();
        return redirect()->route('admin.login');
    }

    

   
}
