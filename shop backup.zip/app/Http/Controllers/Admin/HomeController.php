<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Cviebrock\EloquentSluggable\Services\SlugService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{

    public function index(Request $request)
    {
       
        return view('admin.layouts.app');

    }

    public function addBlog()
    {
        $blogCategories = BlogCategory::whereNull('deleted_at')
            ->select('name', 'id')
            ->get();
        return view('admin.blogs.add', compact('blogCategories'));
    }
    public function createBlog(Request $request)
    {
        try {
            $request->validate([
                'title' => 'required|max:200',
                'category_id' => 'required|numeric'
            ]);
            $variable = ($request->input('slug')) ? $request->input('slug') : $request->input('title');
            $slug = SlugService::createSlug(Blog::class, 'slug', $variable);
            $imageName = '';
            if ($request->file('image')) {
                $image = $request->file('image');
                $imageName = time() . '_' . str_replace(' ', '', $image->getClientOriginalName());
                $image->storeAs('public/images/blogs/', $imageName);
            }

            $blog = Blog::create([
                'title' => $request->input('title'),
                'title_ar' => $request->input('title_ar'),
                'description' => $request->input('description'),
                'description_ar' => $request->input('description_ar'),
                'author' => $request->input('author') ? $request->input('author') : 'Whatsap.io',
                'image' => $imageName,
                'category_id' => $request->input('category_id'),
                'sort_order' => $request->input('sort_order') ? $request->input('sort_order') : 1,
                'slug' => $slug, // Adding the generated slug
            ]);
            return response()->json(['success' => true, 'message' => 'Blog added successfully']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error inserting blog: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the blog. Please try again later.',
            ], 500);
        }
    }
    public function editBlog($id)
    {
        $seo = Seo::with(['language'])->where(['entity_type' => 'Blogs', 'page_id' => $id])->get();
        $blogCategories = BlogCategory::whereNull('deleted_at')
            ->select('name', 'id')
            ->get();
        $languages = Language::select('name', 'id')
            ->get();
        $blog = Blog::findOrFail($id);
        return view('admin.blogs.edit', compact('blog', 'blogCategories', 'languages', 'seo'));
    }
    public function updateBlog(Request $request, $id)
    {
        $blog = Blog::findOrFail($id);
        try {
            $request->validate([
                'title' => 'required|max:200',
            ]);
            $existingSlug = $blog->slug;
            $inputSlug = $request->input('slug');

            if (($inputSlug && $inputSlug !== $existingSlug) || (empty($inputSlug) && $blog->name !== $request->input('name'))) {
                if (empty($inputSlug)) {
                    $inputSlug = $request->input('name');
                }
                $slug = SlugService::createSlug(Blog::class, 'slug', $inputSlug);
            } else {
                $slug = $existingSlug;
            }

            $imageName = $blog->image;
            if ($request->file('image')) {
                $image = $request->file('image');
                $imageName = time() . '_' . str_replace(' ', '', $image->getClientOriginalName());
                $image->storeAs('public/images/blogs/', $imageName);
                // Delete previous image if exists
                if ($blog->image) {
                    Storage::delete('public/images/blogs/' . $blog->image);
                }
            }


            $blog->update([
                'title' => $request->input('title'),
                'title_ar' => $request->input('title_ar'),
                'description' => $request->input('description'),
                'description_ar' => $request->input('description_ar'),
                'author' => $request->input('author') ? $request->input('author') : 'Whatsap.io',
                'category_id' => $request->input('category_id'),
                'image' => $imageName,
                'sort_order' => $request->input('sort_order') ? $request->input('sort_order') : 1,
                'slug' => $slug, // Adding the generated slu
            ]);
            return response()->json([
                'success' => true,
                'message' => 'Feature updated successfully.'
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Seo not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error updating seo: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the seo. Please try again later.',
            ], 500);
        }
    }

    public function toggleStatus(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|exists:blogs,id',
                'status' => 'required|boolean',
            ]);

            $blog = Blog::findOrFail($request->id);
            $blog->is_active = $request->status;
            $blog->save();

            return response()->json([
                'success' => true,
                'message' => 'Blog status updated successfully.'
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Blog not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error toggling blog status: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the blog status. Please try again later.',
            ], 500);
        }
    }

    public function deleteBlog($id)
    {
        try {
            if (Blog::findOrFail($id)->delete()) {
                Seo::deleteAssociatedSeo("Blogs", $id);
                return response()->json([
                    'success' => true,
                    'message' => 'Blog deleted successfully!',
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Blog could not be deleted. Please try again later.',
                ], 500);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Blog not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error deleting Blog: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred. Please try again later.',
            ], 500);
        }
    }
}
