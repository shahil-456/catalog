<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $query = Customer::query();
        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('first_name', 'LIKE', "%{$searchTerm}%")
                ->orWhere('last_name', 'LIKE', "%{$searchTerm}%")
                ->orWhere('email', 'LIKE', "%{$searchTerm}%")
                ->orWhere('mobile', 'LIKE', "%{$searchTerm}%");
        }
        $customers = $query->paginate(10);
        if ($request->ajax()) {
            return view('admin.customers.list', compact('customers'))->render();
        }
        return view('admin.customers.index', compact('customers'));
    }
    public function create()
    {
        return view('admin.customers.add');
    }

    public function store(Request $request)
    {
        try {
            $validated = Validator::make($request->all(), [
                'firstname'     => 'required|string|max:100|min:3',
                'lastname'      => 'required|nullable|string|max:100|min:3',
                'email'         => 'required|email|max:200|unique:customers,email',
                'mobile'         => 'required|integer|min:10000000|max:1000000000000000|unique:customers,mobile',
            ]);

            if ($validated->fails()) {
                return response()->json([
                    'errors' => $validated->errors(),
                ], 422);
            } else {

                $customer = Customer::create([
                    'first_name'      => $request->input('firstname'),
                    'last_name'       => $request->input('lastname'),
                    'email'          => $request->input('email'),
                    'mobile'         => $request->input('mobile'),
                    'created_by' => auth()->id(),
                ]);
                return response()->json(['success' => true, 'message' => 'Customer added successfully', 'customer' => $customer]);
            }
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error Adding Lead: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the customer. Please try again later.',
            ], 500);
        }
    }
    public function getCustomers(Request $request)
    {
        $search = $request->search;
        return Customer::when($search, function ($query) use ($search) {
            $query->where('first_name', 'LIKE', "%{$search}%")
                ->orWhere('last_name', 'LIKE', "%{$search}%")
                ->orWhere('email', 'LIKE', "%{$search}%")
                ->orWhere('mobile', 'LIKE', "%{$search}%");
        })->select('id', 'first_name', 'last_name')->get();
    }
    public function edit($id)
    {
        $customer = Customer::findOrFail($id);
        return view('admin.customers.edit', compact('customer'));
    }

    public function update(Request $request, $id)
    {
        try {
            $customer = Customer::findOrFail($id);
            $validated = Validator::make($request->all(), [
                'firstname'     => 'required|string|max:100',
                'lastname'      => 'required|nullable|string|max:100',
                'email'         => 'required|email|max:200|unique:customers,email,' . $request->id,
                'mobile'        => 'required|integer|max:1000000000000000000|unique:customers,mobile,' . $request->id,
            ]);

            if ($validated->fails()) {
                return response()->json([
                    'errors' => $validated->errors(),
                ], 422);
            }

            $customer->update([
                'first_name'     => $request->input('firstname'),
                'last_name'      => $request->input('lastname'),
                'email'         => $request->input('email'),
                'mobile'        => $request->input('mobile'),
                'updated_at'    => now(),
            ]);
            return response()->json(['success' => true, 'message' => 'Customer Updated successfully']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error Adding Lead: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the customer. Please try again later.',
            ], 500);
        }
    }


    public function destroy($id)
    {
        try {
            if (Customer::findOrFail($id)->delete()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Customer deleted successfully!',
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Customer could not be deleted. Please try again later.',
                ], 500);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Customer not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error deleting Laed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred. Please try again later.',
            ], 500);
        }
    }
}
