<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Enquiry;
use App\Models\StatusHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\ContactEnquiry;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendEnquiryMail;





class EnquiryController extends Controller
{

    public function index(Request $request)
    {
        Enquiry::all();
    }

    public function store(Request $request)
    {

        $latestEnquiry = Enquiry::latest()->first();
        $currentId = $latestEnquiry ? $latestEnquiry->id + 1 : 1;
        $enquiryId = 'JR:' . str_pad($currentId, 5, '0', STR_PAD_LEFT);

        try {
            $request->validate([
                'first_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'mobile' => 'required|string|max:20',
                'model' => 'required|string|max:100',
                'message' => 'nullable|string',
                'issue' => 'required|string',
                'category_id' => 'required|integer|exists:categories,id',
                'brand_id' => 'required',
            ]);

            $customer = Customer::firstOrCreate(
                ['email' => $request->input('email')],
                [
                    'first_name' => $request->input('first_name'),
                    'last_name' => $request->input('last_name'),
                    'mobile' => $request->input('mobile'),
                    'created_by' => 1,
                ]
            );

            $enquiry = Enquiry::create([
                'enquiry_id' => $enquiryId,
                'customer_id' => $customer->id,
                'model' => $request->input('model'),
                'issue' => $request->input('issue'),
                'message' => $request->input('message'),
                'category_id' => $request->input('category_id'),
                'brand_id' => $request->input('brand_id'),
                'status_id' => 1, // Default status
            ]);

            // Create initial status history
            StatusHistory::create([
                'enquiry_id' => $enquiry->id,
                'status_id' => 1, // Default status
                'comment' => 'Enquiry created',
                'updated_by' => 1,
                'status' => 1,
            ]);

            Mail::to(env('MAIL_CC_ADDRESS'))->queue(new SendEnquiryMail($enquiry, 'Enquiry Mail'));

            return response()->json([
                'success' => true,
                'message' => 'Enquiry added successfully',
                'data' => $enquiry->enquiry_id
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error inserting Enquiry: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the Enquiry. Please try again later.',
            ], 500);
        }
    }

     public function storeContactEnquiry(Request $request)
    {

        try {
            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'phone' => 'required|string|max:20',
                // 'company' => 'required|string|max:100',
                'message' => 'required|nullable|string',
            ]);

            $enquiry = ContactEnquiry::create([
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'message' => $request->input('message'),
                'company' => $request->input('company'),
                'phone' => $request->input('phone'),
            ]);

            Mail::to(env('MAIL_CC_ADDRESS'))->queue(new SendEnquiryMail($enquiry, 'Contact Enquiry Mail'));

            return response()->json([
                'success' => true,
                'message' => 'Contact Enquiry added successfully',
                'data' => ''
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error inserting Enquiry: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the Enquiry. Please try again later.',
            ], 500);
        }
    }
}
