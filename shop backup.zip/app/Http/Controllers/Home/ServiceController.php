<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\BrandCategory;
use App\Models\Category;
use App\Models\Faq;
use App\Models\Seo;
use App\Models\Widget;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ServiceController extends Controller
{

    public function service(Request $request)
    {
        try {
            $categories = Category::all();
            $brands = Brand::with('categories')->get();
            $seo = Seo::where('entity_type', 'ServicePage')->first();
            $faqs = Faq::where('page', 'ServicePage')->get();
            $widget = Widget::where('page', 'ServicePage')->first();
            return view('home.services', compact('categories', 'brands', 'faqs', 'seo', 'widget'));
        } catch (\Exception $e) {
            Log::error('Service page error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again later.');
        }
    }
    public function categoryService(Request $request, $categorySlug)
    {
        try {
            $category = Category::where(['slug' => $categorySlug])->firstOrFail();
            $categories = Category::all();
            $brands = Brand::with('categories')->get();
            $seo = Seo::where('entity_type', 'Categories')
                ->where('page_url', $categorySlug)->first();
            $faqs = Faq::where(['page_id' => $category->id, 'page' => 'Categories'])->get();
            $widget = Widget::where(['page_id' => $category->id, 'page' => 'Categories'])->first();
            return view('home.services', compact('categories', 'brands', 'category', 'faqs', 'seo', 'widget', 'categorySlug'));
        } catch (\Exception $e) {
            Log::error('Category service error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Category not found or something went wrong.');
        }
    }

    public function categoryBrandService(Request $request, $categorySlug, $brandSlug)
    {
        try {
            $category = Category::where(['slug' => $categorySlug])->firstOrFail();
            $brand = Brand::where(['slug' => $brandSlug])->firstOrFail();
            $brandCategpry = BrandCategory::where(['brand_id' => $brand->id, 'category_id' => $category->id])->firstOrFail();
            $categories = Category::all();
            $brands = Brand::with('categories')->get();
            $seo = Seo::where('entity_type', 'BrandCategories')
                ->where('page_url', $categorySlug . '/' . $brandSlug)->first();
            $faqs = Faq::where(['page_id' => $brandCategpry->id, 'page' => 'BrandCategories'])->get();
            $widget = Widget::where(['page_id' => $brandCategpry->id, 'page' => 'BrandCategories'])->first();
            return view('home.services', compact('categories', 'brands', 'category', 'brand', 'faqs', 'categorySlug', 'brandSlug', 'widget'));
        } catch (\Exception $e) {
            Log::error('Category-Brand service error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Brand or Category not found, or an error occurred.');
        }
    }
}
