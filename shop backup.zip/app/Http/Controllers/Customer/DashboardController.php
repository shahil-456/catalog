<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Pusher\Pusher;
use App\Models\Notification;
use Illuminate\Support\Facades\Log;


class DashboardController extends Controller
{
    public function index()
    {
        return view('admin.dashboard');
    }

    public function authenticate(Request $request)
    {
        $request->validate([
            'channel_name' => 'required|string',
            'socket_id'    => 'required|string',
        ]);

        try {
            $pusher = new Pusher(
                config('broadcasting.connections.pusher.key'),
                config('broadcasting.connections.pusher.secret'),
                config('broadcasting.connections.pusher.app_id'),
                [
                    'cluster' => config('broadcasting.connections.pusher.options.cluster'),
                    'useTLS'  => false,
                ]
            );

            return $pusher->authorizeChannel($request->input('channel_name'), $request->input('socket_id'));
        } catch (\Exception $e) {
            Log::error("Pusher authentication error: " . $e->getMessage());
            return response()->json(['error' => 'Unauthorized'], 403);
        }
    }

    public function notifications(Request $request)
    {
        Notification::where('to', auth()->id())->update(['status' => 0]);
        $notifications = Notification::where('to', auth()->id())
            ->orderBy('id', 'desc')
            ->paginate(10);
        return view('notifications.index', compact('notifications'))->render();
    }
    public function test(Request $request)
    {
        return view('customer.emails.test');

    }
}
