<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Language;
use App\Models\Seo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use App\Models\Brand;
use App\Models\BrandCategory;
use App\Models\Faq;
use App\Models\Widget;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        $query = Category::query();
        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('name', 'LIKE', "%{$searchTerm}%");
        }
        $categories = $query->paginate(10);
        if ($request->ajax()) {
            return view('admin.categories.list', compact('categories'))->render();
        }
        return view('admin.categories.index', compact('categories'));
    }
    public function addCategory()
    {
        $brands = Brand::all();
        return view('admin.categories.add', compact('brands'));
    }
    public function createCategory(Request $request)
    {
        try {
            $request->validate([
                'name' => 'required|unique:categories,name',
                'name_ar' => 'nullable|string|max:255',
                'description' => 'nullable|string',
                'description_ar' => 'nullable|string',
                'short_description' => 'nullable|string|max:255',
                'short_description_ar' => 'nullable|string|max:255',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'is_featured' => 'nullable|boolean',
            ]);

            $imageName = null;
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->storeAs('public/images/categories', $imageName);
            }

            $category = Category::create([
                'name' => $request->input('name'),
                'name_ar' => $request->input('name_ar'),
                'description' => $request->input('description'),
                'description_ar' => $request->input('description_ar'),
                'short_description' => $request->input('short_description'),
                'short_description_ar' => $request->input('short_description_ar'),
                'image' => $imageName,
                'is_featured' => $request->boolean('is_featured'),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Category added successfully',
                'data' => $category
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error inserting category: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while adding the category. Please try again later.',
            ], 500);
        }
    }
    public function editCategory($id)
    {
        $category = Category::findOrFail($id);
        $selectedBrands = $category->brands->pluck('id')->toArray();
        $brands = Brand::select('name', 'id')->get();
        $languages = Language::select('name', 'id')->get();
        $seo = Seo::with(['language'])->where(['entity_type' => 'Categories', 'page_id' => $id])->get();
        $faq = Faq::where(['page' => 'Categories', 'page_id' => $id])->whereNull('deleted_at')
            ->orderBy('created_at', 'desc')->get();
        $widget = Widget::where(['page' => 'Categories', 'page_id' => $id])->whereNull('deleted_at')
            ->orderBy('created_at', 'desc')->get();
        return view('admin.categories.edit', compact('category', 'languages', 'seo', 'faq', 'brands', 'selectedBrands', 'widget'));
    }
    public function updateCategory(Request $request, $id)
    {
        $category = Category::findOrFail($id);

        try {
            $request->validate([
                'name' => 'required|unique:categories,name,' . $category->id,
                'slug' => [
                    'nullable',
                    Rule::unique('categories', 'slug')->ignore($id),
                ],
                'name_ar' => 'nullable|string|max:255',
                'description' => 'nullable|string',
                'description_ar' => 'nullable|string',
                'short_description' => 'nullable|string|max:255',
                'short_description_ar' => 'nullable|string|max:255',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'is_featured' => 'nullable|boolean',
            ]);
            $data = [
                'name' => $request->input('name'),
                'slug' => $request->input('slug'),
                'name_ar' => $request->input('name_ar'),
                'description' => $request->input('description'),
                'description_ar' => $request->input('description_ar'),
                'short_description' => $request->input('short_description'),
                'short_description_ar' => $request->input('short_description_ar'),
                'is_featured' => $request->boolean('is_featured'),
            ];

            // Handle image upload if provided
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->storeAs('public/images/categories', $imageName);
                $data['image'] = $imageName;
            }

            $category->update($data);
            $category->brands()->sync($request->input('brands'));

            return response()->json([
                'success' => true,
                'message' => 'Category updated successfully.'
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors(),
            ], 422);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error updating category: ', ['exception' => $e]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the category. Please try again later.',
            ], 500);
        }
    }
    public function deleteCategory($id)
    {
        try {
            if (Category::findOrFail($id)->delete()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Category deleted successfully!',
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Category could not be deleted. Please try again later.',
                ], 500);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error deleting Category: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred. Please try again later.',
            ], 500);
        }
    }
}
