<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Category;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ProductsImport;


class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::query();
        $categories = Category::all();

        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('name', 'LIKE', "%{$searchTerm}%");
                
        }
        $products = $query->paginate(10);
        if ($request->ajax()) {
            return view('customer.products.list', compact('products'))->render();
        }
        return view('customer.products.index', compact('products','categories'));
    }

    public function search(Request $request)
        {
            $query = Product::query();

            if ($request->has('search') && !empty($request->search)) {
                $searchTerm = $request->search;
                $query->where('name', 'LIKE', "%{$searchTerm}%");
            }

            $products = $query->get(); 

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'products' => $products
                ]);
            }
        }



   

    public function profile()
    {
        return view('customer.products.profile');
    }
    

    public function show($id)
    {
        $product = Product::findOrFail($id);
        return view('customer.products.view', compact('product'));
    }



    
   
    public function shop(Request $request)
    {
        $query = Product::query();
        $categories = Category::all();


        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('name', 'LIKE', "%{$searchTerm}%");
                
        }
        $products = $query->paginate(12);
        if ($request->ajax()) {
            return view('customer.products.shopping', compact('products'))->render();
        }
        return view('customer.products.shopping', compact('products','categories'));
    }

    public function addCart(Request $request, $productId)
        {
            $product = Product::findOrFail($productId);

            $cart = Cart::updateOrCreate(
                [
                    'user_id'    => auth()->id(),
                    'product_id' => $product->id,
                ],
                [
                    'quantity'   => 1,
                ]
            );

        return redirect()->route('customer.cart');
        }

        public function cart(Request $request)
        {

            $carts = Cart::where('user_id', auth()->id())->get();
            return view('customer.products.cart', compact('carts'));

        }


        public function deleteCart($id)
    {
        // return 1;
        try {
            if (Cart::findOrFail($id)->delete()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Cart deleted successfully!',
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Cart could not be deleted. Please try again later.',
                ], 500);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Cart not found.',
            ], 404);
        } catch (\Exception $e) {
            Log::error('Error deleting Cart: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred. Please try again later.',
            ], 500);
        }
    }


    public function checkout(Request $request)
    {

        $carts = Cart::where('user_id', auth()->id())->get();
        return view('customer.products.checkout', compact('carts'));


    }

    public function order(Request $request)
    {
        $productIds = $request->input('product_id', []);
        $quantities = $request->input('quantity', []);

        foreach ($productIds as $index => $productId) {
            $quantity = $quantities[$index] ?? 1;

            $product = Product::find($productId);

            if ($product) {
                Order::create([
                    'user_id'        => auth()->id(),
                    'product_id'     => $productId,
                    'amount'         => $product->price,
                    'quantity'       => $quantity,
                    'total_amount'   => $product->price * $quantity,
                    'payment_option' => 'test',
                    'status'         => 'Pending',
                ]);

              $product->stock -= $quantity;
              $product->save();

                
            }
        }

        Cart::where('user_id', auth()->id())->delete();

        return redirect()->route('customer.orders')->with('success', 'Order placed successfully!');
    }


     


    public function myOrders(Request $request)
    {

        $orders = Order::where('user_id', auth()->id())->paginate(10);    
        return view('customer.products.orders', compact('orders'));
    }



  
}
