<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;


class LoginController extends Controller
{
    public function index()
    {
        return view('customer.auth.login');
    }

    public function login(Request $request)
    {
    try {
        $validated = Validator::make($request->all(), [
            'email'    => 'required|email|exists:users,email',
            'password' => 'required|min:6',
        ]);

        if ($validated->fails()) {
            return response()->json([
                'success' => false,
                'errors'  => $validated->errors(),
            ], 422);
        }

        $credentials = $validated->validated();

        if (Auth::guard('customer')->attempt($credentials)) {
            return response()->json([
                'success' => true,
                'redirect' => route('customer.shopping'),
            ]);
        }

        return response()->json([
            'success' => false,
            'login_error' => 'The provided credentials do not match our records.',
        ], 401);

    } catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'success' => false,
            'errors'  => $e->errors(),
        ], 422);
    } catch (\Exception $e) {
        \Log::error('Customer login error: ', ['exception' => $e]);
        return response()->json([
            'success' => false,
            'login_error' => 'Something went wrong. Please try again later.',
        ], 500);
    }
    }

    public function logout()
    {
        Auth::guard('admin')->logout();
        return redirect()->route('customer.login');
    }

    public function showForgotPasswordForm()
    {
        return view('customer.auth.passwords.email');
    }

    public function sendResetLink(Request $request)
    {

        $request->validate(['email' => 'required|email']);

        $status = Password::broker('customers')->sendResetLink(
            $request->only('email')
        );

        return $status === Password::RESET_LINK_SENT
            ? back()->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }

    public function showResetForm($token)
    {
        return view('customer.auth.passwords.reset', ['token' => $token]);
    }

    public function resetPassword(Request $request)
    {

        $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);

        $status = Password::broker('customers')->reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function (Customer $customer, $password) {
                $customer->password = Hash::make($password);
                $customer->save();
            }
        );

        return $status === Password::PASSWORD_RESET
            ? redirect()->route('customer.login')->with('status', __($status))
            : back()->withErrors(['email' => [__($status)]]);
    }
}
