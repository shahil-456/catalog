<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\Customer\DashboardController;
use App\Http\Controllers\Customer\LoginController;
use App\Http\Controllers\Customer\CustomerController;
use App\Http\Controllers\Customer\ProductController;
use App\Http\Controllers\Customer\CategoryController;


Route::get('/customer', function () {
    return 'Hello Customer!';
})->name('customer');




Route::get('forgot_password', [LoginController::class, 'showForgotPasswordForm'])->name('customer.forgot-password');
// Route::get('reset-password/{token}', [LoginController::class, 'showResetForm'])->name('customer.password.reset');
Route::post('reset_link', [LoginController::class, 'sendResetLink'])->name('customer.password.email');
Route::post('/password_update', [LoginController::class, 'resetPassword'])->name('customer.password.update');
Route::get('login', [LoginController::class, 'index'])->name('customer.login');

Route::post('login', [LoginController::class, 'login'])->name('customer.login.action');

Route::get('reset-password/{token}', [LoginController::class, 'showResetForm'])->name('password.reset');

Route::middleware('auth:customer')->group(function () {

    Route::get('products', [ProductController::class, 'search'])->name('customer.products');

    Route::get('view-product/{id}', [ProductController::class, 'show'])->name('customer.product.view');

    
    Route::get('shopping', [ProductController::class, 'shop'])->name('customer.shopping');

    Route::get('add-to-cart/{id}', [ProductController::class, 'addCart'])->name('customer.product.addCart');

    Route::get('cart', [ProductController::class, 'cart'])->name('customer.cart');
    Route::delete('delete-cart/{id}', [ProductController::class, 'deleteCart'])->name('customer.cart.delete');

    Route::get('checkout', [ProductController::class, 'checkout'])->name('customer.checkout');
    Route::post('order', [ProductController::class, 'order'])->name('customer.product.order');
    Route::get('my-orders', [ProductController::class, 'myOrders'])->name('customer.orders');


    Route::get('test-pusher', [DashboardController::class, 'test'])->name('customer.test');

 
    Route::post('/broadcasting/auth', [DashboardController::class, 'authenticate'])->name('authenticate');

    
    //Auth routes
    Route::post('logout', [LoginController::class, 'logout'])->name('customer.logout.action');
    Route::get('/', [DashboardController::class, 'index'])->name('customer.dashboard');

   


    Route::post('/set-theme', function (Request $request) {
        session(['theme' => $request->theme]);
    });
});
Route::get('/', function () {
    return 'This is the customer dashboard';
});