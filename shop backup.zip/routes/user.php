<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\User\DashboardController;
use App\Http\Controllers\User\LoginController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\User\RoleController;
use App\Http\Controllers\User\PermissionController;
use App\Http\Controllers\User\CustomerController;
use App\Http\Controllers\User\EnquiryController;
use App\Http\Controllers\User\CategoryController;
use App\Http\Controllers\User\BlogCategoryController;
use App\Http\Controllers\User\BrandController;
use App\Http\Controllers\User\BlogController;
use App\Http\Controllers\User\CmsController;
use App\Http\Controllers\User\FaqController;
use App\Http\Controllers\User\SeoController;
use App\Http\Controllers\User\WidgetController;
use App\Http\Controllers\User\ReportController;






Route::get('forgot_password', [LoginController::class, 'showForgotPasswordForm'])->name('user.forgot-password');
// Route::get('reset-password/{token}', [LoginController::class, 'showResetForm'])->name('user.password.reset');
Route::post('reset_link', [LoginController::class, 'sendResetLink'])->name('user.password.email');
Route::post('/password_update', [LoginController::class, 'resetPassword'])->name('user.password.update');
Route::get('login', [LoginController::class, 'index'])->name('user.login');

Route::post('login', [LoginController::class, 'login'])->name('user.login.action');

Route::get('reset-password/{token}', [LoginController::class, 'showResetForm'])->name('password.reset');

Route::middleware('auth:admin')->group(function () {

    Route::get('categories', [CategoryController::class, 'index'])->name('user.category.list')->middleware('can:list categories');
    Route::get('add_category', [CategoryController::class, 'addCategory'])->name('user.category.add')->middleware('can:add category');
    Route::post('create_category', [CategoryController::class, 'createCategory'])->name('user.category.create')->middleware('can:add category');
    Route::get('edit_category/{id}', [CategoryController::class, 'editCategory'])->name('user.category.edit')->middleware('can:edit category');
    Route::post('update_category/{id}', [CategoryController::class, 'updateCategory'])->name('user.category.update')->middleware('can:edit category');
    Route::delete('delete_category/{id}', [CategoryController::class, 'deleteCategory'])->name('user.category.delete')->middleware('can:delete category');

    Route::get('brands', [BrandController::class, 'index'])->name('user.brand.list')->middleware('can:list brands');
    Route::get('add_brand', [BrandController::class, 'addBrand'])->name('user.brand.add')->middleware('can:add brand');
    Route::post('create_brand', [BrandController::class, 'createBrand'])->name('user.brand.create')->middleware('can:add brand');
    Route::get('edit_brand/{id}', [BrandController::class, 'editBrand'])->name('user.brand.edit')->middleware('can:edit brand');
    Route::post('update_brand/{id}', [BrandController::class, 'updateBrand'])->name('user.brand.update')->middleware('can:edit brand');
    Route::delete('delete_brand/{id}', [BrandController::class, 'deleteBrand'])->name('user.brand.delete')->middleware('can:delete brand');

    Route::get('enquiries', [enquiryController::class, 'index'])->name('user.enquiry.list')->middleware('can:list enquiries');
    Route::get('add_enquiry', [enquiryController::class, 'create'])->name('user.enquiry.add')->middleware('can:add enquiry');
    Route::post('create_enquiry', [enquiryController::class, 'store'])->name('user.enquiry.create')->middleware('can:add enquiry');
    Route::get('edit_enquiry/{id}', [enquiryController::class, 'edit'])->name('user.enquiry.edit')->middleware('can:edit enquiry');
    Route::post('update_enquiry/{id}', [enquiryController::class, 'update'])->name('user.enquiry.update')->middleware('can:edit enquiry');
    Route::delete('delete_enquiry/{id}', [enquiryController::class, 'destroy'])->name('user.enquiry.delete')->middleware('can:delete enquiry');
    Route::post('enquiry-toggle-status', [enquiryController::class, 'toggleStatus'])->name('user.enquiry.toggle_status');
    Route::post('enquiry-status-update/{id}', [enquiryController::class, 'saveStatus'])->name('user.enquiry.statusUpdate');
    Route::get('view_enquiry/{id}', [enquiryController::class, 'show'])->name('user.enquiry.view')->middleware('can:edit enquiry');
    Route::get('/enquiry_reports', [ReportController::class, 'view_reports'])->name('user.enquiry.reports');
    Route::get('/enquiry/export', [ReportController::class, 'exportLeads'])->name('user.enquiry.export');

    Route::get('contact-enquiries', [enquiryController::class, 'contactEnquiries'])->name('user.contact-enquiry.list')->middleware('can:list contact enquiries');
    Route::delete('delete_contactEnquiry/{id}', [enquiryController::class, 'destroyContactEnquiry'])->name('user.contact.enquiry.delete')->middleware('can:delete contact enquiry');
    Route::get('view-contact-enquiry/{id}', [enquiryController::class, 'showContactEnquiry'])->name('user.contact.enquiry.view')->middleware('can:edit contact enquiry');

    Route::get('brand-categories', [brandController::class, 'brandCategories'])->name('user.brand.category.list')->middleware('can:list brand categories');
    Route::get('edit-brand-category/{id}', [BrandController::class, 'editBrandCategory'])->name('user.brand.category.edit')->middleware('can:edit brand category');


    //SEO
    Route::post('/add-seo', [SeoController::class, 'createSeo'])->name('user.seo.add');
    Route::post('/update-seo/{id}', [SeoController::class, 'updateSeo'])->name('user.seo.update');

    //FAQ
    Route::post('/add-faq', [FaqController::class, 'createFaq'])->name('user.faq.add');
    Route::post('/update-faq/{id}', [FaqController::class, 'updateFaq'])->name('user.faq.update');
    Route::delete('/delete-faq/{id}', [FaqController::class, 'delete'])->name('user.faq.delete');

    //Widget
    Route::post('/add-widget', [WidgetController::class, 'createWidget'])->name('user.widget.add');
    Route::post('/update-widget/{id}', [WidgetController::class, 'updateWidget'])->name('user.widget.update');
    Route::delete('/delete-widget/{id}', [WidgetController::class, 'delete'])->name('user.widget.delete');



    //Blog
    Route::get('blogs', [BlogController::class, 'index'])->name('user.blog.list')->middleware('can:list blogs');
    Route::get('add-blog', [BlogController::class, 'addBlog'])->name('user.blog.add')->middleware('can:add blog');
    Route::get('edit-blog/{id}', [BlogController::class, 'editBlog'])->name('user.blog.edit')->middleware('can:edit blog');
    Route::post('create-blog', [BlogController::class, 'createBlog'])->name('user.blog.create')->middleware('can:add blog');
    Route::post('update-blog/{id}', [BlogController::class, 'updateBlog'])->name('user.blog.update')->middleware('can:edit blog');
    Route::delete('delete-blog/{id}', [BlogController::class, 'deleteBlog'])->name('user.blog.delete')->middleware('can:delete blog');
    Route::post('blog-toggle-status', [BlogController::class, 'toggleStatus'])->name('user.blog.toggle_status')->middleware('can:change blog status');
    Route::get('blog-categories', [BlogCategoryController::class, 'index'])->name('user.blog.category.list')->middleware('can:list blog categories');
    Route::get('add-blog-category', [BlogCategoryController::class, 'addBlogCategory'])->name('user.blog.category.add')->middleware('can:add blog category');
    Route::get('edit-blog-category/{id}', [BlogCategoryController::class, 'editBlogCategory'])->name('user.blog.category.edit')->middleware('can:edit blog category');
    Route::post('create-blog-category', [BlogCategoryController::class, 'createBlogCategory'])->name('user.blog.category.create')->middleware('can:add blog category');
    Route::post('update-blog-category/{id}', [BlogCategoryController::class, 'updateBlogCategory'])->name('user.blog.category.update')->middleware('can:edit blog category');
    Route::delete('delete-blog-category/{id}', [BlogCategoryController::class, 'deleteBlogCategory'])->name('user.blog.category.delete')->middleware('can:delete blog category');

    //Auth routes
    Route::post('logout', [LoginController::class, 'logout'])->name('user.logout.action');
    Route::get('/', [DashboardController::class, 'index'])->name('user.dashboard');

    //Customer routes
    Route::get('customers', [CustomerController::class, 'index'])->name('user.customers')->middleware('can:list customers');
    Route::get('add_customer', [CustomerController::class, 'create'])->name('user.customer.add')->middleware('can:add customer');
    Route::post('create_customer', [CustomerController::class, 'store'])->name('user.customer.create')->middleware('can:add customer');
    Route::get('edit_customer/{id}', [CustomerController::class, 'edit'])->name('user.customer.edit')->middleware('can:edit customer');
    Route::post('update_customer/{id}', [CustomerController::class, 'update'])->name('user.customer.update')->middleware('can:update customer');
    Route::delete('delete_customer/{id}', [CustomerController::class, 'destroy'])->name('user.customer.delete')->middleware('can:delete customer');
    Route::post('/get-customers', [CustomerController::class, 'getCustomers'])->name('user.customers.search');



    //Users routes
    Route::get('users', [UserController::class, 'index'])->name('user.users')->middleware('can:list users');
    Route::get('add_user', [UserController::class, 'create'])->name('user.user.add')->middleware('can:add user');
    Route::post('create_user', [UserController::class, 'store'])->name('user.user.create')->middleware('can:add user');
    Route::get('edit_user/{id}', [UserController::class, 'edit'])->name('user.user.edit')->middleware('can:edit user');
    Route::post('update_user/{id}', [UserController::class, 'update'])->name('user.user.update')->middleware('can:update user');
    Route::delete('delete_user/{id}', [UserController::class, 'destroy'])->name('user.user.delete')->middleware('can:delete user');

    //Role routes
    Route::get('/roles', [RoleController::class, 'index'])->name('user.roles')->middleware('can:list roles');
    Route::get('/add-role', [RoleController::class, 'addRole'])->name('user.role.add')->middleware('can:add role');
    Route::post('/create-role', [RoleController::class, 'createRole'])->name('user.role.create')->middleware('can:add role');
    Route::get('/edit-role/{id}', [RoleController::class, 'editRole'])->name('user.role.edit')->middleware('can:edit role');
    Route::post('/update-role/{id}', [RoleController::class, 'updateRole'])->name('user.role.update')->middleware('can:edit role');
    Route::delete('/delete-role/{id}', [RoleController::class, 'deleteRole'])->name('user.role.delete')->middleware('can:delete role');

    //Permission routes
    Route::get('/permissions', [PermissionController::class, 'index'])->name('user.permissions')->middleware('can:list permissions');
    Route::get('/permission/add', [PermissionController::class, 'create'])->name('user.permission.create')->middleware('can:add permission');
    Route::post('/permission/create', [PermissionController::class, 'store'])->name('user.permission.store')->middleware('can:add permission');
    Route::get('/edit-permission/{id}', [PermissionController::class, 'edit'])->name('user.permission.edit')->middleware('can:edit permission');
    Route::post('/update_permission/{id}', [PermissionController::class, 'update'])->name('user.permission.update')->middleware('can:edit permission');
    Route::delete('/delete-permission/{id}', [PermissionController::class, 'destroy'])->name('user.permission.delete')->middleware('can:delete permission');


    //cms routes
    Route::get('cms/home-page', [CmsController::class, 'homePageCms'])->name('user.cms.home');
    Route::get('cms/blog-page', [CmsController::class, 'blogPageCms'])->name('user.cms.blogs');
    Route::get('cms/service-page', [CmsController::class, 'servicePageCms'])->name('user.cms.services');
    Route::get('cms/faq-page', [CmsController::class, 'faqPageCms'])->name('user.cms.faqs');

    //User Profile routes
    Route::get('/profile', [UserController::class, 'profile'])->name('user.profile');
    Route::post('/update-profile', [UserController::class, 'updateProfile'])->name('user.updateProfile');
    Route::post('/update-password', [UserController::class, 'updatePassword'])->name('user.updatePassword');


    Route::post('/set-theme', function (Request $request) {
        session(['theme' => $request->theme]);
    });
});
Route::get('/', function () {
    return 'This is the user dashboard';
});