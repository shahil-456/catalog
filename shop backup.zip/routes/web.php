<?php

use App\Http\Controllers\Home\BlogController;
use App\Http\Controllers\Home\EnquiryController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Home\HomeController;
use App\Http\Controllers\Home\ServiceController;
use App\Http\Controllers\ImageServeController;
use App\Http\Controllers\User\LoginController;







Route::get('login', [LoginController::class, 'index'])->name('login');









Route::get('tester', [HomeController::class, 'index'])->name('admin.tester');





Route::get('/faq', [HomeController::class, 'faqs'])->name('home.faqs');

Route::get('/about-us', [HomeController::class, 'about_us'])->name('home.about-us');
Route::get('/contact-us', [HomeController::class, 'contact'])->name('home.contact');
Route::get('/terms', [HomeController::class, 'terms'])->name('home.terms');
Route::get('/privacy-policy', [HomeController::class, 'privacy'])->name('home.privacy');
Route::get('blog', [BlogController::class, 'blogs'])->name('home.blogs');
Route::get('blog/{slug}', [BlogController::class, 'getBlogBySlug'])->name('home.blogs.detail');
Route::post('enquiry-submit', [EnquiryController::class, 'store'])->name('home.enquiry.store');
Route::get('service', [ServiceController::class, 'service'])->name('home.services.detail');
Route::get('service/{categorySlug}', [ServiceController::class, 'categoryService'])->name('home.category.services.detail');
Route::get('service/{categorySlug}/{brandSlug}', [ServiceController::class, 'categoryBrandService'])->name('home.category-brand.services.detail');
Route::post('contact-submit', [EnquiryController::class, 'storeContactEnquiry'])->name('home.contact.store');



Route::get('/serve/{path}', [ImageServeController::class, 'serve'])
    ->where('path', '.*')
    ->name('image.serve');


Route::get('/', function () {
    return 'This is the --- dashboard';
});