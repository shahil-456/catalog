<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

use App\Http\Controllers\Admin\HomeController;


use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;



Route::get('/', function () {
    return redirect()->route('admin.login');
});



Route::get('login', [LoginController::class, 'index'])->name('admin.login');

Route::post('login-submit', [LoginController::class, 'login'])->name('admin.login.action');


Route::get('tester', [HomeController::class, 'index'])->name('admin.tester');

Route::middleware('auth:admin')->group(function () {


Route::get('users', [UserController::class, 'index'])->name('admin.users');
Route::get('add-user', [UserController::class, 'create'])->name('admin.user.add');
Route::post('create-user', [UserController::class, 'store'])->name('admin.user.create');
Route::get('edit-user/{id}', [UserController::class, 'edit'])->name('admin.user.edit');
Route::post('update-user/{id}', [UserController::class, 'update'])->name('admin.user.update');
Route::get('view-user/{id}', [UserController::class, 'show'])->name('admin.user.view');
Route::delete('delete-user/{id}', [UserController::class, 'destroy'])->name('admin.user.delete');

Route::get('categories', [CategoryController::class, 'index'])->name('admin.categories');
Route::get('add-category', [CategoryController::class, 'add'])->name('admin.category.add');
Route::post('create_category', [CategoryController::class, 'store'])->name('admin.category.create');
Route::get('edit-category/{id}', [CategoryController::class, 'editCategory'])->name('admin.category.edit');
Route::post('update_category/{id}', [CategoryController::class, 'update'])->name('admin.category.update');
Route::delete('delete_category/{id}', [CategoryController::class, 'deleteCategory'])->name('admin.category.delete');


Route::get('products', [ProductController::class, 'index'])->name('admin.products');
Route::get('add-product', [ProductController::class, 'create'])->name('admin.product.add');
Route::post('create-product', [ProductController::class, 'store'])->name('admin.product.create');
Route::get('edit-product/{id}', [ProductController::class, 'edit'])->name('admin.product.edit');
Route::post('update-product/{id}', [ProductController::class, 'update'])->name('admin.product.update');
Route::get('view-product/{id}', [ProductController::class, 'show'])->name('admin.product.view');
Route::delete('delete-product/{id}', [ProductController::class, 'destroy'])->name('admin.product.delete');


Route::get('import-products', [ProductController::class, 'import'])->name('admin.import.products');
Route::post('import-submit', [ProductController::class, 'importSubmit'])->name('admin.import.submit');

Route::get('orders', [ProductController::class, 'allOrders'])->name('admin.product.orders');

Route::get('view-order/{id}', [ProductController::class, 'orderDetails'])->name('admin.order.view');

Route::post('update-status/{id}', [ProductController::class, 'updateOrderStatus'])->name('admin.order.status');

//Auth routes
Route::get('logout', [LoginController::class, 'logout'])->name('admin.logout');



Route::post('/set-theme', function (Request $request) {
    session(['theme' => $request->theme]);
});
});
