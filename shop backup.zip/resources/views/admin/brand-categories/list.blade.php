@foreach ($brand_categories as $key => $brand_category)
<tr id="brandCategoryRow{{ $brand_category->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $brand_category->brand->name }}</td>
    <td>{{ $brand_category->category->name??'' }}</td>
    <td>

        <div class="hstack gap-3 flex-wrap">
            @can('edit brand category')
            <a href="{{ route('admin.brand.category.edit', [$brand_category->id]) }}" class="link-success fs-15">
                <i class="ri-edit-2-line"></i>
            </a>
            @endcan 
            
        </div>
    </td>
</tr>
@endforeach
@if ($brand_categories->hasPages())
<tr>
    <td colspan="4">
        {{ $brand_categories->links() }}
    </td>
</tr>
@endif
