@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Brand Catgory
@endslot
@endcomponent
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"> Brand Category</h4>
            </div>
            <div class="card-body">
                <form id="brandForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" id="brandId" value="{{ $brandCategory->id }}">
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="Nameinput" class="form-label">Brand</label>
                                <input disabled type="text" name="name" value="{{ $brandCategory->brand->name }}"
                                    class="form-control" placeholder="Enter Name" id="Nameinput">
                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="Nameinput" class="form-label">Category</label>
                                <input disabled type="text" name="name" value="{{ $brandCategory->category->name }}"
                                    class="form-control" placeholder="Enter Name" id="Nameinput">
                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Add Meta Tags Form --}}
@include('admin.partial.seo.add', ['seo' => $seo ?? collect(),'entity_type' => 'BrandCategories', 'page_id' =>
$brandCategory->id])

{{-- Add FAQ Form --}}
@include('admin.partial.faq.add', ['faq' => $faq ?? collect(),'page' => 'BrandCategories', 'page_id' => $brandCategory->id])


@include('admin.partial.widgets.add', ['widgets' => $widget ?? collect(),'page' => 'BrandCategories', 'page_id' =>
$brandCategory->id])

@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    let descriptionEditor, descriptionArEditor;
    ClassicEditor
        .create(document.querySelector('#description'), {
            height: '200px'
        })
        .then(editor => {
            descriptionEditor = editor;
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => { console.error(error); });

    ClassicEditor
        .create(document.querySelector('#description_ar'), {
            height: '200px'
        })
        .then(editor => {
            descriptionArEditor = editor;
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => { console.error(error); });
</script>
<script>
    $(document).ready(function() {
        $('#brandForm').on('submit', function(e) {
            e.preventDefault();
            $('.invalid-feedback').text('');
            $('.form-control').removeClass('is-invalid');
            let formData = new FormData(this);
            if (typeof descriptionEditor !== 'undefined') {
                formData.set('description', descriptionEditor.getData());
            }
            if (typeof descriptionArEditor !== 'undefined') {
                formData.set('description_ar', descriptionArEditor.getData());
            }
            formData.append('_token', $('input[name="_token"]').val());
            formData.append('is_featured', $('#is_featured').is(':checked') ? 1 : 0);
            formData.append('category_ids', ($('#categorySelect').val() && ''));

            let brandId = $('#brandId').val();

            $.ajax({
                url: "{{ route('admin.brand.update', [':id']) }}".replace(':id', brandId),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastMagic.success("Success!", response.message);
                        setTimeout(function() {
                                window.location.href =
                                    "{{ route('admin.brand.list') }}";
                            }, 1000);
                    }
                },
                error: function(xhr) {
                    let errors = xhr.responseJSON.errors;
                    if (errors) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.name) {
                            $('#nameError').text(errors.name[0]);
                            $('#Nameinput').addClass('is-invalid');
                        }
                        if (errors.name_ar) {
                            $('#nameArError').text(errors.name_ar[0]);
                            $('#NameArinput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#Descriptioninput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#DescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.short_description) {
                            $('#shortDescriptionError').text(errors.short_description[0]);
                            $('#ShortDescriptioninput').addClass('is-invalid');
                        }
                        if (errors.short_description_ar) {
                            $('#shortDescriptionArError').text(errors.short_description_ar[0]);
                            $('#ShortDescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.slug) {
                            $('#slugError').text(errors.slug[0]);
                            $('#Sluginput').addClass('is-invalid');
                        }

                    }
                }
            });
        });
    });
</script>
@endsection
