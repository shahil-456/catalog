@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Categories
@endslot
@endcomponent

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add Brand</h4>
            </div>
            <div class="card-body">
                <form id="brandForm" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="Nameinput" class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Name"
                                    id="Nameinput" >
                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="NameArinput" class="form-label">Name Arabic</label>
                                <input type="text" name="name_ar" class="form-control" placeholder="Enter Name Arabic"
                                    id="NameArinput">
                                <div class="invalid-feedback" id="nameArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="Descriptioninput" class="form-label">Description</label>
                                <textarea name="description" class="form-control" placeholder="Enter Description"
                                    id="description" rows="4"></textarea>
                                <div class="invalid-feedback" id="descriptionError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="DescriptionArinput" class="form-label">Description Arabic</label>
                                <textarea name="description_ar" class="form-control"
                                    placeholder="Enter Description Arabic" id="description_ar" rows="4"></textarea>
                                <div class="invalid-feedback" id="descriptionArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="ShortDescriptioninput" class="form-label">Short Description</label>
                                <input type="text" name="short_description" class="form-control"
                                    placeholder="Enter Short Description" id="ShortDescriptioninput">
                                <div class="invalid-feedback" id="shortDescriptionError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="ShortDescriptionArinput" class="form-label">Short Description Arabic</label>
                                <input type="text" name="short_description_ar" class="form-control"
                                    placeholder="Enter Short Description Arabic" id="ShortDescriptionArinput">
                                <div class="invalid-feedback" id="shortDescriptionArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="image" class="form-label">Image</label>
                                <input type="file" name="image" class="form-control" id="image" accept="image/*">
                                <div class="invalid-feedback" id="imageError"></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex align-items-center">
                            <div class="form-check mb-3">
                                <input type="checkbox" name="is_featured" class="form-check-input" id="is_featured"
                                    value="1">
                                <label class="form-check-label" for="is_featured">Is Featured</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#description'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    ClassicEditor
        .create(document.querySelector('#description_ar'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>

<script>
    $(document).ready(function() {
            $('#brandForm').on('submit', function(e) {
                e.preventDefault();
                // Clear previous errors
                $('#nameError').text('');
                $('#nameArError').text('');
                $('#descriptionError').text('');
                $('#descriptionArError').text('');
                $('#shortDescriptionError').text('');
                $('#shortDescriptionArError').text('');
                $('#imageError').text('');

                $('#Nameinput').removeClass('is-invalid');
                $('#NameArinput').removeClass('is-invalid');
                $('#Descriptioninput').removeClass('is-invalid');
                $('#DescriptionArinput').removeClass('is-invalid');
                $('#ShortDescriptioninput').removeClass('is-invalid');
                $('#ShortDescriptionArinput').removeClass('is-invalid');
                $('#image').removeClass('is-invalid');

                // Client-side validation for name 
                if (!$('#Nameinput').val().trim()) {
                    $('#nameError').text('The name field is .');
                    $('#Nameinput').addClass('is-invalid');
                    return;
                }

                let formData = new FormData(this);
                // Checkbox value handling
                if ($('#is_featured').is(':checked')) {
                    formData.set('is_featured', '1');
                } else {
                    formData.delete('is_featured');
                }

                $.ajax({
                    url: "{{ route('admin.brand.create') }}",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {

                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href =
                                    "{{ route('admin.brand.list') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.name) {
                            $('#nameError').text(errors.name[0]);
                            $('#Nameinput').addClass('is-invalid');
                        }
                        if (errors.name_ar) {
                            $('#nameArError').text(errors.name_ar[0]);
                            $('#NameArinput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#Descriptioninput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#DescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.short_description) {
                            $('#shortDescriptionError').text(errors.short_description[0]);
                            $('#ShortDescriptioninput').addClass('is-invalid');
                        }
                        if (errors.short_description_ar) {
                            $('#shortDescriptionArError').text(errors.short_description_ar[0]);
                            $('#ShortDescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.image) {
                            $('#imageError').text(errors.image[0]);
                            $('#image').addClass('is-invalid');
                        }
                    }
                });
            });
        });
</script>
@endsection
