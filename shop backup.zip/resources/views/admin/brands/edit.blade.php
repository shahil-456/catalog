@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Brands
@endslot
@endcomponent
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Update Brand</h4>
            </div>
            <div class="card-body">
                <form id="brandForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" id="brandId" value="{{ $brand->id }}">
                    <div class="row">
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="Sluginput" class="form-label">Slug</label>
                                <input type="text" name="slug" value="{{ $brand->slug }}" class="form-control"
                                    placeholder="Enter Slug" id="Sluginput">
                                <div class="invalid-feedback" id="slugError"></div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="Nameinput" class="form-label">Name</label>
                                <input type="text" name="name" value="{{ $brand->name }}" class="form-control"
                                    placeholder="Enter Name" id="Nameinput">
                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="NameArinput" class="form-label">Name Arabic</label>
                                <input type="text" name="name_ar" value="{{ $brand->name_ar }}" class="form-control"
                                    placeholder="Enter Name Arabic" id="NameArinput">
                                <div class="invalid-feedback" id="nameArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea name="description" class="form-control" id="description" rows="3"
                                    placeholder="Enter Description">{{ $brand->description }}</textarea>
                                <div class="invalid-feedback" id="descriptionError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="description_ar" class="form-label">Description Arabic</label>
                                <textarea name="description_ar" class="form-control" id="description_ar" rows="3"
                                    placeholder="Enter Description Arabic">{{ $brand->description_ar }}</textarea>
                                <div class="invalid-feedback" id="descriptionArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="short_description" class="form-label">Short Description</label>
                                <textarea name="short_description" class="form-control" id="short_description" rows="2"
                                    placeholder="Enter Short Description">{{ $brand->short_description }}</textarea>
                                <div class="invalid-feedback" id="shortDescriptionError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="short_description_ar" class="form-label">Short Description Arabic</label>
                                <textarea name="short_description_ar" class="form-control" id="short_description_ar"
                                    rows="2"
                                    placeholder="Enter Short Description Arabic">{{ $brand->short_description_ar }}</textarea>
                                <div class="invalid-feedback" id="shortDescriptionArError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="Nameinput" class="form-label">Category</label>


                                <select id="categorySelect" name="categories[]" class="form-control" data-choices
                                    data-choices-removeItem multiple>
                                    <option disabled>Choose category</option>
                                    @foreach($categories as $category)
                                    <option {{ in_array($category->id, $selectedCategories) ? 'selected' : '' }}
                                        value={{ $category->id }} >
                                        {{ $category->name }}
                                    </option>
                                    @endforeach
                                </select>

                                @error('categories') <div class="text-danger">{{ $message }}</div> @enderror
                                <div class="invalid-feedback" id="categoryError"></div>

                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="image" class="form-label">Upload Image</label>
                                <input type="file" name="image" id="image" class="form-control">
                                @if($brand->image)
                                <div class="mt-2">
                                    <img src="{{ asset('storage/images/brands/'.$brand->image) }}" alt="Current Image"
                                        style="height: 60px;">
                                </div>
                                @endif
                                <div class="invalid-feedback" id="imageError"></div>
                            </div>
                        </div>
                        <div class="col-3 d-flex align-items-end">
                            <div class="mb-3 w-100">
                                <label for="is_featured" class="form-label mb-1">Is Featured</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="is_featured" id="is_featured"
                                        value="1" {{ $brand->is_featured ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_featured">Enable</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-3 d-flex align-items-end">
                            <div class="mb-3 w-100">
                                <label for="status" class="form-label mb-1">Status</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="status" id="status_id"
                                        value="1" {{ $brand->status ? 'checked' : '' }}>
                                    <label class="form-check-label" for="status_id">Active</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Add Meta Tags Form --}}
@include('admin.partial.seo.add', ['seo' => $seo ?? collect(),'entity_type' => 'Brands', 'page_id' =>
$brand->id])

{{-- Add FAQ Form --}}
@include('admin.partial.faq.add', ['faq' => $faq ?? collect(),'page' => 'Brands', 'page_id' => $brand->id])

@include('admin.partial.widgets.add', ['widgets' => $widget ?? collect(),'page' => 'Brands', 'page_id' =>
$brand->id])
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    let descriptionEditor, descriptionArEditor;
    ClassicEditor
        .create(document.querySelector('#description'), {
            height: '200px'
        })
        .then(editor => {
            descriptionEditor = editor;
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => { console.error(error); });

    ClassicEditor
        .create(document.querySelector('#description_ar'), {
            height: '200px'
        })
        .then(editor => {
            descriptionArEditor = editor;
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => { console.error(error); });
</script>

<script>
    $(document).ready(function() {
        $('#brandForm').on('submit', function(e) {
            e.preventDefault();


            // Clear all errors

            $('.invalid-feedback').text('');
            $('.form-control').removeClass('is-invalid');

            let formData = new FormData(this);

            if (typeof descriptionEditor !== 'undefined') {
                formData.set('description', descriptionEditor.getData());
            }
            if (typeof descriptionArEditor !== 'undefined') {
                formData.set('description_ar', descriptionArEditor.getData());
            }
            formData.append('_token', $('input[name="_token"]').val());
            formData.append('is_featured', $('#is_featured').is(':checked') ? 1 : 0);
            formData.append('category_ids', ($('#categorySelect').val() && ''));

            let brandId = $('#brandId').val();

            $.ajax({
                url: "{{ route('admin.brand.update', [':id']) }}".replace(':id', brandId),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastMagic.success("Success!", response.message);
                        setTimeout(function() {
                                window.location.href =
                                    "{{ route('admin.brand.list') }}";
                            }, 1000);
                    }
                },
                error: function(xhr) {
                    let errors = xhr.responseJSON.errors;
                    if (errors) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.name) {
                            $('#nameError').text(errors.name[0]);
                            $('#Nameinput').addClass('is-invalid');
                        }
                        if (errors.name_ar) {
                            $('#nameArError').text(errors.name_ar[0]);
                            $('#NameArinput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#Descriptioninput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#DescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.short_description) {
                            $('#shortDescriptionError').text(errors.short_description[0]);
                            $('#ShortDescriptioninput').addClass('is-invalid');
                        }
                        if (errors.short_description_ar) {
                            $('#shortDescriptionArError').text(errors.short_description_ar[0]);
                            $('#ShortDescriptionArinput').addClass('is-invalid');
                        }
                        if (errors.slug) {
                            $('#slugError').text(errors.slug[0]);
                            $('#Sluginput').addClass('is-invalid');
                        }

                    }
                }
            });
        });
    });
</script>
@endsection
