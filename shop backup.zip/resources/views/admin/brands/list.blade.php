@foreach ($brands as $key => $brand)
<tr id="brandRow{{ $brand->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $brand->name }}</td>
    <td>{{ $brand->created_at }}</td>
    <td>
        <div class="hstack gap-3 flex-wrap">
            @can('edit brand')
            <a href="{{ route('admin.brand.edit', [$brand->id]) }}" class="link-success fs-15">
                <i class="ri-edit-2-line"></i>
            </a>
            @endcan 
            @can('delete brand')
            <a href="javascript:void(0);" class="link-danger fs-15 deleteService" data-id="{{ $brand->id }}">
                <i class="ri-delete-bin-line"></i>
            </a>  
            @endcan 

        </div>
    </td>
</tr>
@endforeach
@if ($brands->hasPages())
<tr>
    <td colspan="4">
        {{ $brands->links() }}
    </td>
</tr>
@endif
