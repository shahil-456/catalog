@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Faq Page CMS
@endslot
@endcomponent
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add Faq Page CMS</h4>
            </div>
            <div class="card-body">
                @include('admin.partial.seo.add', ['seo' => $seo ?? collect(),'entity_type' => 'FaqPage', 'page_id' => 0])
                @include('admin.partial.faq.add', ['faq' => $faq ?? collect(),'page' => 'FaqPage', 'page_id' => 0])
                @include('admin.partial.widgets.add', ['widgets' => $widget ?? collect(),'page' => 'FaqPage','page_id' => 0])
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
@endsection
