@extends('layouts.admin.master')
@section('title')
Edit Blog
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Blogs
@endslot
@endcomponent

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Edit Blog</h4>
            </div>
            <div class="card-body">
                <!-- Using enctype for file upload -->
                <form id="blogForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" id="blogId" value="{{ $blog->id }}">
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="slugInput" class="form-label">Slug</label>
                                <input type="text" name="slug" class="form-control" placeholder="Enter Slug"
                                    id="slugInput" value="{{ $blog->slug }}">
                                <div class="invalid-feedback" id="slugError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="categoryInput" class="form-label">Category</label>
                                <select name="category_id" class="form-control" id="categoryInput">
                                    <option value="">Select Category</option>
                                    @foreach($blogCategories as $category)
                                    <option value="{{ $category->id }}" {{ $blog->category_id == $category->id ?
                                        'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="categoryError"></div>
                            </div>
                        </div>
                        <!-- Title -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="titleInput" class="form-label">Title</label>
                                <input type="text" name="title" class="form-control" placeholder="Enter Title"
                                    id="titleInput" value="{{ $blog->title }}">
                                <div class="invalid-feedback" id="titleError"></div>
                            </div>
                        </div>
                        <!-- Title (Arabic) -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="titleArInput" class="form-label">Title (Arabic)</label>
                                <input type="text" name="title_ar" class="form-control" placeholder="Enter Arabic Title"
                                    id="titleArInput" value="{{ $blog->title_ar }}">
                                <div class="invalid-feedback" id="titleArError"></div>
                            </div>
                        </div>
                        <!-- Description -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="descriptionInput" class="form-label">Description</label>
                                <textarea name="description" class="form-control" placeholder="Enter Description"
                                    id="descriptionInput">{{ $blog->description }}</textarea>
                                <div class="invalid-feedback" id="descriptionError"></div>
                            </div>
                        </div>
                        <!-- Description (Arabic) -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="descriptionArInput" class="form-label">Description (Arabic)</label>
                                <textarea name="description_ar" class="form-control"
                                    placeholder="Enter Arabic Description"
                                    id="descriptionArInput">{{ $blog->description_ar }}</textarea>
                                <div class="invalid-feedback" id="descriptionArError"></div>
                            </div>
                        </div>
                        <!-- Author -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="authorInput" class="form-label">Author</label>
                                <input type="text" name="author" class="form-control" placeholder="Enter Author"
                                    id="authorInput" value="{{ $blog->author }}">
                                <div class="invalid-feedback" id="authorError"></div>
                            </div>
                        </div>
                        <!-- Category -->

                        <!-- Image -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="imageInput" class="form-label">Image</label>
                                <input type="file" name="image" class="form-control" id="imageInput">
                                <div class="invalid-feedback" id="imageError"></div>
                                @if($blog->image)
                                <div class="mt-2">
                                    <img src="{{ Storage::url('images/blogs/' . $blog->image) }}" alt="Blog Image"
                                        style="max-width: 200px;">
                                </div>
                                @endif
                            </div>
                        </div>
                        <!-- Sort Order -->
                        {{-- <div class="col-6">
                            <div class="mb-3">
                                <label for="sortOrderInput" class="form-label">Sort Order</label>
                                <input type="number" name="sort_order" class="form-control"
                                    placeholder="Enter Sort Order" id="sortOrderInput" value="{{ $blog->sort_order }}">
                                <div class="invalid-feedback" id="sortOrderError"></div>
                            </div>
                        </div> --}}
                        <!-- Slug (optional if you want it editable) -->

                        <!-- Submit Button -->
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update Blog</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div><!-- end row -->
@include('admin.partial.seo.add', [
'seo' => $seo ?? collect(),
'entity_type' => 'Blogs',
'page_id' => $blog->id,
])
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#descriptionInput'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    ClassicEditor
        .create(document.querySelector('#descriptionArInput'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
            $('#blogForm').on('submit', function(e) {
                e.preventDefault();

                // Clear previous error messages and classes
                $('.invalid-feedback').text('');
                $('.form-control').removeClass('is-invalid');
                // Use FormData to support file upload along with other fields
                let formData = new FormData(this);
                // Get blog ID from hidden input
                let blogId = $('#blogId').val();

                $.ajax({
                    url: "{{ route('admin.blog.update', [':id']) }}".replace(':id', blogId),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href = "{{ route('admin.blog.list') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.title) {
                            $('#titleError').text(errors.title[0]);
                            $('#titleInput').addClass('is-invalid');
                        }
                        if (errors.title_ar) {
                            $('#titleArError').text(errors.title_ar[0]);
                            $('#titleArInput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#descriptionInput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#descriptionArInput').addClass('is-invalid');
                        }
                        if (errors.author) {
                            $('#authorError').text(errors.author[0]);
                            $('#authorInput').addClass('is-invalid');
                        }
                        if (errors.category_id) {
                            $('#categoryError').text(errors.category_id[0]);
                            $('#categoryInput').addClass('is-invalid');
                        }
                        if (errors.image) {
                            $('#imageError').text(errors.image[0]);
                            $('#imageInput').addClass('is-invalid');
                        }
                        // if (errors.sort_order) {
                        //     $('#sortOrderError').text(errors.sort_order[0]);
                        //     $('#sortOrderInput').addClass('is-invalid');
                        // }
                        if (errors.slug) {
                            $('#slugError').text(errors.slug[0]);
                            $('#slugInput').addClass('is-invalid');
                        }
                    }
                });
            });
        });
</script>
@endsection
