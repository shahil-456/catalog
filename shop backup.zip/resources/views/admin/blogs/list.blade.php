@foreach ($blogs as $key => $blog)
<tr id="blogRow{{ $blog->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $blog->title }}</td>
    <td>
        <div class="form-check form-switch">
            @can('edit blog status')
            <input class="form-check-input toggleBlogStatus" type="checkbox" data-id="{{ $blog->id }}" {{
                            $blog->is_active ? 'checked' : '' }}
            >
            @endcan 

            
        </div>
    </td>
    <td>
        <div class="hstack gap-3 flex-wrap">
             @can('edit blog')
            <a href="{{ route('admin.blog.edit', [$blog->id]) }}" class="link-success fs-15">
            <i class="ri-edit-2-line"></i>
            </a>
            @endcan 

            @can('delete blog')
            <a href="javascript:void(0);" class="link-danger fs-15 deleteBlog" data-id="{{ $blog->id }}">
                <i class="ri-delete-bin-line"></i>
            </a>
            @endcan 

            
        </div>
    </td>
</tr>
@endforeach
@if ($blogs->hasPages())
<tr>
    <td colspan="2">
        {{ $blogs->links() }}
    </td>
</tr>
@endif
