@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')



<div class="grid lg:grid-cols-4 gap-6 h-30">
        
  
  @foreach ($carts as $key => $cart)

<div id="Card{{$key+1}}" class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700">

    <a href="#">
        <img class="p-4 rounded-t-lg" src="{{ asset($cart->product->image) }}" alt="product image" />
    </a>
    <div class="px-5 pb-5">
        <a href="#">
            <h5 class="text-xl font-semibold tracking-tight text-gray-900 dark:text-white">{{$cart->product->name}}</h5>
            <p>{{$cart->product->category->name}}</p>
        </a>
        <div class="flex items-center mt-2.5 mb-5">
            <div class="flex items-center space-x-1 rtl:space-x-reverse">
               
                
            </div>
            {{-- <span class="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-sm dark:bg-blue-200 dark:text-blue-800 ms-3">5.0</span> --}}
        </div>
        <br>
        <div class="flex items-center justify-between">
            <span class="text-3xl font-bold text-gray-900 dark:text-white">{{ currencySymbol() }}{{$cart->product->price}}</span>
            <a href="{{ route('admin.product.view', [$cart->product->id]) }}" >
            <button type="button" class="btn bg-primary text-white">Details</button></a>
        </div>
<br>
        
    <div class="">

        <a class="class="link-danger fs-15 deleteProduct"" href="{{ route('admin.product.addCart', [$cart->id]) }}" >
      <span class="btn bg-danger text-white rounded-lg">

          <i data-feather="trash-2"></i>

      </span>
            </a>
        </div>



    </div>
</div>



  

@endforeach


</div>
                



<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
             <script>
    $(document).ready(function() {
        
            // Handle the delete button click
            $('.deleteCart').on('click', function() {
                var cartId = $(this).data('id');
                var token = $('meta[name="csrf-token"]').attr(
                    'content');

                if (confirm("Are you sure you want to delete this product?")) {
                    $.ajax({
                    url: "{{ route('admin.cart.delete', [':id']) }}".replace(':id', cartId),
                    type: 'POST',
                    data: {
                        _token: token,
                        _method: 'DELETE'
                    },
                    
                    success: function(response) {

                        $('#productRow' + cartId).remove();

                        if (response.success) {
                           Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Deleted successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                            $('#productRow' + cartId).remove();
                        }
                    },
                    error: function(xhr) {
                       
                    }
                });

                }
            });

            



        });
</script>

@endsection
