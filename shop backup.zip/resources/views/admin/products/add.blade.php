@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
      <link href="{{ URL::to('knorix/assets/libs/quill/quill.core.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ URL::to('knorix/assets/libs/quill/quill.snow.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ URL::to('knorix/assets/libs/nice-select2/css/nice-select2.css') }}" rel="stylesheet" type="text/css">


  
  <div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Add Product</h4>
                               
                            </div>
                        </div>


                        <div class="p-6">

                    <form class="valid-form grid lg:grid-cols-2 gap-2" id="productForm" enctype="multipart/form-data">
                            @csrf

                           
                    <div class="form-group">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Name</label>
                        <input name="name" type="text" class="form-input">
                    </div>
                    
                    <div class="form-group ">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Category</label>

                    <select name="category_id" class="form-input ">
                        <option value="">-- Select Category --</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                    </div>

                    <div class="form-group">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Stock</label>
                        <input name="stock" value="1" type="stock" step="1" class="form-input">
                    </div>

                    <div class="form-group">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Price</label>
                        <input name="price" type="number" step="1" class="form-input">
                    </div>

                    


                    {{-- <div class="form-group">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Category</label>
                      
                    </div> --}}
                    <br>

                    <div class="form-group grid lg:grid-cols-12">

                        <div name="description" id="snow-editor" style="height: 300px;">
                            <h3><span class="ql-size-large">Description!</span></h3>
                               
                            </div>       

                    </div>

                    <br>

                   


                    <div class="form-group">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Image</label>
                        <input name="image" type="file" class="form-input" accept="image/*">
                    </div>

{{-- 
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Name</label>
                    <ul id="options" class="absolute z-10 w-full  border rounded mt-1 max-h-40 overflow-auto hidden"></ul>

                        <input id="selectedValue" name="selected_value" type="" class="form-input">
                    </div> --}}


                    {{-- <div class="form-group" id="searchableSelect">
                    <input id="searchInput" type="text" placeholder="Search and select..."
                            class="form-input">
                    <ul id="options" class="absolute z-10 w-full border rounded mt-1 max-h-40 overflow-auto hidden"></ul>
                    <input class="form-input" type="hidden" name="selected_value" id="selectedValue">
                    </div> --}}


                    

                   

                    
                
                    

                        <div class="col-span-2">
                            <button class="btn bg-primary text-white" type="submit">Submit</button>
                        </div>
                        </form>



        

         


                       

                            {{-- <form class="valid-form grid lg:grid-cols-3 gap-6">
                               
                                <button class="btn bg-primary text-white" type="submit">Submit form</button>

                            </form> --}}

                           

                        
                        </div>
                    </div>

                    
                </div>

                

       <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/pristinejs/dist/pristine.min.js"></script>



 <script src="{{ URL::to('knorix/assets/libs/quill/quill.min.js') }}"></script>
    <script src="{{ URL::to('knorix/assets/js/pages/form-editor.js') }}"></script>
    <script src="{{ URL::to('knorix/assets/libs/nice-select2/js/nice-select2.js') }}"></script>
    <script src="{{ URL::to('knorix/assets/js/pages/form-select.js') }}"></script>

  


    <script>

    $(document).ready(function() {
        var form = document.getElementById("productForm");
        var pristine = new Pristine(form);

        $('#productForm').on('submit', function(e) {
            e.preventDefault();

            // reset pristine errors
            pristine.reset();

            let formData = new FormData(this);

            $.ajax({
                url: "{{ route('admin.product.create') }}",
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Operation completed successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        $('#productForm')[0].reset();
                    }
                },
               error: function(xhr) {
            let errors = xhr.responseJSON.errors;

            // Clear previous errors
            $('.error-text').remove();
            $('input, select, textarea').removeClass('border-red-500');

            // Loop through Laravel validation errors
            $.each(errors, function(field, messages) {
                let input = $('[name="'+field+'"]');

                // Add red border
                input.addClass('border-red-500');

                // Append error message
                input.after('<small class="error-text text-red-500">'+messages[0]+'</small>');
            });
        }

            });
        });
    });
</script>



@endsection


@section('script')





@endsection


