@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
               <div class="flex flex-col gap-6">

                  <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Products</h4>
                                <div class="flex items-center gap-2">
                                   <a href="{{route('admin.product.add')}}"><button type="button" 
                                class="float-right px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1">
                                Add Product
                            </button></a>
                                </div>
                            </div>
                        </div>
                        <div>
                            
                            <div class="overflow-x-auto">
                                <div class="min-w-full inline-block align-middle">
                                    <div class="py-3 px-4">
                                            <div class="relative max-w-xs">
                                                <label for="table-search" class="sr-only">Search</label>
                                                <input type="text" name="table-search" id="table-search" class="form-input ps-11" placeholder="Search for Products">
                                                <div class="absolute inset-y-0 start-0 flex items-center pointer-events-none ps-4">
                                                    <svg class="h-3.5 w-3.5 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" >
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    <div class="overflow-hidden">
                                        
                                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                            <thead>
                                                <tr>

                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>

                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Image</th>                                                                                                       
                                                                                        
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @include('admin.products.list')

                                            </tbody>

                                        </table>
                                    </div>


                                    {{ $products->links('vendor.pagination.custom') }}



                                
                                    </div>
                                </div>


                           
                        </div>
                    </div> <!-- end card -->

            </div>  

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
             <script>
    $(document).ready(function() {
        
            // Handle the delete button click
            $('.deleteProduct').on('click', function() {
                var productId = $(this).data('id');
                var token = $('meta[name="csrf-token"]').attr(
                    'content');

                if (confirm("Are you sure you want to delete this product?")) {
                    $.ajax({
                    url: "{{ route('admin.product.delete', [':id']) }}".replace(':id', productId),
                    type: 'POST',
                    data: {
                        _token: token,
                        _method: 'DELETE'
                    },
                    
                    success: function(response) {
                        $('#productRow' + productId).remove();

                        if (response.success) {
                           Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Deleted successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                            $('#productRow' + productId).remove();
                        }
                    },
                    error: function(xhr) {
                       
                    }
                });

                }
            });

            $('#table-search').on('keyup', function() {
                let searchQuery = $(this).val();
                loadProducts(searchQuery);
            });

            function loadProducts(searchQuery = '') {
                $.ajax({
                    url: "{{ route('admin.products') }}",
                    type: 'GET',
                    data: {
                        search: searchQuery
                    },
                    success: function(response) {
                        $('tbody').html(response);
                    },
                    error: function(xhr) {
                       
                    }
                });
        }



        });
</script>

@endsection
