@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
               <div class="flex flex-col gap-6">

                  <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Orders</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>
                        <div>
                            
                            <div class="overflow-x-auto">
                                <div class="min-w-full inline-block align-middle">
                                    <div class="py-3 px-4">
                                            <div class="relative max-w-xs">
                                                
                                                
                                            </div>
                                        </div>
                                    <div class="overflow-hidden">
                                        
                                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                            <thead>
                                                <tr>

                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User Name</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product Name</th>
                                                    
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>                                                    
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Image</th>
                                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                                           
                                                    <th scope="col" class="px-6 py-3    text-left text-xs font-medium text-gray-500 uppercase">ACtion</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                               @foreach ($orders as $key => $order)

                                                <tr id="productRow{{ $order->id }}" class="odd:bg-white even:bg-gray-100 dark:odd:bg-slate-700 dark:even:bg-slate-800">
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$key+1}}</td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$order->user->username}}</td>     
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$order->product->name}}</td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$order->amount}}</td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$order->quantity}}</td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$order->total_amount}}</td>

                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> 
                                                <img src="{{ asset($order->product->image) }}" width="150" alt="User Photo">

                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                @if ($order->status == 'Pending')
                                                    <button class="px-3 py-1 text-xs font-semibold rounded-lg bg-yellow-100 text-yellow-800">
                                                        {{ $order->status }}
                                                    </button>
                                                @elseif ($order->status == 'Shipped')
                                                    <button class="px-3 py-1 text-xs font-semibold rounded-lg bg-blue-100 text-blue-800">
                                                        {{ $order->status }}
                                                    </button>
                                                @elseif ($order->status == 'Delivered')
                                                    <button class="px-3 py-1 text-xs font-semibold rounded-lg bg-green-100 text-green-800">
                                                        {{ $order->status }}
                                                    </button>
                                                @endif
                                            </td>

                                            <td class="px-6 py-4 whitespace-nowrap text-end text-sm font-medium">

                                                <div class="flex space-x-3">
                                                <a href="{{ route('admin.order.view', [$order->id]) }}"><i data-feather="eye" class="text-green-600 w-4"></i></a>
                                                </div>
                                            </td>


                                                </tr>

                                                @endforeach



                                            </tbody>

                                        </table>
                                    </div>


                                    {{ $orders->links('vendor.pagination.custom') }}



                                
                                    </div>
                                </div>


                           
                        </div>
                    </div> <!-- end card -->

            </div>  

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
            

@endsection
