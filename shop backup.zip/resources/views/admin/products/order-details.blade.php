@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    
  

<div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Order  Details</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>


                <div class="p-6">
                <div class="max-w-xl mx-auto shadow rounded-2xl p-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    <input type="hidden" id="orderId" value="{{$order->id}}">
                <div class="p-4 border rounded-lg ">
                    <span class="font-semibold ">UserName:</span>
                    <span class="ml-2 ">{{ $order->user->username }}</span>
                </div>
                <div class="p-4 border rounded-lg ">
                    <span class="font-semibold ">Product Name:</span>
                    <span class="ml-2 ">{{ $order->product->name }}</span>
                </div>

            <div class="p-4 border rounded-lg ">
                <span class="font-semibold ">Category:</span>
                <span class="ml-2 ">{{ $order->product->category->name }}</span>
            </div>

       

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Amount:</span>
            <span class="ml-2 ">{{ $order->amount ?? 'N/A' }}</span>
        </div>

          <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Stock:</span>
            <span class="ml-2 ">{{ $order->stock ?? 1 }}</span>
        </div>

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Created At:</span>
            <span class="ml-2 ">{{ $order->created_at->format('d M Y') }}</span>
        </div>

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Description:</span>
            <span class="ml-2 ">{!! $order->product->description ?? 'N/A' !!}</span>
        </div>
        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Status:</span>
            <span class="ml-2 ">{{ $order->status ?? 1 }}</span>
        </div>
        </div>

            <div>
                <span class="font-semibold">Image:</span><br>
                <img src="{{ asset($order->product->image) }}" 
                    alt="Profile Photo" 
                    class="w-24 h-24 rounded-full object-cover mt-2">
            </div>

             <div class="mt-6 flex gap-3">
                    <a href="{{ route('admin.products') }}" class="px-4 py-2 bg-gray-600 text-white rounded-lg">Back</a>
                </div>

                        </div>

                        <form class="valid-form grid lg:grid-cols-2 gap-2" id="statusForm" enctype="multipart/form-data">
                            @csrf
                    <div class="form-group ">
                        <label class="text-gray-800 text-sm font-medium inline-block mb-2">Change Status</label>
                        <select name="status" class="form-input">
                        <option value="">-- Select Status --</option>
                        <option value="Pending" {{ $order->status == 'Pending' ? 'selected' : '' }}>Pending</option>
                        <option value="Shipped" {{ $order->status == 'Shipped' ? 'selected' : '' }}>Shipped</option>
                        <option value="Delivered" {{ $order->status == 'Delivered' ? 'selected' : '' }}>Delivered</option>
                    </select>

                        </div>
                           <button class="btn bg-primary text-white" type="submit">Submit</button>  
                        </form>
                    </div>

                   

                    
                </div>
                </div>



                <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/pristinejs/dist/pristine.min.js"></script>


    <script>

    $(document).ready(function() {
        var form = document.getElementById("statusForm");
        var pristine = new Pristine(form);

        $('#statusForm').on('submit', function(e) {
            e.preventDefault();

            // reset pristine errors
            pristine.reset();
            let orderId = $('#orderId').val();

            let formData = new FormData(this);

            $.ajax({
                url: "{{ route('admin.order.status', ':id') }}".replace(':id', orderId),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Operation completed successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        $('#productForm')[0].reset();
                    }
                },
               error: function(xhr) {
            let errors = xhr.responseJSON.errors;

            // Clear previous errors
            $('.error-text').remove();
            $('input, select, textarea').removeClass('border-red-500');

            // Loop through Laravel validation errors
            $.each(errors, function(field, messages) {
                let input = $('[name="'+field+'"]');

                // Add red border
                input.addClass('border-red-500');

                // Append error message
                input.after('<small class="error-text text-red-500">'+messages[0]+'</small>');
            });
        }

            });
        });
    });
</script>


@endsection




