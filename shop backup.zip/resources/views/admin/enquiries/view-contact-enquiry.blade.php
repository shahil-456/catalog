@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
View Enquiry
@endslot
@endcomponent

<div class="row">
    <div class="col-xl-12">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <h4 class="fw-bold text-dark mb-3">Contact Enquiry Details</h4>
                            <div class="row g-3 mb-3">
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Customer Name</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->name }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Email</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->email ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Phone</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->phone ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Company</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->company ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Message</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->message ?? 'N/A' }}</p>
                                    </div>
                                </div>
                               
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Created Date</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->created_at ?? 'N/A' }}</p>
                                    </div>
                                </div>
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script src="{{ URL::asset('material/libs/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ URL::asset('material/js/pages/timeline.init.js') }}"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const previewButtons = document.querySelectorAll('.preview-btn');
        const previewFrame = document.getElementById('previewFrame');

        previewButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                const fileUrl = this.getAttribute('data-filename');
                if (previewFrame && fileUrl) {
                    previewFrame.src = fileUrl;
                }
            });
        });

        // Clear frame when modal is closed
        const previewModal = document.getElementById('previewModal');
        previewModal.addEventListener('hidden.bs.modal', function () {
            previewFrame.src = '';
        });
    });
</script>
@endsection
