@extends('layouts.admin.master')
@section('title')
Edit Enquiry
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Enquiries
@endslot
@endcomponent

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Edit Enquiry</h4>
            </div>
            <div class="card-body">
                <!-- Using enctype for file upload -->
                <form value={{$enquiry->customer->first_name}} id="blogForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden"  id="enq_id" value="{{ $enquiry->id
                    }}">
                    <div class="row">

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="customerNameInput" class="form-label">Customer First Name</label>
                                <input type="text" name="first_name" class="form-control"
                                    placeholder="Enter Customer Name" value={{$enquiry->customer->first_name}}
                                value={{$enquiry->customer->first_name}} id="customerNameInput">
                                <div class="invalid-feedback" value={{$enquiry->customer->first_name}}
                                    id="customerNameError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="customerNameInput" class="form-label">Last Name</label>
                                <input type="text" name="last_name" class="form-control"
                                    placeholder="Enter Customer Last Name" value={{$enquiry->customer->first_name}}
                                value={{$enquiry->customer->first_name}} id="customerNameInput">
                                <div class="invalid-feedback" value={{$enquiry->customer->last_name}}
                                    id="customerNameError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="emailInput" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Email"
                                    value={{$enquiry->customer->email}} id="emailInput">
                                <div class="invalid-feedback" value={{$enquiry->customer->first_name}} id="emailError">
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="phoneInput" class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" placeholder="Enter Phone"
                                    value="{{$enquiry->customer->mobile}}" id="phoneInput">
                                <div class="invalid-feedback" value={{$enquiry->customer->first_name}} id="phoneError">
                                </div>
                            </div>
                        </div>


                        <div class="col-6">
                            <div class="mb-3">
                                <label for="category_id" class="form-label">Category</label>
                                <select name="category_id" id="category_id" class="form-control">
                                    <option disabled>Select Category</option>
                                    @foreach($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="category_idError"></div>
                            </div>
                        </div>
                        <!-- Title -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="brand_id" class="form-label">Brand</label>
                                <select name="brand_id" id="brand_id" class="form-control">
                                    <option disabled>Select Brand</option>
                                    @foreach($brands as $brand)
                                    <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="brand_idError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="modelInput" class="form-label">Model</label>
                                <input type="text" name="model" class="form-control" placeholder="Enter Model"
                                    value={{$enquiry->model}} id="modelInput">
                                <div class="invalid-feedback" value={{$enquiry->customer->first_name}} id="modelError">
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="mb-3">
                                <label for="messageInput" class="form-label">Message</label>
                                <textarea name="message" class="form-control" placeholder="Enter Message"
                                    id="messageInput">{{$enquiry->message}}</textarea>
                                <div class="invalid-feedback" value={{$enquiry->message}} id="messageError"></div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="mb-3">
                                <label for="issueInput" class="form-label">Issue</label>
                                <textarea name="issue" class="form-control" placeholder="Enter Issue"
                                    id="issueInput">{{$enquiry->issue}}</textarea>
                                <div class="invalid-feedback" value={{$enquiry->issue}} id="issueError"></div>
                            </div>
                        </div>


                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update Enquiry</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Status History</h4>
            </div>
            <div class="card-body">
                <!-- Using enctype for file upload -->
                @can('change enquiry status')
                <form id ="statusForm">
                    @csrf
                    <div class="mb-3">
                        <label for="status_id">Status</label>
                        <select @cannot('change lead status') disabled @endcannot name="status_id"
                            value={{$enquiry->customer->first_name}} id="status_id"
                            class="form-select" style="background-color: {{ $latestStatus->statusData->style ?? '' }}">
                            <option value="">Select Status</option>
                            @foreach($statuses as $status)
                            <option value="{{ $status->id }}" @if($latestStatusId == $status->id) selected style="background-color: #fff; color: #000;" @endif>
                                {{ $status->name }}
                            </option>
                                {{ $status->name }}
                            </option>
                            @endforeach
                        </select>
                        @error('status_id') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>

                    <div class="mb-3">
                        <label for="comment">Comment</label>
                        <textarea name="comment"
                            value={{$enquiry->customer->first_name}} id="comment" class="form-control">{{ old('comment') }}</textarea>
                        @error('comment') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>

                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
                @endcan

                <div class="mt-4">
                    @if($status_historys->count() > 0)
                    <h5 class="text-center mb-4">Status History</h5>
                    <div>
                        @foreach ($status_historys as $value)
                        <div class="row mb-4">
                            <div class="col-12 d-flex flex-column flex-md-row align-items-start gap-3">
                                <div class="flex-grow-1">
                                    <div class="p-3 rounded shadow-sm border position-relative"
                                        style="background-color: {{ optional($value->statusData)->style ?? '#f8f9fa' }};">
                                        <div class="fw-bold fs-6 mb-1 text-white">
                                            {{ $value->statusData?->name ?? '' }}
                                        </div>
                                        <div class="mb-1 text-white">
                                            {{ $value->comment }}
                                        </div>
                                        <div class="d-flex justify-content-between text-white-50 small mt-2">
                                            <span>
                                                By {{ $value->updatedBy ? $value->updatedBy->first_name . ' ' .
                                                $value->updatedBy->last_name : $lead->typist->first_name . ' ' .
                                                $lead->typist->last_name }}
                                            </span>
                                            <span>
                                                {{ \Carbon\Carbon::parse($value->created_at)->format('d M Y, h:i A') }}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @endif
                </div>

            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->

</div><!-- end row -->

@endsection

@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/35.3.1/classic/ckeditor.js"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#descriptionInput'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    ClassicEditor
        .create(document.querySelector('#descriptionArInput'))
        .then(editor => {
            editor.ui.view.editable.element.style.height = '200px';
            editor.ui.view.editable.element.style.overflowY = 'auto';
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
            $('#blogForm').on('submit', function(e) {
                e.preventDefault();

                // Clear previous error messages and classes
                $('.invalid-feedback').text('');
                $('.form-control').removeClass('is-invalid');
                // Use FormData to support file upload along with other fields
                let formData = new FormData(this);
                // Get blog ID from hidden input
                let blogId = $('#blogId').val();

                $.ajax({
                    url: "{{ route('admin.blog.update', [':id']) }}".replace(':id', blogId),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href = "{{ route('admin.enquiry.list') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.title) {
                            $('#titleError').text(errors.title[0]);
                            $('#titleInput').addClass('is-invalid');
                        }
                        if (errors.title_ar) {
                            $('#titleArError').text(errors.title_ar[0]);
                            $('#titleArInput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#descriptionInput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#descriptionArInput').addClass('is-invalid');
                        }
                        if (errors.author) {
                            $('#authorError').text(errors.author[0]);
                            $('#authorInput').addClass('is-invalid');
                        }
                        if (errors.category_id) {
                            $('#categoryError').text(errors.category_id[0]);
                            $('#categoryInput').addClass('is-invalid');
                        }
                        if (errors.image) {
                            $('#imageError').text(errors.image[0]);
                            $('#imageInput').addClass('is-invalid');
                        }
                        // if (errors.sort_order) {
                        //     $('#sortOrderError').text(errors.sort_order[0]);
                        //     $('#sortOrderInput').addClass('is-invalid');
                        // }
                        if (errors.slug) {
                            $('#slugError').text(errors.slug[0]);
                            $('#slugInput').addClass('is-invalid');
                        }
                    }
                });
            });

            $('#blogForm').on('submit', function(e) {
                e.preventDefault();

                // Clear previous error messages and classes
                $('.invalid-feedback').text('');
                $('.form-control').removeClass('is-invalid');
                // Use FormData to support file upload along with other fields
                let formData = new FormData(this);
                // Get blog ID from hidden input
                let enq_id = $('#enq_id').val();

                $.ajax({
                    url: "{{ route('admin.enquiry.update', [':id']) }}".replace(':id', enq_id),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href = "{{ route('admin.blog.list') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.title) {
                            $('#titleError').text(errors.title[0]);
                            $('#titleInput').addClass('is-invalid');
                        }
                        if (errors.title_ar) {
                            $('#titleArError').text(errors.title_ar[0]);
                            $('#titleArInput').addClass('is-invalid');
                        }
                        if (errors.description) {
                            $('#descriptionError').text(errors.description[0]);
                            $('#descriptionInput').addClass('is-invalid');
                        }
                        if (errors.description_ar) {
                            $('#descriptionArError').text(errors.description_ar[0]);
                            $('#descriptionArInput').addClass('is-invalid');
                        }
                        if (errors.author) {
                            $('#authorError').text(errors.author[0]);
                            $('#authorInput').addClass('is-invalid');
                        }
                        if (errors.category_id) {
                            $('#categoryError').text(errors.category_id[0]);
                            $('#categoryInput').addClass('is-invalid');
                        }
                        if (errors.image) {
                            $('#imageError').text(errors.image[0]);
                            $('#imageInput').addClass('is-invalid');
                        }
                        // if (errors.sort_order) {
                        //     $('#sortOrderError').text(errors.sort_order[0]);
                        //     $('#sortOrderInput').addClass('is-invalid');
                        // }
                        if (errors.slug) {
                            $('#slugError').text(errors.slug[0]);
                            $('#slugInput').addClass('is-invalid');
                        }
                    }
                });
            });$('#statusForm').on('submit', function(e) {
                e.preventDefault();

                // Clear previous error messages and classes
                $('.invalid-feedback').text('');
                $('.form-control').removeClass('is-invalid');
                // Use FormData to support file upload along with other fields
                let formData = new FormData(this);
                // Get blog ID from hidden input
                let enquiry_id = $('#enq_id').val();

                $.ajax({
                    url: "{{ route('admin.enquiry.statusUpdate', [':id']) }}".replace(':id', enquiry_id),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                location.reload();
                            }, 1000);

                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors.title) {
                            $('#titleError').text(errors.title[0]);
                            $('#titleInput').addClass('is-invalid');
                        }
                        if (errors.title_ar) {
                            $('#titleArError').text(errors.title_ar[0]);
                            $('#titleArInput').addClass('is-invalid');
                        }
                      
                    }
                });
            });


        });
</script>
@endsection
