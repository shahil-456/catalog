@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Enquiry
@endslot
@endcomponent


<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div class="live-preview">

                    <div class="row g-4 mb-3">
                     <div class="col-xxl-4 col-sm-4">
                                    <div class="input-light">
                                        <label for="key">Keyword</label>
                                        <input type="text" class="form-control search" id="search"
                                        placeholder="Search Customer Name,Email,Phone,Model,...">
                                    </div>
                                </div>

                                
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle mb-0" id="blog_table">
                            <thead class="table-light">
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">Customer Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Company</th>
                                <th scope="col">Created At</th>
                                {{-- <th scope="col">Status</th> --}}
                                <th scope="col">Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                @include('admin.enquiries.contact-enquiries-list')
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>

<script>
    $(document).ready(function() {
            // Handle the delete button click
            $(document).on('click', '.deleteEnquiry', function() {
                var blogId = $(this).data('id');
                var token = $('meta[name="csrf-token"]').attr(
                    'content');

                if (confirm("Are you sure you want to delete this enquiry?")) {
                    $.ajax({
                        url: "{{ route('admin.contact.enquiry.delete', [':id']) }}".replace(':id',
                            blogId),
                        type: 'DELETE',
                        data: {
                            _token: token,
                        },
                        success: function(response) {
                            if (response.success) {
                                toastMagic.success("Success!", response.message);
                                $('#blogRow' + blogId)
                                    .remove(); // Remove the user row from the table
                            }
                        },
                        error: function(xhr) {
                            toastMagic.error("Error!", "Something went wrong. Please try again.");
                        }
                    });
                }
            });
        });
</script>
<script>
    $(document).ready(function() {
            function LoadEnquiries(searchQuery = '') {
                $.ajax({
                    url: "{{ route('admin.contact-enquiry.list') }}",
                    type: 'GET',
                    data: {
                        search: searchQuery
                    },
                    success: function(response) {
                        $('tbody').html(response);
                    },
                    error: function(xhr) {

                        toastMagic.error("Error!", "Something went wrong. Please try again.");


                    }
                });
            }
        });
</script>
<script>
    $(document).ready(function() {
            $(document).on('click', '.pagination a', function(event) {
                event.preventDefault();
                var url = $(this).attr('href');
                $.ajax({
                    url: url,
                    type: 'GET',
                    success: function(data) {
                        $('#blog_table tbody').html(data);
                    }
                });
            });
        });
</script>
<script>

        $('#search, #idStatus, #startDate, #endDate').on('keyup change', function () {
        LoadEnquiries();
        });

        function LoadEnquiries() {

            let search = $('#search').val();
            let status = $('#idStatus').val();
            let typist = $('#typist').val();
            let sales = $('#sales').val();
            let start_date = $('input[name="start_date"]').val();
            let end_date = $('input[name="end_date"]').val();        

            $.ajax({
                url: "{{ route('admin.contact-enquiry.list') }}",
                type: 'GET',
                data: {
                    search: search,
                    status: status,
                    sales: sales,
                    typist: typist,
                    start_date: start_date,
                    end_date: end_date
                },
                success: function(response) {
                    $('tbody').html(response);

                },
               
            });
        }     


    // Handle toggle of blog active status
        $(document).on('change', '.toggleEnquiryStatus', function() {
            var blogId = $(this).data('id');
            var status = $(this).is(':checked') ? 1 : 0;
            $.ajax({
                url: "{{ route('admin.enquiry.toggle_status') }}",
                type: "POST",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    id: blogId,
                    status: status
                },
                success: function(response) {
                    if (response.success) {

                        toastMagic.success("Success!", response.message);
                    } else {

                        toastMagic.error("Error!", 'Failed to update status.');
                    }
                },
                error: function() {
                    toastMagic.error("Error!", 'An error occurred.');
                }
            });
        });
</script>
@endsection
