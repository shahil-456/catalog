@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
View Enquiry
@endslot
@endcomponent

<div class="row">
    <div class="col-xl-12">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <div class="live-preview">
                            <h4 class="fw-bold text-dark mb-3">Enquiry Details</h4>
                            <div class="row g-3 mb-3">
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Customer Name</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->customer->first_name . ' ' .
                                            $enquiry->customer->last_name }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Email</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->customer->email ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Phone</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->customer->mobile ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Model</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->model ?? 'N/A' }}
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Message</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->message ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Issue</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->issue ?? 'N/A' }}</p>
                                    </div>
                                </div>
                               
                                <div class="col-sm-6 col-lg-4 mb-3">
                                    <div class="p-3 bg-white rounded shadow-sm border h-100">
                                        <h6 class="text-muted small mb-1">Created Date</h6>
                                        <p class="fw-semibold text-dark mb-0">{{ $enquiry->created_at ?? 'N/A' }}</p>
                                    </div>
                                </div>
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="">
                            @if($status_historys->count() > 0)
                            <div style="text-align: center;">
                                <h5>Status History</h5>
                            </div>
                            <div class="">
                                @foreach ($status_historys as $value)
                                <div class="row mb-4">
                                    <div class="col-12 d-flex flex-column flex-md-row align-items-start gap-3">
                                        <div class="flex-grow-1">
                                            <div class="p-3 rounded shadow-sm border position-relative"
                                                style="background-color: {{ optional($value->statusData)->style ?? '#f8f9fa' }}; text-decoration: none;">
                                                <div class="fw-bold fs-6 mb-1 text-white">
                                                    {{ $value->statusData?->name ?? '' }}
                                                </div>
                                                <div class="mb-1 text-white">
                                                    {{ $value->comment }}
                                                </div>
                                                <div class="d-flex justify-content-between text-white-50 small mt-2">
                                                    <span>
                                                        By {{ $value->updatedBy ? $value->updatedBy->first_name . ' ' .
                                                        $value->updatedBy->last_name : $enquiry->typist->first_name . ' ' .
                                                        $enquiry->typist->last_name }}
                                                    </span>
                                                    <span>
                                                        {{ \Carbon\Carbon::parse($value->created_at)->format('d M Y, h:i
                                                        A') }}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script src="{{ URL::asset('material/libs/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ URL::asset('material/js/pages/timeline.init.js') }}"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const previewButtons = document.querySelectorAll('.preview-btn');
        const previewFrame = document.getElementById('previewFrame');

        previewButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                const fileUrl = this.getAttribute('data-filename');
                if (previewFrame && fileUrl) {
                    previewFrame.src = fileUrl;
                }
            });
        });

        // Clear frame when modal is closed
        const previewModal = document.getElementById('previewModal');
        previewModal.addEventListener('hidden.bs.modal', function () {
            previewFrame.src = '';
        });
    });
</script>
@endsection
