@foreach ($enquiries as $key => $enquiry)
<tr id="enquiryRow{{ $enquiry->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $enquiry->name }}</td>
    <td>{{ $enquiry->email }}</td>

    <td>{{ $enquiry->phone }}</td>
    <td>{{ $enquiry->company?? 'N/A' }}</td>
      {{-- <td>{{ $enquiry->status?? 'N/A' }}</td> --}}

    <td>{{ $enquiry->created_at }}</td>

    

   
    <td>
        <div class="hstack gap-3 flex-wrap">

            @can('edit enquiry')
            {{-- <a href="{{ route('admin.enquiry.edit', [$enquiry->id]) }}" class="link-success fs-15">
                            <i class="ri-edit-2-line"></i>
            </a> --}}
            @endcan 

            @can('view enquiry')
            <a href="{{ route('admin.contact.enquiry.view', [$enquiry->id]) }}" class="link-success fs-15">
                            <i class="ri-eye-line"></i>
            </a>
            @endcan 

    
            @can('delete enquiry')
              <a href="javascript:void(0);" class="link-danger fs-15 deleteEnquiry" data-id="{{ $enquiry->id }}">
                <i class="ri-delete-bin-line"></i>
            </a>
            @endcan 

        </div>
    </td>
</tr>
@endforeach
@if ($enquiries->hasPages())
<tr>
    <td colspan="2">
        {{ $enquiries->links() }}
    </td>
</tr>
@endif