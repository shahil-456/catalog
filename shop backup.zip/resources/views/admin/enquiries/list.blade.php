@foreach ($enquiries as $key => $enquiry)
<tr id="enquiryRow{{ $enquiry->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $enquiry->customer->first_name }}</td>
    <td>{{ $enquiry->customer->last_name }}</td>
    <td>{{ $enquiry->customer->mobile }}</td>
    <td>{{ $enquiry->model }}</td>
    <td>{{ $enquiry->message }}</td>
  
    <td>{{ $enquiry->created_at }}</td>

    @php
    $status = $enquiry->statushistory->last()?->statusData;
    @endphp

    <td>
        @if ($status)
        <span class="badge" style="background-color: {{ $status->style }}; font-size: 0.8rem; padding: 0.6em 1em;">
            {{ $status->name }}
        </span>
        @else
        N/A
        @endif
    </td>
    <td>
        <div class="hstack gap-3 flex-wrap">

            @can('edit enquiry')
            <a href="{{ route('admin.enquiry.edit', [$enquiry->id]) }}" class="link-success fs-15">
                            <i class="ri-edit-2-line"></i>
            </a>
            @endcan 

            @can('view enquiry')
            <a href="{{ route('admin.enquiry.view', [$enquiry->id]) }}" class="link-success fs-15">
                            <i class="ri-eye-line"></i>
            </a>
            @endcan 

    
            @can('delete enquiry')
              <a href="javascript:void(0);" class="link-danger fs-15 deleteEnquiry" data-id="{{ $enquiry->id }}">
                <i class="ri-delete-bin-line"></i>
            </a>
            @endcan 

        </div>
    </td>
</tr>
@endforeach
@if ($enquiries->hasPages())
<tr>
    <td colspan="2">
        {{ $enquiries->links() }}
    </td>
</tr>
@endif