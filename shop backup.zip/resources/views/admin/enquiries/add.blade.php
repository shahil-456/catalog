@extends('layouts.admin.master')
@section('title')
Add Blog
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Enquiries
@endslot
@endcomponent

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add Enquiry</h4>
            </div>
            <div class="card-body">
                <form id="enquiryForm" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="category_id" class="form-label">Category</label>
                                <select name="category_id" id="category_id" class="form-control">
                                    <option disabled>Select Category</option>
                                    @foreach($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="category_idError"></div>
                            </div>
                        </div>
                        <!-- Title -->
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="brand_id" class="form-label">Brand</label>
                                <select name="brand_id" id="brand_id" class="form-control">
                                    <option disabled>Select Brand</option>
                                    @foreach($brands as $brand)
                                    <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="brand_idError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="first_name" class="form-label">First Name</label>
                                <input type="text" name="first_name" class="form-control"
                                    placeholder="Enter Customer Name" id="first_name">
                                <div class="invalid-feedback" id="first_nameError"></div>
                            </div>
                        </div>
                         <div class="col-6">
                            <div class="mb-3">
                                <label for="first_name" class="form-label">Last Name</label>
                                <input type="text" name="last_name" class="form-control"
                                    placeholder="Enter Last Name" id="first_name">
                                <div class="invalid-feedback" id="first_nameError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Email"
                                    id="email">
                                <div class="invalid-feedback" id="emailError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" placeholder="Enter Phone"
                                    id="phone">
                                <div class="invalid-feedback" id="phoneError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="model" class="form-label">Model</label>
                                <input type="text" name="model" class="form-control" placeholder="Enter Model"
                                    id="model">
                                <div class="invalid-feedback" id="modelError"></div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="mb-3">
                                <label for="message" class="form-label">Message</label>
                                <textarea name="message" class="form-control" placeholder="Enter Message"
                                    id="message"></textarea>
                                <div class="invalid-feedback" id="messageError"></div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="mb-3">
                                <label for="issue" class="form-label">Issue</label>
                                <textarea name="issue" class="form-control" placeholder="Enter Issue"
                                    id="issue"></textarea>
                                <div class="invalid-feedback" id="issueError"></div>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    $(document).ready(function() {
            $('#enquiryForm').on('submit', function(e) {
                e.preventDefault();
                // Clear previous errors
                $('.invalid-feedback').text('');
                $('.form-control').removeClass('is-invalid');

                // Use FormData to handle file upload along with other fields
                let formData = new FormData(this);
                $.ajax({
                    url: "{{ route('admin.enquiry.create') }}",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href = "{{ route('admin.enquiry.list') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (errors) {
                            $.each(errors, function(key, value) {
                                $('#' + key + 'Error').text(value[0]);
                                $('#' + key).addClass('is-invalid');
                            });
                        } else {
                            toastMagic.error("Error!", "An unexpected error occurred.");
                        }
                    }
                });
            });
        });
</script>
@endsection
