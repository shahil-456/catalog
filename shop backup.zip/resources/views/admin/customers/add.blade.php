@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Customers
@endslot
@endcomponent

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Add Customer</h4>
            </div>
            <div class="card-body">
                <form id="customerForm">
                    @csrf
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="firstname" class="form-label">First Name</label>
                                <input type="text" name="firstname" class="form-control" placeholder="Enter First Name"
                                    id="firstname">
                                <div class="invalid-feedback" id="firstnameError"></div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="mb-3">
                                <label for="lastname" class="form-label">Last Name</label>
                                <input type="text" name="lastname" class="form-control" placeholder="Enter Last Name"
                                    id="lastname">
                                <div class="invalid-feedback" id="lastnameError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Email"
                                    id="email">
                                <div class="invalid-feedback" id="emailError"></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div>
                                <label class="form-label">Phone</label>
                                <div class="input-group" data-input-flag>
                                    <button class="btn btn-light border" type="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <img src="{{ URL::asset('material/images/flags/ae.svg') }}" alt="flag img"
                                            height="20" class="country-flagimg rounded">
                                        <span id="country_code" class="ms-2 country-codeno">+ 971</span>
                                        <input type="hidden" name="country_code" value="">
                                    </button>
                                    <input id="mobile" name="mobile" type="text"
                                        class="form-control rounded-end flag-input" value="" placeholder="Enter number"
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    <div class="invalid-feedback" id="phoneError"></div>
                                    <div class="dropdown-menu w-100">
                                        <div class="p-2 px-3 pt-1 searchlist-input">
                                            <input type="text"
                                                class="form-control form-control-sm border search-countryList"
                                                placeholder="Search country name or country code..." />
                                        </div>
                                        <ul class="list-unstyled dropdown-menu-list mb-0"></ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
    .toast-error {
        background: #dc3545 !important;
        /* Bootstrap danger color */
        color: #fff;
    }
</style>

@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{URL::asset('material/js/pages/flag-input.init.js')}}"></script>

<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    $(document).ready(function() {
            $('#customerForm').on('submit', function(e) {
                e.preventDefault();

                // Clear existing validation errors
                $('#firstnameError').text('');
                $('#lastnameError').text('');
                $('#emailError').text('');
                $('#phoneError').text('');

                $('#firstname').removeClass('is-invalid');
                $('#lastname').removeClass('is-invalid');
                $('#email').removeClass('is-invalid');
                $('#mobile').removeClass('is-invalid');


                let formData = {
                    firstname: $('#firstname').val(),
                    lastname: $('#lastname').val(),
                    email: $('#email').val(),
                    mobile: $('#country_code').text().replace('+', '').trim() + $('#mobile').val(),
                    _token: $('input[name="_token"]').val()
                };
                $.ajax({
                    url: "{{ route('admin.customer.create') }}",
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            Toastify({
                                text: response.message,
                                duration: 1000,
                                close: true,
                                className: "success",
                            }).showToast();
                            setTimeout(function() {
                                window.location.href =
                                    "{{ route('admin.customers') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;

                        if (xhr.status === 422) {

                        if (errors.firstname) {
                            $('#firstnameError').text(errors.firstname[0]);
                            $('#firstname').addClass('is-invalid');
                        }
                        if (errors.lastname) {
                            $('#lastnameError').text(errors.lastname[0]);
                            $('#lastname').addClass('is-invalid');
                        }
                        if (errors.email) {
                            $('#emailError').text(errors.email[0]);
                            $('#email').addClass('is-invalid');
                        }
                        if (errors.mobile) {
                            $('#phoneError').text(errors.mobile[0]);
                            $('#mobile').addClass('is-invalid');
                        }
                        }


                    }
                });
            });
        });
</script>
@endsection
