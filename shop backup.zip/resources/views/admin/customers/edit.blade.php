@extends('layouts.admin.master')
@section('title')
@lang('translation.analytics')
@endsection
@section('css')
<link href="{{ URL::asset('material/libs/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet">
@endsection
@section('content')
@component('admin.components.breadcrumb')
@slot('li_1')
Dashboards
@endslot
@slot('title')
Customers
@endslot
@endcomponent
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Update Customer</h4>
            </div>
            <div class="card-body">
                <form id="customerForm">
                    @csrf
                    <input type="hidden" id="customerId" value="{{ $customer->id }}">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Firstname</label>
                                <input type="text" name="firstname" class="form-control"
                                    value="{{ $customer->first_name }}" placeholder="Enter Firstname" id="firstname">
                                <div class="invalid-feedback" id="firstnameError"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Lastname</label>
                                <input type="text" name="lastname" class="form-control"
                                    value="{{ $customer->last_name }}" placeholder="Enter Lastname" id="lastname">
                                <div class="invalid-feedback" id="lastnameError"></div>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" value="{{ $customer->email }}"
                                    placeholder="Enter Email" id="email">
                                <div class="invalid-feedback" id="emailError"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <div class="input-group">
                                    <input type="text" name="phone" class="form-control" placeholder="Enter Phone"
                                        id="phone" value="{{ $customer->mobile }} ">
                                    <div class="invalid-feedback" id="phoneError"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
    .toast-error {
        background: #dc3545 !important;
        /* Bootstrap danger color */
        color: #fff;
    }
</style>
@endsection
@section('script')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="{{ URL::asset('material/js/app.js') }}"></script>
<script>
    $(document).ready(function() {
            $('#customerForm').on('submit', function(e) {
                e.preventDefault();
                $('#firstnameError').text('');
                $('#lastnameError').text('');
                $('#emailError').text('');
                $('#phoneError').text('');
                $('#firstname').removeClass('is-invalid');
                $('#lastname').removeClass('is-invalid');
                $('#email').removeClass('is-invalid');
                $('#phone').removeClass('is-invalid');

                let formData = {
                    _token: $('input[name="_token"]').val(),
                    firstname: $('#firstname').val(),
                    lastname: $('#lastname').val(),
                    email: $('#email').val(),
                    mobile: $('#phone').val(),
                };
                let customerId = $('#customerId').val();
                $.ajax({
                     url: "{{ route('admin.customer.update', [':id']) }}".replace(':id', customerId),
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            Toastify({
                                text: response.message,
                                duration: 1000,
                                close: true,
                                className: "success",
                            }).showToast();
                            setTimeout(function() {
                                window.location.href =
                                    "{{ route('admin.customers') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        if (xhr.status === 422) {
                        if (errors.firstname) {
                            $('#firstnameError').text(errors.firstname[0]);
                            $('#firstname').addClass('is-invalid');
                        }
                        if (errors.lastname) {
                            $('#lastnameError').text(errors.lastname[0]);
                            $('#lastname').addClass('is-invalid');
                        }
                        if (errors.email) {
                            $('#emailError').text(errors.email[0]);
                            $('#email').addClass('is-invalid');
                        }
                        if (errors.mobile) {
                            console.log(errors.mobile[0]);
                            $('#phoneError').text(errors.mobile[0]);
                            $('#phone').addClass('is-invalid');
                        }
                        }
                    }

                });
            });
        });
</script>
@endsection
