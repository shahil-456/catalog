@foreach ($blogCategories as $key => $blogCategory)
<tr id="blogCategoryRow{{ $blogCategory->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $blogCategory->name }}</td>
    <td>
        <div class="hstack gap-3 flex-wrap">
            @can('edit blog category')
            <a href="{{ route('admin.blog.category.edit', [$blogCategory->id]) }}" class="link-success fs-15">
                            <i class="ri-edit-2-line"></i>
            </a>
            @endcan 

            @can('delete blog category')
            <a href="javascript:void(0);" class="link-danger fs-15 deleteBlogCategory"
                            data-id="{{ $blogCategory->id }}">
                            <i class="ri-delete-bin-line"></i>
            </a>
            @endcan 
            
        </div>
    </td>
</tr>
@endforeach
@if ($blogCategories->hasPages())
<tr>
    <td colspan="2">
        {{ $blogCategories->links() }}
    </td>
</tr>
@endif
