@foreach ($categories as $key => $category)


<tr id="categoryRow{{ $category->id }}" class="odd:bg-white even:bg-gray-100 dark:odd:bg-slate-700 dark:even:bg-slate-800">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$key+1}}</td>

<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$category->name}}</td>

<td class="px-6 py-4 whitespace-nowrap text-end text-sm font-medium">

<div class="flex space-x-3">
  <a href="{{ route('admin.category.edit', [$category->id]) }}"><i data-feather="edit-2" class="text-blue-600 w-4"></i></a>
    <a href="javascript:void(0);" class="link-danger fs-15 deleteCategory" data-id="{{ $category->id }}"> <i data-feather="trash-2" class="text-red-600 w-4"></i></a>
</div>

</td>
</tr>

@endforeach







