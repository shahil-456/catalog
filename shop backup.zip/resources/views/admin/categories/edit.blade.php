@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')

  <link href="{{ URL::to('knorix/assets/libs/quill/quill.core.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ URL::to('knorix/assets/libs/quill/quill.snow.css') }}" rel="stylesheet" type="text/css">



    
            <div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Add Category</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>


                        <div class="p-6">

                        <form class="valid-form grid lg:grid-cols-2 gap-2" id="productForm" enctype="multipart/form-data">
                            @csrf
                        <input type="hidden" id="catId" value="{{ $category->id }}">

                           
                        <div class="form-group">
                            <label for="validationDefault01" class="text-gray-800 text-sm font-medium inline-block mb-2">Name</label>
                            <input value="{{ $category->name }}" name="name" type="text" class="form-input" id="validationDefault01">
                        </div>

                        <div class="form-group">

                        <div name="description" id="snow-editor" style="height: 300px;">
                             
                        {!! $category->description !!}
                            </div>       

                        </div>

                                   <div class="col-span-2">
                                <button class="btn bg-primary text-white" type="submit">Submit</button>
                            </div>
                        </form>

                       


                        
                        </div>
                    </div>

                    
                </div>

        

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/pristinejs/dist/pristine.min.js"></script>



 <script src="{{ URL::to('knorix/assets/libs/quill/quill.min.js') }}"></script>
    <script src="{{ URL::to('knorix/assets/js/pages/form-editor.js') }}"></script>




    <script>
        
    $(document).ready(function() {
        var form = document.getElementById("productForm");
        var pristine = new Pristine(form);

        $('#productForm').on('submit', function(e) {
            e.preventDefault();

            // reset pristine errors
            pristine.reset();

            let formData = new FormData(this);

            let desc = document.querySelector('#snow-editor .ql-editor').innerHTML;
            formData.append('description', desc);
            let catId = $('#catId').val();

            
            $.ajax({
                url: "{{ route('admin.category.update', ':id') }}".replace(':id', catId),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Operation completed successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        $('#productForm')[0].reset();
                    }
                },
               error: function(xhr) {
            let errors = xhr.responseJSON.errors;

            // Clear previous errors
            $('.error-text').remove();
            $('input, select, textarea').removeClass('border-red-500');

            // Loop through Laravel validation errors
            $.each(errors, function(field, messages) {
                let input = $('[name="'+field+'"]');

                // Add red border
                input.addClass('border-red-500');

                // Append error message
                input.after('<small class="error-text text-red-500">'+messages[0]+'</small>');
            });
        }

            });
        });
    });
</script>



@endsection


@section('script')





@endsection


