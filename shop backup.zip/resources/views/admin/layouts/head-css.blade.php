@yield('css')
<!-- Layout config Js -->
<script src="{{ URL::to('material/js/layout.js') }}"></script>
<!-- Bootstrap Css -->
<link href="{{ URL::to('material/css/bootstrap.min.css') }}"  rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{ URL::to('material/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="{{ URL::to('material/css/app.min.css') }}"  rel="stylesheet" type="text/css" />
<!-- custom Css-->
<link href="{{ URL::to('material/css/custom.min.css') }}"  rel="stylesheet" type="text/css" />
{{-- @yield('css') --}}
