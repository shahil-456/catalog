@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    
  

<div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">User Details</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>


                <div class="p-6">
                <div class="max-w-xl mx-auto shadow rounded-2xl p-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    
                <div class="p-4 border rounded-lg ">
                    <span class="font-semibold ">Name:</span>
                    <span class="ml-2 ">{{ $user->first_name.' '.$user->last_name }}</span>
                </div>

            <div class="p-4 border rounded-lg ">
                <span class="font-semibold ">Email:</span>
                <span class="ml-2 ">{{ $user->email }}</span>
            </div>

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Username:</span>
            <span class="ml-2 ">{{ $user->username }}</span>
        </div>

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Role:</span>
            <span class="ml-2 ">{{ $user->role->name ?? 'N/A' }}</span>
        </div>

        <div class="p-4 border rounded-lg">
            <span class="font-semibold ">Created At:</span>
            <span class="ml-2 ">{{ $user->created_at->format('d M Y') }}</span>
        </div>
    </div>

            <div>
                <span class="font-semibold">Profile Photo:</span><br>
                <img src="{{ asset($user->profile_photo) }}" 
                    alt="Profile Photo" 
                    class="w-24 h-24 rounded-full object-cover mt-2">
            </div>

             <div class="mt-6 flex gap-3">
                    <a href="{{ route('admin.users') }}" class="px-4 py-2 bg-gray-600 text-white rounded-lg">Back</a>
                    <a href="{{ route('admin.user.edit', $user->id) }}" class="px-4 py-2 bg-blue-600 text-white rounded-lg">Edit</a>
                </div>

                          

                           

                        
                        </div>
                    </div>

                    
                </div>
                </div>

               


@endsection




