@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    
  <div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Edit User</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>


                        <div class="p-6">

                        <form class="valid-form grid lg:grid-cols-2 gap-2" id="userForm" enctype="multipart/form-data">
                            @csrf
                        <input type="hidden" id="userId" value="{{ $user->id }}">

                            <div class="form-group">
                            <label for="validationDefault01" class="text-gray-800 text-sm font-medium inline-block mb-2">First name</label>
                            <input value="{{$user->first_name}}" name="first_name" type="text" class="form-input" id="validationDefault01">
                        </div>


                            <div class="form-group">
                                <label for="validationDefault02" class="text-gray-800 text-sm font-medium inline-block mb-2">Last name</label>
                                <input value="{{$user->last_name}}" name="last_name" type="text" class="form-input" id="validationDefault02" required>
                            </div>

                             <div class="form-group">
                                    <label for="inputEmail4" class="text-gray-800 text-sm font-medium inline-block mb-2">Email</label>
                                    <input value="{{$user->email}}" name="email" type="email" class="form-input" id="inputEmail4" required>
                            </div>

                            <div class="form-group">
                                <label for="inputUsername" class="text-gray-800 text-sm font-medium inline-block mb-2">Username</label>
                                <input value="{{$user->username}}" type="text" class="form-input" id="inputUsername" name="username" required>
                            </div>

                            


                            <div class="form-group">
                                <label for="inputPhone" class="text-gray-800 text-sm font-medium inline-block mb-2">Phone</label>
                                <input value="{{$user->phone}}" type="text" class=" form-input" id="inputPhone" name="phone" required>
                            </div>

                            <div class="form-group">
                                <label for="inputPhoto" class="text-gray-800 text-sm font-medium inline-block mb-2">Profile Photo</label>
                                <input type="file" class="form-input" id="inputPhoto" name="photo" accept="image/*">
                            </div>

                            <img src="{{ asset($user->profile_photo) }}" width="150" alt="User Photo">

 
                            
                                   <div class="col-span-2">
                                <button class="btn bg-primary text-white" type="submit">Update</button>
                            </div>
                        </form>

                       
                           

                        
                        </div>
                    </div>

                    
                </div>

                <script src="{{ URL::to('knorix/assets/libs/pristinejs/pristine.min.js') }}"></script>
            <script src="{{ URL::to('knorix/assets/js/pages/form-validation.js') }}"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    $(document).ready(function() {
        var form = document.getElementById("userForm");
        var pristine = new Pristine(form);

        $('#userForm').on('submit', function(e) {
            e.preventDefault();

            // reset pristine errors
            pristine.reset();

            let formData = new FormData(this);
            let userId = $('#userId').val();

            $.ajax({
                url: "{{ route('admin.user.update', ':id') }}".replace(':id', userId),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Operation completed successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        $('#userForm')[0].reset();
                    }
                },
               error: function(xhr) {
            let errors = xhr.responseJSON.errors;

            // Clear previous errors
            $('.error-text').remove();
            $('input, select, textarea').removeClass('border-red-500');

            // Loop through Laravel validation errors
            $.each(errors, function(field, messages) {
                let input = $('[name="'+field+'"]');

                // Add red border
                input.addClass('border-red-500');

                // Append error message
                input.after('<small class="error-text text-red-500">'+messages[0]+'</small>');
            });
        }

            });
        });
    });
</script>



@endsection


@section('script')





@endsection


