@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')

 <link href="{{ URL::to('knorix/assets/libs/quill/quill.core.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ URL::to('knorix/assets/libs/quill/quill.snow.css') }}" rel="stylesheet" type="text/css">
    
  <div class="flex flex-col gap-6">
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h4 class="card-title">Add User</h4>
                                <div class="flex items-center gap-2">
                                  
                                </div>
                            </div>
                        </div>


                        <div class="p-6">

                        <form class="valid-form grid lg:grid-cols-2 gap-2" id="userForm" enctype="multipart/form-data">
                            @csrf

                            {{-- <div class="form-group">
                                <label for="validationDefault01" class="text-gray-800 text-sm font-medium inline-block mb-2">First name</label>
                                <input name="first_name" type="text" class="form-input" id="validationDefault01"  required>
                            </div> --}}

                            <div class="form-group">
                            <label for="validationDefault01" class="text-gray-800 text-sm font-medium inline-block mb-2">First name</label>
                            <input name="first_name" type="text" class="form-input" id="validationDefault01">
                        </div>


                            <div class="form-group">
                                <label for="validationDefault02" class="text-gray-800 text-sm font-medium inline-block mb-2">Last name</label>
                                <input name="last_name" type="text" class="form-input" id="validationDefault02" required>
                            </div>

                            <div class="form-group">
                                <label for="inputUsername" class="text-gray-800 text-sm font-medium inline-block mb-2">Username</label>
                                <input type="text" class="form-input" id="inputUsername" name="username" required>
                            </div>

                             <div class="form-group">
                                    <label for="inputEmail4" class="text-gray-800 text-sm font-medium inline-block mb-2">Email</label>
                                    <input name="email" type="email" class="form-input" id="inputEmail4" required>
                            </div>

                            

                            <div class="form-group">
                                <label for="inputPassword" class="text-gray-800 text-sm font-medium inline-block mb-2">Password</label>
                                <input type="password" class="form-input" id="inputPassword" name="password" required>
                            </div>

                            <div class="form-group">
                                <label for="inputConfirmPassword" class="text-gray-800 text-sm font-medium inline-block mb-2">Confirm Password</label>
                                <input required type="password" class="form-input" id="inputConfirmPassword" name="password_confirmation" required>
                            </div>


                            <div class="form-group">
                                <label for="inputPhone" class="text-gray-800 text-sm font-medium inline-block mb-2">Phone</label>
                                <input type="text" class=" form-input" id="inputPhone" name="phone" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="inputPhoto" class="text-gray-800 text-sm font-medium inline-block mb-2">Profile Photo</label>
                                <input type="file" class="form-input" id="inputPhoto" name="photo" accept="image/*">
                            </div>

 
                            {{-- <div>
                                <label for="validationDefault03" class="text-gray-800 text-sm font-medium inline-block mb-2">Email</label>
                                <input type="email" class="form-input" id="validationDefault03" value="mark.otto@email.com">
                            </div>
                            --}}
                                   <div class="col-span-2">
                                <button class="btn bg-primary text-white" type="submit">Submit</button>
                            </div>
                        </form>

                       

                            {{-- <form class="valid-form grid lg:grid-cols-3 gap-6">
                               
                                <button class="btn bg-primary text-white" type="submit">Submit form</button>

                            </form> --}}

                           

                        
                        </div>
                    </div>

                    
                </div>

                 <script src="{{ URL::to('knorix/assets/libs/quill/quill.min.js') }}"></script>
                <script src="{{ URL::to('knorix/assets/js/pages/form-editor.js') }}"></script>


                <script src="{{ URL::to('knorix/assets/libs/pristinejs/pristine.min.js') }}"></script>
            <script src="{{ URL::to('knorix/assets/js/pages/form-validation.js') }}"></script>

            

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/pristinejs/dist/pristine.min.js"></script>
    <script>
    $(document).ready(function() {
        var form = document.getElementById("userForm");
        var pristine = new Pristine(form);

        $('#userForm').on('submit', function(e) {
            e.preventDefault();

            // reset pristine errors
            pristine.reset();

            let formData = new FormData(this);

            $.ajax({
                url: "{{ route('admin.user.create') }}",
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Operation completed successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        $('#userForm')[0].reset();
                    }
                },
               error: function(xhr) {
            let errors = xhr.responseJSON.errors;

            // Clear previous errors
            $('.error-text').remove();
            $('input, select, textarea').removeClass('border-red-500');

            // Loop through Laravel validation errors
            $.each(errors, function(field, messages) {
                let input = $('[name="'+field+'"]');

                // Add red border
                input.addClass('border-red-500');

                // Append error message
                input.after('<small class="error-text text-red-500">'+messages[0]+'</small>');
            });
        }

            });
        });
    });
</script>



@endsection


@section('script')





@endsection


