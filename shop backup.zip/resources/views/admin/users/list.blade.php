@foreach ($users as $key => $user)


<tr id="userRow{{ $user->id }}" class="odd:bg-white even:bg-gray-100 dark:odd:bg-slate-700 dark:even:bg-slate-800">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$key+1}}</td>

<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{{$user->first_name.' '.$user->last_name}}</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$user->username}}</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$user->email}}</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200"> {{$user->phone}}</td>

<td class="px-6 py-4 whitespace-nowrap text-end text-sm font-medium">

<div class="flex space-x-3">
  <a href="{{ route('admin.user.view', [$user->id]) }}"><i data-feather="eye" class="text-green-600 w-4"></i></a>
  <a href="{{ route('admin.user.edit', [$user->id]) }}"><i data-feather="edit-2" class="text-blue-600 w-4"></i></a>
    <a href="javascript:void(0);" class="link-danger fs-15 deleteUser" data-id="{{ $user->id }}"> <i data-feather="trash-2" class="text-red-600 w-4"></i></a>
</div>

</td>
</tr>

@endforeach







