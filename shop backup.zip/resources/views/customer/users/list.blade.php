@foreach ($users as $key => $user)
<tr id="roleRow{{ $user->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $user->first_name.' '.$user->last_name }}</td>
    <td>{{ $user->email }}</td>
    <td>{{ $user->mobile }}</td>
    <td>{{ $user->roles->first()?->name ?? 'No Role Assigned' }}</td>
    <td>{{ $user->status == 1 ? 'Active' : 'Inactive' }}</td>
    <td>{{ $user->created_at->format('Y-m-d h:i A') }}</td>

    <td>
        <div class="hstack gap-3 flex-wrap">
        @can('edit user')
        <a href="{{ route('user.user.edit', [$user->id]) }}" class="link-success fs-15">
            <i class="ri-edit-2-line"></i>
        </a>
        @endcan

        @can('delete user')
        <a href="javascript:void(0);" class="link-danger fs-15 deleteUser" data-id="{{ $user->id }}">
            <i class="ri-delete-bin-line"></i>
        </a>
        @endcan

        </div>
    </td>
</tr>
@endforeach
@if ($users->hasPages())
<tr>
    <td colspan="4">
        {{ $users->links() }}
    </td>
</tr>
@endif
