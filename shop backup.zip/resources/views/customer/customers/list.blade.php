@foreach ($customers as $key => $customer)
<tr id="roleRow{{ $customer->id }}">
    <td>{{ $key + 1 }}</td>
    <td>{{ $customer->first_name.' '.$customer->last_name }}</td>
    <td>{{ $customer->email }}</td>
    <td>{{ $customer->mobile }}</td>
    <td>{{ $customer->created_at->format('Y-m-d h:i A') }}</td>
    <td>
        <div class="hstack gap-3 flex-wrap">
            @can('edit customer')
            <a href="{{ route('user.customer.edit', [$customer->id]) }}" class="link-success fs-15">
                <i class="ri-edit-2-line"></i>
            </a>
            @endcan
            @can('delete customer')
            <a href="javascript:void(0);" class="link-danger fs-15 deleteCustomer" data-id="{{ $customer->id }}">
                <i class="ri-delete-bin-line"></i>
            </a>
            @endcan
        </div>
    </td>
</tr>
@endforeach
@if ($customers->hasPages())
<tr>
    <td colspan="4">
        {{ $customers->links() }}
    </td>
</tr>
@endif
