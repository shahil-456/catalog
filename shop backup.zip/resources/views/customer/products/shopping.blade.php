@extends('customer.layouts.app')

@section('title', 'Dashboard')

@section('content')



<form class="valid-form grid lg:grid-cols-2 gap-2" id="userForm" enctype="multipart/form-data">
                            @csrf
 <div class="form-group">
        <input id="search" name="search" type="text" placeholder="search for products" class="form-input" id="validationDefault01">
                        </div>

</form>                     

<div class="grid lg:grid-cols-4 gap-6 h-30">

        
  
  @foreach ($products as $key => $product)

<div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <img class="p-4 rounded-t-lg" src="{{ asset($product->image) }}" alt="product image" />
    </a>
    <div class="px-5 pb-5">
        <a href="#">
            <h5 class="text-xl font-semibold tracking-tight text-gray-900 dark:text-white">{{$product->name}}</h5>
            <p>{{$product->category->name}}</p>
        </a>
        <div class="flex items-center mt-2.5 mb-5">
            <div class="flex items-center space-x-1 rtl:space-x-reverse">
               
                
            </div>
        </div>
        <br>
        <div class="flex items-center justify-between">
            <span class="text-3xl font-bold text-gray-900 dark:text-white">{{ currencySymbol() }}{{$product->price}}</span>
            
            <a href="{{ route('customer.product.view', [$product->id]) }}" >
            <button type="button" class="btn bg-primary text-white">Details</button></a>
        </div>
<br>
        
    <div class="">

                 <p>  Stock: {{$product->stock}}</p>
                 <br>

            <a href="{{ route('customer.product.addCart', [$product->id]) }}" >
      <span class="btn bg-primary text-white rounded-lg">
          <i data-feather="shopping-cart"></i>
      </span>
            </a>
        </div>



    </div>
</div>



  

@endforeach
            {{ $products->links('vendor.pagination.custom') }}


</div>
                



<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
             <script>
    $(document).ready(function() {
        
            // Handle the delete button click
            
            $('#search').on('keyup', function() {
                let searchQuery = $(this).val();
                loadProducts(searchQuery);
            });

            function loadProducts(searchQuery = '') {
                $.ajax({
                    url: "{{ route('customer.products') }}",
                    type: 'GET',
                    data: {
                        search: searchQuery
                    },
                    success: function(response) {
                       
                    },
                    error: function(xhr) {
                       
                    }
                });
        }


        });
</script>

@endsection
