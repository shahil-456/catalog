@extends('customer.layouts.app')

@section('title', 'Dashboard')

@section('content')


<div class="overflow-x-auto">
    <table class="min-w-full border border-gray-200 rounded-lg shadow-sm dark:border-gray-700">
        <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Image</th>
                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Name</th>
                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Category</th>
                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Price</th>
                 <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Quantity</th>
                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700 dark:text-gray-200">Action</th>
            </tr>
        </thead>
        <form method="POST"enctype="multipart/form-data" action="{{route('customer.product.order')}}">

            @csrf

       <tbody class="divide-y divide-gray-200 dark:divide-gray-600">
        @php $total = 0; @endphp
        @foreach ($carts as $key => $cart)
            @php $total += $cart->product->price; @endphp
            <tr class="bg-white dark:bg-gray-800">
                <td class="px-4 py-2">
                    <img src="{{ asset($cart->product->image) }}" alt="product image" class="w-16 h-16 rounded">
                </td>
                <td class="px-4 py-2 text-gray-900 dark:text-white font-medium">
                    {{ $cart->product->name }}
                </td>
                <td class="px-4 py-2 text-gray-600 dark:text-gray-300">
                    {{ $cart->product->category->name }}
                </td>
                <td class="px-4 py-2 text-gray-900 dark:text-white font-semibold">
                    {{ currencySymbol() }}{{ $cart->product->price }}
                </td>
                <td class="px-4 py-2 text-gray-900 dark:text-white font-semibold">
                    <input name="product_id[]" value="{{ $cart->product_id }}" type="hidden" step="1" class="form-input w-20">

                    <input name="quantity[]" value="1" type="number" step="1" class="form-input w-20">
                </td>
                <td class="px-4 py-2">
                    <div class="flex items-center gap-2">
                        <a href="{{ route('customer.product.view', [$cart->product->id]) }}" 
                        class="btn bg-primary text-white px-3 py-1 rounded-lg text-sm">
                            Details
                        </a>
                        <a href="{{ route('customer.product.addCart', [$cart->id]) }}" 
                        class="btn bg-red-600 text-white px-3 py-1 rounded-lg text-sm flex items-center gap-1">
                            <i data-feather="trash-2" class="w-4 h-4"></i>
                            Remove
                        </a>
                    </div>
                </td>
            </tr>
        @endforeach

        <tr class="bg-gray-100 dark:bg-gray-700 font-bold">
            <td colspan="3" class="px-4 py-3 text-right text-gray-900 dark:text-white">Total</td>
            <td colspan="2" class="px-4 py-3 text-gray-900 dark:text-white">
                {{ currencySymbol() }}{{ $total }}
            </td>

            

            <td colspan="3" class="px-4 py-3 text-gray-900 dark:text-white">
               <button type="submit"  
                        class="btn bg-primary text-white px-3 py-1 rounded-lg text-sm">
                    Place Order
             </button>
            </td>
        </tr>

    </tbody>
        </form>


    </table>
</div>



         <br>       



<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
             <script>
    $(document).ready(function() {
        
            // Handle the delete button click
            $('.deleteCart').on('click', function() {
                var cartId = $(this).data('id');
                var token = $('meta[name="csrf-token"]').attr(
                    'content');

                if (confirm("Are you sure you want to delete this product?")) {
                    $.ajax({
                    url: "{{ route('customer.cart.delete', [':id']) }}".replace(':id', cartId),
                    type: 'POST',
                    data: {
                        _token: token,
                        _method: 'DELETE'
                    },
                    
                    success: function(response) {

                        $('#productRow' + cartId).remove();

                        if (response.success) {
                           Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message ?? 'Deleted successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                            $('#productRow' + cartId).remove();
                        }
                    },
                    error: function(xhr) {
                       
                    }
                });

                }
            });

            



        });
</script>

@endsection
