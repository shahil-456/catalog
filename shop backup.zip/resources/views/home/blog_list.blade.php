@extends('home.layouts.default')
@section('content')

<style>
    .pagination1 {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        padding-left: 0;
        list-style: none;
        border-radius: 0.25rem;
    }

    input[type="submit"] {
        color: #fff;
        border: 1px solid #c20010;
        -webkit-border-radius: 25px;
        -moz-border-radius: 25px;
        border-radius: 10px;
        font-weight: 600;
        text-transform: capitalize;
        padding: 10px 35px;
        font-size: 13px;
        text-transform: uppercase;
        background: #c20010;
        text-align: center;
    }

    .post-img img {
        width: 100%;
    }

    .date {
        font-size: 12px;
        color: #778291;
    }

    .post-desc a {
        line-height: 1.3;
        float: left;
    }

    .recent-post-widget.no-border {
        background: #e6e6e659;
        padding: 9px;
    }

    .pagination1 {
        display: inline;
        /* Use flexbox to make items align horizontally */
        list-style: none;
        /* Remove default list styles */
        padding: 0;
        margin: 20px 0;
    }

    .pagination1 ul li {
        display: inline-block;
    }

    .pagination1 li {
        margin-right: 10px;
        /* Add some space between each item */
    }

    .pagination1 li:last-child {
        margin-right: 0;
        /* Remove margin for the last item to prevent extra space */
    }

    .pagination1 li a {
        display: inline-block;
        /* Display links as inline-block to align them horizontally */
        padding: 5px 10px;
        text-decoration: none;
        background-color: #c20010;
        color: #fff;
        border-radius: 3px;
    }

    .pagination1 li.active a {
        background-color: #c20010;
    }

    .pagination1 li.disabled a {
        opacity: 0.5;
        pointer-events: none;
    }
</style>
<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg', ['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">Blogs</h2>
        </div>
    </div>
</section>
<section class="feature-one mt-5">
    <div class="container">
        <div class="row align-items-center gy-4 gy-lg-0">
            @foreach ($blogs as $blog)
            <div class="col-md-4">
                <div class="recent-post-widget no-border mb-3">
                    <div class="post-img">
                        <a href="{{ route('home.blogs.detail',['slug'=>$blog->slug]) }}">
                            <picture>
                                <source
                                    srcset="{{ secure_image_url('images/blogs/' . $blog->image, ['source'=>'storage','format' => 'webp','grayscale' => false,    'quality'=>20]) }}"
                                    type="image/webp">
                                <img src="{{ secure_image_url('images/blogs/' . $blog->image, ['source'=>'storage','format' => 'jpg','grayscale' => false,   'quality'=>20]) }}"
                                    alt="Blog Image">
                            </picture>
                        </a>
                    </div>
                    <div class="post-desc">
                        <a href="{{ route('home.blogs.detail',['slug'=>$blog->slug]) }}">{{ $blog->title }}</a>
                        <span class="date">
                            <i class="fa fa-calendar"></i>
                            {{ \Carbon\Carbon::parse($blog->created_at)->format('F d, Y') }}</span>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        <div class="col-12 text-center mt-50 mb-50">
            {!! $blogs->links() !!}
        </div>
    </div>
</section>
@stop
