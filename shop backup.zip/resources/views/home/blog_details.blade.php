@extends('home.layouts.default')
@section('content')
<style>
    .post-img img {
        width: 100%;
    }

    .blogs-img img {
        width: 100%;
    }


    .date {
        font-size: 12px;
        color: #778291;
    }

    .post-desc a {
        line-height: 1.3;
        float: left;
    }
</style>

<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg', ['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">Blogs</h2>
        </div>
    </div>
</section>
<section class="feature-one mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 order-last">
                <div class="widget-area">
                    <div class="recent-posts mb-50">
                        <div class="widget-title">
                            <h6 class="title pb-2">Latest News</h6>
                        </div>
                        @foreach ($blogs as $blog_detail)
                        <div class="recent-post-widget  no-border pb-3">
                            <div class="post-img">
                                <a href="{{ route('home.blogs.detail', $blog_detail->slug) }}">
                                    <picture>
                                        <source
                                            srcset="{{ secure_image_url('images/blogs/' . $blog_detail->image, ['source'=>'storage','format' => 'webp','grayscale' => false,  'quality'=>20]) }}"
                                            type="image/webp">
                                        <img src="{{ secure_image_url('images/blogs/' . $blog_detail->image, ['source'=>'storage','format' => 'jpg','grayscale' => false,  'quality'=>20]) }}"
                                            alt="Blog Image">
                                    </picture>
                                </a>
                            </div>
                            <div class="post-desc">
                                <a href="{{ route('home.blogs.detail', $blog_detail->slug) }}">{{ $blog_detail->title }}</a>
                                <span class="date">
                                    <i class="fa fa-calendar"></i>
                                    {{ \Carbon\Carbon::parse($blog_detail->created_at)->format('F d, Y') }}</span>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="col-lg-9 pr-35 md-pr-15">
                <p style="text-align: justify; " class="blogs-img">
                    <picture>
                        <source
                            srcset="{{ secure_image_url('images/blogs/' . $blog->image, ['source'=>'storage','format' => 'webp','grayscale' => false]) }}"
                            type="image/webp">
                        <img src="{{ secure_image_url('images/blogs/' . $blog->image, ['source'=>'storage','format' => 'jpg','grayscale' => false]) }}"
                            alt="Blog Image">
                    </picture>
                </p>
                <h1 class="page-title new-title pb-10" style="font-size:24px">{{ $blog->title }}</h1>
                {!! $blog->description !!}
            </div>
        </div>
</section>
<script>
    window.addEventListener('load', () => {
        document.querySelectorAll('img.lazy-replace').forEach(img => {
            const actual = img.getAttribute('data-src');
            if (actual) {
                img.src = actual;
            }
        });
    });
</script>
@stop
