@extends('home.layouts.default')
@section('content')

<section class="banner-1 bg_img  ">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <img src="{{ secure_image_url('assets/images/home/banner-b.png', ['source'=>'public','format' => 'webp','grayscale' => false]) }}"
                    alt="banner" class="img-fluid" title="Banner">
            </div>
            <div class="col-lg-6">
                <div class="banner-content-1 cl-white">
                    <h1 class="title" style="font-size:45px;text-transform:Capitalize">We make Gadgets Repair
                        hassle-free for you</h1>
                    <p>
                        Our service is not only about fixing – it's more about making your device like new again.
                    </p>
                    <a href="{{ route('home.services.detail') }}" class="service-btn">Book Your Service Now</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="amazing-feature-section" id="feature">
    <div class="topper-feature oh padding-top padding-bottom">
        <div class="container">
            <div class="row mb-3">
                <div class="col-lg-12">
                    <div class="left-style mb-lg-0   pos-rel text-center">
                        <h2 class="title">What would you like to Repair?</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                @foreach ($home_categories as $category)
                <div class="col-lg-4 device-card">
                    <a href="{{ route('home.category.services.detail', $category->slug) }}"
                        class="dc_inner_img shadow bg-color3">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 v-aligh">
                                <div class="dc_img">
                                    <h2 style="font-size: 24px;
                                        line-height: 23px;
                                        margin-top: -9px; ">{{ $category->name }}<br>
                                        <small>Repair</small>
                                    </h2>
                                    <i class="fa fa-arrow-right"></i>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                <div class="dc_img">
                                    <picture>
                                        <source
                                            srcset="{{ secure_image_url('images/categories/' . $category->image, ['source'=>'storage','format' => 'webp','grayscale' => false]) }}"
                                            type="image/webp">
                                        <img src="{{ secure_image_url('images/categories/' . $category->image, ['source'=>'storage','format' => 'jpg','grayscale' => false]) }}"
                                            class="img-fluid" alt="{{ $category->name }} Repair">
                                    </picture>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
<section class="how-section padding-bottom padding-top light-red home-tab" id="how">
    <div class="container">
        <div class="section-header">

            <h2 class="title">Let’s See How It Work</h2>
            <p>It's easier than you think.Follow 4 simple easy steps</p>
        </div>
        <div class="text-center how d-flex justify-content-center">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" role="tab" aria-controls="home"
                        aria-selected="true">Repair Online</a>
                </li>
            </ul>
        </div>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">




                <div class="row mb-40-none">
                    <div class="col-lg-3 col-sm-6 col-xl-3">
                        <div class="how-item">
                            <div class="how-thumb">
                                <img src="assets/images/icon/how-1.png" alt="book_repair" title="book_repair">
                            </div>
                            <div class="how-content">

                                <h3 class="title" style="font-size: 24px;
    line-height: 23px;
    margin-top: -9px;">Book Your Repair</h3>
                                <p>View prices upfront and book repair online. Pay by Card or Choose Cash on Delivery.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xl-3">
                        <div class="how-item">
                            <div class="how-thumb">
                                <img src="assets/images/icon/how-2.png" alt="free_pickup" title="free_pickup">
                            </div>
                            <div class="how-content">

                                <h3 class="title" style="font-size: 24px;
    line-height: 23px;
    margin-top: -9px;">Free Pickup</h3>
                                <p>Relax while our executives pick the device from your place.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xl-3">
                        <div class="how-item">
                            <div class="how-thumb">
                                <img src="assets/images/icon/how-3.png" alt="diagnosis_repair" title="diagnosis_repa">
                            </div>
                            <div class="how-content">

                                <h3 class="title" style="font-size: 24px;
    line-height: 23px;
    margin-top: -9px;">Diagnosis &amp; Repair</h3>
                                <p>Get a 30 point quality check report on your mail while your device is repaired.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xl-3">
                        <div class="how-item">
                            <div class="how-thumb">
                                <img src="assets/images/icon/how-4.png" alt="receive_pay" title="receive_pay">
                            </div>
                            <div class="how-content">

                                <h3 class="title" style="font-size: 24px;
    line-height: 23px;
    margin-top: -9px;">Receive &amp; Pay</h3>
                                <p>Receive the device at your place and pay.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<section class="newslater-section oh bg_img pos-rel">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 d-none d-lg-block">
                <div class="subscribe-thumb-2">
                    <img src="assets/images/home/man-hold.webp" class="img-fluid" alt="newslater" title="newslater">
                </div>
            </div>
            

        </div>
    </div>
</section>




<section class="testimonial-feature bg_img pb-xl-0 padding-bottom">
    <div class="oh pos-rel padding-top padding-bottom">

        <div class="container">

            <div class="section-header">

                <h5 class="title">Our Clients Speak</h5>
                <p>We have been working with clients around the world</p>
            </div>

            <div class="row align-items-center">

                <div class="col-lg-12">
                    <div class="client-slider owl-carousel owl-theme">
                        <div class="client-item">
                            <div class="client-content">
                                <h5 style="font-weight:normal">Freddie</h5>
                                <p>
                                    One of the best tech-support in Dubai. They indeed have a strong team of very
                                    professional technicians. Got my phone repaired within hours and that too back to
                                    normal. I am surely going to visit them next time if God forbid, any of my devices
                                    go down.
                                </p>
                                <div class="rating">
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star-half-alt"></i>
                                    </span>
                                </div>
                            </div>

                        </div>
                        <div class="client-item">
                            <div class="client-content">
                                <h5 style="font-weight:normal">George</h5>
                                <p>
                                    Thank you Just Repair for a service that was fast, quick and lasting. Now my laptop
                                    is rendering just the way it used to be. Will recommend it to anybody I know.
                                </p>
                                <div class="rating">
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star-half-alt"></i>
                                    </span>
                                </div>
                            </div>

                        </div>
                        <div class="client-item">
                            <div class="client-content">
                                <h5 style="font-weight:normal">Kamran Malik</h5>
                                <p>
                                    I had a major issue with my Macbook Air motherboard and on contacting Apple they had
                                    charted a costly 1400 AED motherboard change. It's just my great luck to have
                                    contacted Just Repair who did it within 2 days. It was indeed the best decision of
                                    my life. So I would strongly refer you to these guys for any Macbook issues. They
                                    are professional, trustworthy and always available.
                                </p>
                                <div class="rating">
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star-half-alt"></i>
                                    </span>
                                </div>
                            </div>

                        </div>

                        <div class="client-item">
                            <div class="client-content">
                                <h5 style="font-weight:normal">Mahesh Narayanan</h5>
                                <p>
                                    First quality service in Dubai ! I had an issue with my Printers. Needed to replace
                                    the internal parts the company technician had said. I found Just Repair online and
                                    then made the payment and scheduled a pickup the next day. They arrived exactly on
                                    time and within hours they gave me my printer all good and going. Such a hassle free
                                    and delightful service they provide. Thank you, Just Repair .

                                </p>
                                <div class="rating">
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span>
                                        <i class="fas fa-star-half-alt"></i>
                                    </span>
                                </div>
                            </div>

                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@stop
