<!doctype html>
<html>

<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @include('home.includes.head')
</head>

<body class="hb-homepage hb-overxhidden ">
    <a href="#0" class="scrollToTop"><i class="fas fa-angle-up"></i></a>
    <div class="overlay"></div>
    <header class="hb-header">
        @include('home.includes.header')
    </header>
    @yield('content')
    @include('home.includes.footer')
    @yield('scripts')
</body>

</html>
