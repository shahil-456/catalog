@extends('home.layouts.default')
@section('content')


<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg',['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">Terms of Service</h2>


        </div>
    </div>
</section>

<section class="feature-one mt-5">
    <div class="container">
        <div class="row align-items-center gy-4 gy-lg-0">
            <div class="col-md-12 list main">

                <div class="pb-3">
                    <h1 style="font-size:24px" class="pb-2">JUST REPAIR - TERMS & CONDITIONS:</h1>

                    <p>The approximate billing amount shown is primarily an initial amount, not a fixed one. Additional
                        installation/service charges can be added according to the on-site work and requirements.</p>
                </div>


                <div class="pb-3">
                    <h4 style="font-size:24px" class="pb-2">WARRANTY</h4>

                    <p>We offer a 60-day warranty on laptops/printers that we have repaired. For claiming the warranty,
                        the security seal must be intact and not be tampered with.</p>
                    <p>Just repair won’t be responsible if the device is submitted for any damage after these 60 days.
                        No warranty claims will be accepted after this period.</p>
                    <p>The damages that happened to the device from the user’s side after our repair, will not be
                        covered under our warranty and additional cost will be required to repair it.</p>
                </div>




                <div class="pb-3">
                    <h4 style="font-size:24px" class="pb-2">LIMITATIONS TO SERVICE</h4>

                    <p>We will not be responsible for any service delay due to reasons not in the company's control. We
                        are third-party service providers and reserve the right to refuse the provision of any service.
                        We can refuse to service the customers if the system's minimum requirements are not according to
                        our standards or the job's technical requirements are unreal and extensive.</p>
                    <p>We will also not be responsible for any data loss from the repair. The customer has to back up
                        all his data on any device, either the computer, phone, or storage device's disk drives. Data
                        can be in the form of any information, files, or software installed on the device.</p>
                </div>




                <div class="pb-3">
                    <h4 style="font-size:24px" class="pb-2"> POINT TO BE NOTED </h4>

                    <p> After completing the repair, the device should be collected by the customer within 30 days of
                        intimation, else Just repair has the right to dispose of the device.</p>
                </div>







                <!--	<form enctype="multipart/form-data" method="post" role="form" action="https://justrepair.ae/import">
								<div class="form-group">
								<label for="exampleInputFile">File Upload</label>
								<input type="file" name="file" id="file" size="150">
								<p class="help-block">Only Excel/CSV File Import.</p>
								</div>
								<button type="submit" class="btn btn-default" name="submit" value="submit">Upload</button>
								</form>-->





            </div>





        </div>



    </div>




</section>


@stop
