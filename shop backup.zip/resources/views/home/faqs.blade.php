@extends('home.layouts.default')
@section('content')

<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg', ['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">FAQ</h2>
            <p>Frequently Asked Questions</p>
        </div>
    </div>
</section>
<section class="feature-section padding-top padding-bottom oh pos-rel">
    <div class="container">
        <h4 class="pt-3 pb-2 color-black">Are You Looking for a Quick &amp; Affordable service for Your Damaged Gadgets?
        </h4>
        <p align="justify">We have a well-versed team of highly skilled technicians who are experts in working on any
            issues with your gadgets. They are trained to diagnose the problem and finish the repair at a rapid speed.
            This will help in extending the life cycle of your device. No matter the budget, we pride ourselves on
            providing professional customer service.</p>
    </div>
    @if($faqs->isNotEmpty())
    <div class="container">
        <div class="text-center mb-3">
            <h1 style="font-size:36px" class="title">Any Questions or Concerns?</h1>
        </div>
        <div class="row">
            <div class="col-lg-12 m-auto">
                <div class="faq--wrapper" id="get">
                    <div class="faq--area">
                        @foreach ($faqs as $faq)
                        <div class="faq--item">
                            <div class="faq-title">
                                <h5 class="title">{{ $faq->question }}</h5>
                                <span class="icon"></span>
                            </div>
                            <div class="faq-content" style="display: none;">
                                <p>{{ $faq->answer }}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</section>
@section('scripts')
@if($faqs->isNotEmpty())
<script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
        @foreach($faqs as $index => $faq)
        {
        "@type": "Question",
        "name": {!! json_encode($faq->question) !!},
        "acceptedAnswer": {
            "@type": "Answer",
            "text": {!! json_encode($faq->answer) !!}
        }
        }@if(!$loop->last),@endif
        @endforeach
    ]
    }
</script>
@endif
@endsection
