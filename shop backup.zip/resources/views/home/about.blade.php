@extends('home.layouts.default')
@section('content')




<style>
    input[type="submit"] {
        color: #fff;
        border: 1px solid #c20010;
        -webkit-border-radius: 25px;
        -moz-border-radius: 25px;
        border-radius: 10px;
        font-weight: 600;
        text-transform: capitalize;
        padding: 10px 35px;
        font-size: 16px;
        text-transform: uppercase;
        background: #c20010;
        text-align: center;
    }

    service-inside li h5 {
        color: #303030;
        font-size: 18px;
        padding-top: 13px;
    }
</style>

<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg',['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h1 class="title">About Us</h1>
            <p>What you like to Repair?</p>
        </div>
    </div>
</section>



<section class="feature-one mt-5" id="about">
    <div class="container">
        <div class="row align-items-center gy-4 gy-lg-0">

            <div class="col-lg-6 ps-lg-5 ">
                <div class="feature-content-text wow fadeInLeft mt-4 mt-xl-0"
                    style="visibility: visible; animation-name: fadeInLeft;">
                    <h2 style="font-size:28px">We are a team of highly skilled professionals who can fix any broken
                        devices in the UAE.</h2>


                    <p>The brand of your gadget, its model or technology is not a constraint for us. Because we accept
                        and repair all devices. You can trust our long experience in handling electronic gadgets,
                        laptops, printers, copiers, iPhones, MacBooks, etc. In addition to this we also provide quality
                        services in data recovery. Our team of software experts can bring out data from any expired
                        devices within a matter of hours. Software support is another strong area, where we can provide
                        you with new and intelligent software solutions that are available in the market. We will
                        install it for you and then you can get onboard quickly to take advantage of that software.
                        Along with all this we provide email support services as well. Send emails, track them and much
                        more with JustRepair.</p>


                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-start">
                <img src="{{ secure_image_url('assets/images/van.png',['source'=>'public','format' => 'png','grayscale' => false]) }}"
                    class="img-fluid" width="170%" alt="laptop repair service dubai"
                    title="laptop repair service dubai">

            </div>
        </div>
        <div class="row mt-5">

            <ul class="service-inside">
                <li> <img
                        src="{{ secure_image_url('assets/images/icon/a3.svg',['source'=>'public','format' => 'svg','grayscale' => false]) }}"
                        alt="printer service dubai" title="printer service dubai">
                    <h5>Instant Service</h5>
                </li>
                <li> <img
                        src="{{ secure_image_url('assets/images/icon/a4.svg',['source'=>'public','format' => 'svg','grayscale' => false]) }}"
                        alt="mobile repair shop dubai" title="mobile repair shop dubai">
                    <h5>Dedicated Support</h5>
                </li>
                <li> <img
                        src="{{ secure_image_url('assets/images/icon/a5.svg',['source'=>'public','format' => 'svg','grayscale' => false]) }}"
                        alt="tablet repair service dubai" title="tablet repair service dubai">
                    <h5>Easy Customer Service</h5>
                </li>
                <li> <img
                        src="{{ secure_image_url('assets/images/icon/a6.svg',['source'=>'public','format' => 'svg','grayscale' => false]) }}"
                        alt="best iMac repair service center in Dubai" title="best iMac repair service center in Dubai">
                    <h5>Quality Cost Service</h5>
                </li>
            </ul>
        </div>
    </div>

    <div class="feature-content1">

        <div class="container">
            <h4 class="pt-3 pb-2">Are You Looking for a Quick &amp; Affordable service for Your Damaged Gadgets? </h4>

            <p> We repair laptops of all top brands with utmost care and dexterity. You can be
                assured of your product in our capable hands </p>
        </div>
    </div>
</section>
@stop
