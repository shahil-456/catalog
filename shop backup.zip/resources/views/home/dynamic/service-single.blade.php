@extends('layouts.default')
@section('content')
<div class="hb-breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ol class="hb-breadcrumb">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="{{ route('services') }}">Services</a></li>
                    <li><span>{{ $service->name }}</span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<main class="hb-main">
    <div class=" ">
        <div class="breadcrumb-service mb-5">
            <div class="container position-relative pt-4 pt-lg-0">
                <div class="row align-items-center">
                    <div class="col-md-7 col-xl-6 mb-6 mb-md-0">
                        <!-- <span class="small-title-box">Analytics</span> -->
                        <h1 class="my-4"> {{ $service->name }}</h1>
                        <!-- <p class="mb-7">Gain valuable insights into your digital campaigns with our comprehensive data
                                                                                                                                                                                                            analytics and
                                                                                                                                                                                                            reporting feature.</p> -->
                    </div>
                    <div class="col-md-4 position-relative ms-auto mb-xl-n9">
                        <figure class="single-service-top-img">
                            <svg width="300px" height="150px" viewBox="0 0 223.6 87.2"
                                style="enable-background:new 0 0 223.6 87.2;" xml:space="preserve">
                                <path class="fill-mode"
                                    d="M222.9,53.8c-13.2-3-28-3-41,0.9c-5.5,1.7-11,4.3-14.9,8.7c-1.3-0.1-2.6-0.2-3.8-0.1 c-5.8,0.1-11.6,1.5-16.9,3.7c-2.9,1.2-5.7,2.9-8.5,4.4c-3.7,1.9-7.4,3.8-11.3,5.3c-7.3,2.9-16,5-23.5,1.7c-1.5-0.6-2.9-1.5-4.1-2.6 c6.5-2.6,12.2-7.9,13.2-15c0.8-6.6-5.1-12.1-11.6-11.4c-5,0.6-7.5,5.6-8.3,10.1c-0.9,4.9-0.3,10.8,2.7,14.9 c0.2,0.2,0.4,0.5,0.5,0.7c-0.4,0.1-0.8,0.2-1.3,0.3c-6.6,1.5-14.3,0.3-20.3-2.9c-6.1-3.3-10.3-9.1-12.3-15.6 c-0.2-0.7-1.2-0.4-1,0.3c2.1,7.3,6.7,13.4,13.4,17.1c6.8,3.7,15.4,4.5,22.7,2.4c0,0,0.1,0,0.1,0c4.5,4.4,11.2,5.9,17.3,5.4 c8-0.6,15.6-4.1,22.7-7.7c5.6-2.9,10.8-6,17-7.6c3.8-0.9,7.8-1.5,11.8-1.3c-3.3,4.8-4.6,11.1-2.3,16.5c2.8,6.4,11.3,6.7,16.3,2.8 c5.1-4,2.8-12.4-1-16.4c-2.4-2.5-5.7-3.9-9.1-4.5c0.2-0.2,0.3-0.3,0.5-0.4c4.3-4,10.2-6.2,15.9-7.5c11.8-2.8,24.9-2.7,36.7,0 C223.6,56,224.1,54,222.9,53.8z M95.5,71.6c-1.2-2.4-1.7-5.1-1.8-7.8c-0.1-4.5,1.1-11.2,6.1-12.6c2.4-0.7,5.2,0.4,7.2,1.7 c2.9,1.9,3.5,5.5,2.9,8.7c-1.2,6.2-6.8,10.5-12.6,12.6C96.7,73.4,96,72.5,95.5,71.6z M171.5,66.3c5.7,1.8,10.3,7.8,8.5,14 c-1.1,3.9-6.1,5.2-9.6,4.8c-3.5-0.4-5.5-3.4-6.2-6.5c-1.1-4.7,0.6-9.5,3.5-13.1C169,65.7,170.2,65.9,171.5,66.3z">
                                </path>
                                <polygon class="fill-primary" points="65.3,39 61,56.8 0.7,0.7"></polygon>
                                <path class="fill-mode"
                                    d="M60.6,57.3L0.2,1.1C0,0.9-0.1,0.5,0.1,0.3C0.3,0,0.7-0.1,1,0.1l64.7,38.3c0.2,0.1,0.4,0.4,0.3,0.7l-4.3,17.8 c-0.1,0.2-0.2,0.4-0.4,0.5c-0.1,0-0.1,0-0.2,0C60.9,57.4,60.7,57.4,60.6,57.3z M5.6,4.3l55.1,51.2l3.9-16.3L5.6,4.3z">
                                </path>
                                <polygon class="fill-primary" points="56.5,42.4 61,56.8 0.7,0.8"></polygon>
                                <path class="fill-mode"
                                    d="M60.6,57.3L0.2,1.3C0,1.1-0.1,0.7,0.2,0.4c0.2-0.3,0.6-0.3,0.9-0.1l55.8,41.5c0.1,0.1,0.2,0.2,0.2,0.3 l4.6,14.4c0.1,0.3,0,0.6-0.3,0.8c-0.1,0.1-0.2,0.1-0.4,0.1C60.9,57.4,60.7,57.4,60.6,57.3z M10.1,8.7l49.6,45.9l-3.8-11.8 L10.1,8.7z">
                                </path>
                                <polygon class="fill-primary" points="0.7,0.7 91.5,28.5 65.2,38.8 			"></polygon>
                                <path class="fill-mode"
                                    d="M64.9,39.4L0.3,1.2C0,1.1-0.1,0.7,0.1,0.4C0.2,0.1,0.5-0.1,0.9,0l90.9,27.8c0.3,0.1,0.5,0.3,0.5,0.6 c0,0.3-0.2,0.5-0.4,0.6L65.4,39.4c-0.1,0-0.2,0-0.2,0C65.1,39.4,65,39.4,64.9,39.4z M5.8,2.9l59.5,35.2l24.3-9.5L5.8,2.9z">
                                </path>
                                <polygon class="fill-primary" points="56.3,42.4 26.5,57.6 0.7,0.7 			"></polygon>
                                <path class="fill-mode"
                                    d="M26.3,58.3c-0.2-0.1-0.3-0.2-0.4-0.3L0.1,0.9c-0.1-0.3,0-0.6,0.2-0.8C0.5,0,0.8,0,1.1,0.1l55.7,41.8 c0.2,0.1,0.3,0.4,0.3,0.6c0,0.2-0.2,0.4-0.4,0.5L26.8,58.2c-0.1,0-0.2,0.1-0.3,0.1C26.5,58.3,26.4,58.3,26.3,58.3z M2.3,2.7 l24.5,54l28.2-14.4L2.3,2.7z">
                                </path>
                            </svg>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row align-items-start justify-content-center">
                <div class="container pt-4 pt-lg-0">
                    <div class="row">
                        <div class="col-xl-8 mx-auto mb-5 pt-4">
                            @foreach ($page_sections as $page_section)
                            @if ($page_section->section_id == 1)
                            <div class="{{ 'order-' . $page_section->sort_order }}">
                                @foreach ($page_section->items as $key => $item)
                                <div
                                    class="{{ 'row flex-row' . ($key % 2 == 0 ? '-reverse' : '') . ' pt-4 align-items-center' }}">
                                    <div class="col-lg-6 mb-6 mb-lg-0">
                                        <h3 class="my-4">{{ $item['heading'] }}</h3>
                                        <p>{{ $item['content'] }}</p>
                                    </div>
                                    <div class="col-lg-6 position-relative ms-auto">

                                        <img src={{ $item['image']==null || $item['image']=='' ?
                                            asset('img/no_image_service_page.png') :
                                            asset('storage/images/page_section_items/' . $item['image']) }}
                                            class="rounded position-relative zindex-2" alt="feature-img">
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            @endif
                            @if ($page_section->section_id == 2)
                            <div class="{{ 'order-' . $page_section->sort_order }}">
                                <h3 class="my-4">{{ $page_section->heading }}</h3>
                                <ul class="list-group list-group-borderless">
                                    @foreach ($page_section->items as $item)
                                    <li class="list-group-item heading-color d-flex mb-0">
                                        <i class="fi fi-rs-arrow-small-right me-2"></i>{{ $item['heading'] }}
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                            @if ($page_section->section_id == 3)
                            <div class="{{ 'row mt-5 order-' . $page_section->sort_order }}">
                                <div class="col-lg-12 mb-2 mt-5">
                                    <h4>{{ $page_section->heading }} </h4>
                                </div>
                                <div class="row">
                                    <ul class="listing2">
                                        @foreach ($page_section->items as $item)
                                        <li><strong> {{ $item['heading'] }}</strong>
                                            <br>{{ $item['content'] }}
                                        </li>
                                        @endforeach
                                    </ul>

                                </div>

                            </div>
                            @endif
                            @if ($page_section->section_id == 4)
                            <div class="{{ 'col-md-12  order-' . $page_section->sort_order }}">
                                <h2>{{ $page_section->heading }}</h2>
                                <p>{{ $page_section->content }}</p>
                            </div>
                            @endif
                            @endforeach

                            @if (count($faqs))
                            <div class="row mt-4 order-50">
                                <h4>Frequently Asked Question</h4>
                                @if (count($faqs))
                                <div class="accordion" id="accordionExample">
                                    @foreach ($faqs as $faq)
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="heading">
                                            <button class="accordion-button h6 mb-0 text-black" type="button"
                                                data-bs-toggle="collapse" data-bs-target={{ '#collapse' . $faq->id }}
                                                aria-expanded="true" aria-controls="collapseOne">
                                                {{ $faq->question }}
                                            </button>
                                        </h2>
                                        <div id={{ 'collapse' . $faq->id }}
                                            class="accordion-collapse collapse "
                                            aria-labelledby="headingOne" data-bs-parent="#accordionExample"
                                            style="">
                                            <div class="accordion-body">
                                                {{ $faq->answer }}
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                                @endif
                            </div>
                            @endif
                        </div>
                        <div class="col-lg-4 ms-auto mt-4 mt-lg-0">
                            <div class="sidebar mb-5">
                                <div class="card  rounded h-100 overflow-hidden p-4 bg-gradient2">
                                    <!-- SVG decoration -->
                                    <div class="position-absolute top-0 end-0 mt-n3 me-n4">
                                        <img src="images/decoration-pattern-2.svg" class="opacity-2 h-200px" alt="">
                                    </div>

                                    <!-- Card body -->
                                    <div class="card-body bg-transparent position-relative p-3 pt-10">
                                        <div class="badge bg-dark text-white p-1">Enterprise</div>
                                        <h3 class="text-white mb-0 mt-3">GET A FREE CONSULTATION</h3>
                                    </div>

                                    <form class="card-body px-0 pb-0 pt-5" method="POST"
                                        action="{{ route('service.submit') }}">
                                        @csrf
                                        {!! NoCaptcha::renderJs() !!}
                                        <!-- Name -->
                                        <div class="input-floating-label form-floating mb-4">
                                            <input type="text" class="form-control " name="name"
                                                value="{{ old('name') }}" placeholder=" " id="floatingName">
                                            <input type="hidden" name="type" value="1" />
                                            <input type="hidden" name="service_id" value="{{ $service->id }}" />
                                            <label for="floatingName">Your name</label>
                                            @error('name')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                            <!-- Display validation error message -->
                                            @enderror
                                        </div>
                                        <!-- Email -->
                                        <div class="input-floating-label form-floating mb-4">
                                            <input type="email" class="form-control " value="{{ old('email') }}"
                                                id="floatingInput" placeholder=" " name="email">
                                            <label for="floatingInput">Email address</label>
                                            @error('email')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                            <!-- Display validation error message -->
                                            @enderror
                                        </div>
                                        <!-- Number -->
                                        <div class="input-floating-label form-floating mb-4">
                                            <input type="tel" class="form-control  " name="phone" id="floatingNumber"
                                                value="{{ old('phone') }}" placeholder=" ">
                                            <input type="hidden" id="dial_code" name="dial_code" value="971">
                                            <label for="floatingNumber">Phone number</label>
                                            @error('phone')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                            <!-- Display validation error message -->
                                            @enderror
                                        </div>
                                        <!-- Message -->
                                        <div class="input-floating-label form-floating mb-4">
                                            <textarea class="form-control " placeholder=" " id="floatingTextarea2"
                                                style="height: 100px" value="{{ old('message') }}"></textarea>
                                            <label for="floatingTextarea2">Message</label>
                                        </div>
                                        <div class="col-12">
                                            {!! NoCaptcha::display() !!}
                                        </div>
                                        <!-- Button -->
                                        <button type="submit" class="btn btn-lg btn-primary mb-0">Send a
                                            message</button>
                                    </form>
                                    @if (session('message'))
                                    @if (session('message') == 'true')
                                    <div class="alert alert-success mt-2 mb-2" role="alert">
                                        <div class="d-flex gap-4">
                                            <span><i class="fa-solid fa-circle-check icon-success"></i></span>
                                            <div class="d-flex flex-column gap-2">
                                                <h6 class="mb-0" id="{{ $success_id }}"> {{ 'Thank you for choosing
                                                    us' }}
                                                </h6>

                                            </div>
                                        </div>
                                    </div>
                                    @elseif (session('message') == 'false')
                                    <div class="alert alert-danger mt-2 mb-2" role="alert">
                                        <div class="d-flex gap-4">
                                            <span><i class="fa-solid fa-circle-exclamation icon-danger"></i></span>
                                            <div class="d-flex flex-column gap-2">
                                                <h6 class="mb-0">
                                                    {{ 'An error occurred. Please try again later. ' }}
                                                </h6>

                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if($faqs)
    <script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
        @foreach($faqs as $index => $faq)
        {
        "@type": "Question",
        "name": {!! json_encode($faq->question) !!},
        "acceptedAnswer": {
            "@type": "Answer",
            "text": {!! json_encode($faq->answer) !!}
        }
        }@if(!$loop->last),@endif
        @endforeach
    ]
    }
    </script>
    @endif

</main>
@stop