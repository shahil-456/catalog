<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
@if (isset($seo) && !empty($seo->meta_title))
<title>{{ $seo->meta_title }}</title>
<meta name="description" content="{{ $seo->meta_description }}">
<meta name="keywords" content="{{ $seo->meta_keyword }}">
<!-- Other SEO meta tags -->
@else
<title>{{ $title ?? 'Just Repair' }}</title>
@endif
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<title></title>
<link rel="shortcut icon" href="{{ asset('assets/images/favicon.png') }}" type="image/x-icon">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/css/minified.css') }}">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css'>
     <link rel='stylesheet' href="{{ asset('assets/css/bootstrap-icons.css') }}">
     
    <style>
        .dropdown-toggle {
            text-decoration: none;
        }

        a {
            color: #000000;
            text-decoration: none;
        }

        a:hover {
            color: #000000;
        }
    </style>