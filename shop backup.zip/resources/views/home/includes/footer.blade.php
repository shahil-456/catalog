<section class="call-to-action cta-bg-3">
    <div class="container">
        <div class="row action-content-wrapper justify-content-between gy-4 gy-lg-0">
            <div class="col-lg-9 mt-0">
                <div class="action-title-wrap title-img d-block d-sm-flex">
                    <img src="{{ asset('assets/images/home/logo-footer.png') }}" alt="">
                    <div class="text-lg-end w-100">
                        <a class="manrope2" href="mailto:help@justrepair.ae">help@JustRepair.ae</a>
                        <a class="manrope2" href="tel:+971564130210">+971 56 413 0210</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 text-lg-end text-center whts">
                <a href="https://wa.me/+971564130210"><img class="" src="{{ asset('assets/images/home/whatsapp-f.svg') }}"></a>
            </div>
        </div>
    </div>
</section>
<footer class="footer-3 ">
    <div class="container">
        <div class="footer-top pt-5 pb-5">
            <div class="row gy-lg-0 gy-4">
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai']) }}">Laptop
                                Repair</a></h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'apple-repair-dubai']) }}">Apple
                                    laptop repair
                                </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'lenovo-repair-dubai']) }}">Lenovo
                                    laptop
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'microsoft-repair-dubai']) }}">Microsoft
                                    laptop repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'hp-repair-dubai']) }}">Hp
                                    laptop repair
                                </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'dell-repair-dubai']) }}">Dell
                                    laptop
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'laptop-service-center-in-dubai', 'brandSlug' => 'asus-repair-dubai']) }}">Asus
                                    laptop
                                    repair </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'printer-repair-service-dubai']) }}">Printer
                                Repair</a></h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'samsung-repair-dubai']) }}">Samsung
                                    printer repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'hp-repair-dubai']) }}">Hp
                                    printer repair
                                </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'canon-repair-dubai']) }}">Canon
                                    printer
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'epson-repair-dubai']) }}">Epson
                                    printer
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'brother-repair-dubai']) }}">Brother
                                    printer repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'printer-repair-service-dubai', 'brandSlug' => 'sharp-repair-dubai']) }}">Sharp
                                    printer
                                    repair </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'imac-repair-service-dubai']) }}">iMac
                                Repair</a>
                        </h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'imac-repair-service-dubai', 'brandSlug' => 'apple-repair-dubai']) }}">Apple
                                    imac repair
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'desktop-repair-service-dubai']) }}">Desktop
                                Repair</a></h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'apple-repair-dubai']) }}">Apple
                                    desktop
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'microsoft-repair-dubai']) }}">Microsoft
                                    desktop repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'hp-repair-dubai']) }}">Hp
                                    desktop repair
                                </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'dell-repair-dubai']) }}">Dell
                                    desktop
                                    repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'lenovo-repair-dubai']) }}">Lenovo
                                    desktop repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'desktop-repair-service-dubai', 'brandSlug' => 'acer-repair-dubai']) }}">Acer
                                    desktop
                                    repair </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'cctv-system-repair']) }}">CCTV
                                System Repair</a></h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'cctv-system-repair', 'brandSlug' => 'hikvison-repair']) }}">Hikvison
                                    cctv system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'cctv-system-repair', 'brandSlug' => 'dahua-repair']) }}">Dahua
                                    cctv system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'cctv-system-repair', 'brandSlug' => 'bosch-repair']) }}">Bosch
                                    cctv system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'cctv-system-repair', 'brandSlug' => 'xiaomi-repair']) }}">Xiaomi
                                    cctv system repair </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 ps-xl-5 col-sm-5">
                    <div class="footer-widget">
                        <h3 style="font-size:16px;"><a
                                href="{{ route('home.category.services.detail', ['categorySlug' => 'biometric-system-repair']) }}">Biometric
                                System Repair</a>
                        </h3>
                        <ul class="link-list list-unstyled">
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'biometric-system-repair', 'brandSlug' => 'zkteco-repair']) }}">Zkteco
                                    biometric system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'biometric-system-repair', 'brandSlug' => 'suprema-repair']) }}">Suprema
                                    biometric system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'biometric-system-repair', 'brandSlug' => 'idemia-repair']) }}">Idemia
                                    biometric system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'biometric-system-repair', 'brandSlug' => 'dahua-repair']) }}">Dahua
                                    technology biometric
                                    system repair </a>
                            </li>
                            <li style="font-size:11px;margin-top:3px;margin-bottom:3px"><a
                                    href="{{ route('home.category-brand.services.detail', ['categorySlug' => 'biometric-system-repair', 'brandSlug' => 'fingertec-repair']) }}">Fingertec
                                    biometric system repair
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12 col-sm-6 pt-5">
                    <div class="footer-widget">


                        <div class="row mt-3 align-items-center">
                            <div class="col-md-6 br-right-1">
                                <p>Al Raffa Police Station Road
                                    Raffa St, Bur Dubai,
                                    Dubai – UAE</p>
                            </div>
                            <div class="col-md-6 footer-4">
                                <ul class="social-icons">
                                    <li>
                                        <a href="https://www.facebook.com/justrepair.ae/" target="_blank"
                                            aria-label="Visit our Facebook page"><i class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/JustrepairA" target="_blank" class=""
                                            aria-label="Visit our twitter page"><i class="fab fa-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/justrepair.ae/" target="_blank"
                                            aria-label="Visit our Instagram page"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/@justrepair-ae" target="_blank"
                                            aria-label="Visit our Youtube page"><i class="fab fa-youtube"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <ul class="footer-link">
                <li>
                    <a href="{{ route('home.about-us') }}">About</a>
                </li>
                <li>
                    <a href="{{ route('home.faqs') }}">FAQs</a>
                </li>
                <li>
                    <a href="{{ route('home.contact') }}">Contact</a>
                </li>
                <li>
                    <a href="{{ route('home.terms') }}">Terms of Service</a>
                </li>
                <li>
                    <a href="{{ route('home.privacy') }}">Privacy</a>
                </li>
                <li>
                    <a href="{{ route('home.blogs') }}">Blogs</a>
                </li>
            </ul>
        </div>
        <div class="copyright">
            <p>
                Copyright 2025, All Rights Reserved
            </p>
        </div>
    </div>
</footer>

<div class="whats-float">
    <a href="https://wa.me/+971564130210" target="_blank">
        <i class="fab fa-whatsapp"></i><span>WhatsApp<br><small>+971 56 413 0210</small></span>
    </a>
</div>
<style>
       
.whats-float {
    position: fixed;
 
    top:50%;
    right:-108px;
    width:150px;
    overflow: hidden;
    background-color: #25d366;
    color: #FFF;
    border-radius: 4px 0 0 4px;
    z-index: 10;
    transition: all 0.5s ease-in-out;
    vertical-align: middle;
    cursor:pointer;
    animation: bounceInDown 2s;
  -webkit-animation: bounceInDown 2s;
  -moz-animation: bounceInDown 2s;
    
}

.whats-float a span {
    color: white;
    font-size: 15px;
    padding-top: 8px;
    padding-bottom: 10px;
    position: absolute;
    line-height: 16px;
    font-weight: bolder;
}

.whats-float i {
    font-size: 30px;
    color: white;
    line-height: 30px;
    padding: 10px;
    transform:rotate(0deg);
    transition: all 0.5s ease-in-out;
    text-align:center;

}

.whats-float:hover {
    color: #FFFFFF;
    /* transform:translate(0px,0px); */
     transform:translate(-108px,0px);
}

.whats-float:hover i  {
    transform:rotate(360deg);
}
.foot-contact {
    justify-content: space-around;
    display: flex;
    align-items: center;
}
.manrope2:hover {
    color: #fff;
}
@media (max-width: 768px) {
    .foot-contact {
        flex-direction: column;
    }
}
</style>
<script src="{{ asset('assets/js/minified.js') }}"></script>
<script src="{{ asset('assets/js/main.js') }}"></script>
