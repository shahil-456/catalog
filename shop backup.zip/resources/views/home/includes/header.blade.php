<a href="#0" class="scrollToTop" aria-label="scroll the page"><i class="fas fa-angle-up"></i></a>
<div class="overlay">
    <div class="menu-repiar">
        <ul>
            <li><a href="">
                     Repair
                </a></li>
        </ul>
    </div>
</div>
<header class="header-section">
    <div class="container">
        <div class="header-wrapper">
            <div class="logo">
                <a href="{{ route('home.home') }}">
                    <img src="{{ asset('assets/images/home/logo.png') }}" alt="logo">
                </a>
            </div>
            <div style="display: flex; align-items: center;">
                <div class="header-right">
                    <a href="tel:+971564130210" class="header-button d-none d-sm-inline-block">+971 56 413 0210</a>
                    <a href="https://wa.me/+971564130210" class=""><img alt="whatsapp" title="whatsapp"
                            src="{{ asset('assets/images/home/whatsapp.svg') }}"></a>
                </div>
                <div class="header-bar">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</header>
