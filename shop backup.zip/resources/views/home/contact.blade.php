@extends('home.layouts.default')
@section('content')

<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Just Repair",
    "url": "https://justrepair.ae",
    "logo": "https://justrepair.ae/assets/images/home/logo.png",
    "image": "https://justrepair.ae/assets/images/home/banner.svg",
    "description": "Just Repair offers professional repair services for Mobiles, Laptops, Printers, iPads, iMacs, and MacBooks in Dubai. Free pickup and delivery available. Book your service now.",
    "address": {
        "@type": "PostalAddress",
        "streetAddress": "Al Raffa Police Station Road, Raffa St, Bur Dubai",
        "addressLocality": "Dubai",
        "addressCountry": "AE"
    },
    "telephone": "+971508418452",
    "sameAs": [
        "https://www.facebook.com/justrepair.ae",
        "https://twitter.com/JustrepairA",
        "https://www.instagram.com/justrepair.ae/"
    ]
}
</script>
<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg', ['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <!--<div class="bottom-shape d-none d-md-block">-->
    <!--    <img src="./assets/css/img/page-header.png" alt="css">-->
    <!--</div>-->
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">Contact Us</h2>

        </div>
    </div>
</section>

    {!! ToastMagic::styles() !!}


<div class="container">

    <div class="row mt-5 ">

        <!--Section: Contact v.2-->
        <section class="mb-4 p-3">

        

            <div class="row align-items-center">

                <!--Grid column-->
                <div class="col-md-9 mb-md-0 mb-5">
                        <!--Section heading-->
            <h2 class="h1-responsive font-weight-bold text-left">Get in touch</h2>
            <!--Section description-->
            <p class="text-left w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to
                contact us directly. Our team will come back to you within
                a matter of hours to help you.</p>


            <form id="contactForm" enctype="multipart/form-data">
                @csrf
                <div class="row"><div class="col-md-6">
            <div class="form-group">
                <label for="Name">Name</label>
                <input name="name" id="name"  type="text" class="form-control">
                <div class="invalid-feedback" id="nameError"></div>

                
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input name="phone" id="phone" type="text" class="form-control">
                 <div class="invalid-feedback" id="phoneError"></div>
               
            </div>
            
            
            </div>
            <div class="col-md-6"><form>
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input name="email"  type="email" class="form-control" id="email" aria-describedby="emailHelp">
                <div class="invalid-feedback" id="emailError"></div>
                
            </div>
            <div class="form-group">
                <label >Company</label>
                <input name="company" id="company" type="text" class="form-control">
                <div class="invalid-feedback" id="companyError"></div>
               
            </div>
            
            
            </div>
            <div class="col-md-12">
                <div class="form-group">
                <label >Message</label>
                <textarea name="message" id="message" class="form-control" rows="3"></textarea>
                <div class="invalid-feedback" id="messageError"></div>

            </div>

            <button type="submit" class="btn btn-danger" style="max-width: 100px;">Submit</button>
            </div>
            </div>
            </form>
                </div>

                    <div class="col-md-3 text-center contact">
                        <ul class="list-unstyled mb-0">
                            <li><i class="fas fa-map-marker-alt"></i>
                                <a href="https://www.google.com/maps/place/Justrepair.ae/@25.2601194,55.2870507,17z/data=!3m1!4b1!4m6!3m5!1s0x3e5f431f9def75bd:0x86fc4cbc9c05f7ba!8m2!3d25.2601146!4d55.2892394!16s%2Fg%2F11t4lvxl1g?hl=en"
                                    target="_blank">Dubai, UAE</a>
                            </li>

                            <li><i class="fas fa-phone"></i>
                                <a href="tel:+971564130210">+971 56 413 0210</a>
                            </li>

                            <li><i class="fas fa-envelope"></i>
                                <a href="mailto:info@justrepair.ae">Info@justrepair.ae</a>
                            </li>
                        </ul>
                    </div>
                    <!--Grid column-->

                </div>

        </section>
        <!--Section: Contact v.2-->

    </div>

</div>

{!! ToastMagic::scripts() !!}

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<script>
    $(document).ready(function() {
            $('#contactForm').on('submit', function(e) {
                e.preventDefault();
                // Clear previous errors
                $('#nameError').text('');
              
                $('#name').removeClass('is-invalid');
                $('#nameError').removeClass('is-invalid');
                
                // Client-side validation for name 
                
                let formData = new FormData(this);


                $.ajax({
                    url: "{{ route('home.contact.store') }}",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastMagic.success("Success!", response.message);
                            setTimeout(function() {
                                window.location.href =
                                    "{{ route('home.home') }}";
                            }, 1000);
                        }
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;

                        if (errors.name) {
                            $('#nameError').text(errors.name[0]);
                            $('#name').addClass('is-invalid');
                        }

                        if (errors.phone) {
                            $('#phoneError').text(errors.phone[0]);
                            $('#phone').addClass('is-invalid');
                        }


                        if (errors.email) {
                            $('#emailError').text(errors.email[0]);
                            $('#email').addClass('is-invalid');
                        }


                         if (errors.message) {
                            $('#messageError').text(errors.message[0]);
                            $('#message').addClass('is-invalid');
                        }

                       
                    }
                });
            });
        });
</script>

@stop
