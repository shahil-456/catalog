@extends('home.layouts.default')
@section('content')
<section class="page-header bg_img"
    data-background="{{ secure_image_url('assets/images/product/bg-intro.jpg',['source'=>'public','format' => 'jpg','grayscale' => false]) }}">
    <div class="container">
        <div class="page-header-content cl-white">
            <h2 class="title">Privacy & Policy</h2>
        </div>
    </div>
</section>
<section class="feature-one mt-5">
    <div class="container">
        <div class="row align-items-center gy-4 gy-lg-0">
            <div class="col-md-12 list main">


                <div class="pb-3">
                    <h1 style="font-size:24px" class="pb-2"> PRIVACY POLICY </h1>

                    <p> Every customer’s information and personal data are handled carefully following privacy laws.
                        We comply with all privacy laws, and our internal privacy policy is also very strict.</p>
                </div>
                <div class="pb-3">
                    <h4 style="font-size:24px" class="pb-2"> DATA COLLECTION </h5>

                        <p> We collect information including phone, email address, and location details directly
                            from the customers and also might collect images with customers to use in our social
                            media accounts to showcase our services only with their consent. We may also
                            occasionally contact customers after repairs for feedback. Every customer has the right
                            to remove feedback from our social media and marketing platforms.</p>
                </div>
                <div class="pb-3">
                    <h4 style="font-size:24px" class="pb-2"> LAWS </h5>

                        <p> Just Repair is an authorized gadget repair company registered in the UAE. The Service
                            Terms shall be governed by and construed in accordance with the laws of Dubai excluding
                            its conflict of law provisions.</p>
                        <p>We reserve the right, at our sole discretion, to update, change or replace any part of
                            these Terms of Service by posting updates and changes to our website. Our customers can
                            check the "Just Repair website" periodically for changes and updates.</p>
                </div>
            </div>
        </div>
    </div>
</section>


@stop
