@extends('home.layouts.default')
@section('content')
<style>
    /* General error and helper styles */
    .error,
    .error-message {
        color: red;
        font-weight: bold;
    }

    .error-message {
        font-size: 12px;
        padding-left: 20px;
        float: right;
    }

    /* Hide company and OTP fields by default */
    #company-field,
    #otp-field {
        display: none;
    }

    /* Address and button styles */
    .address-type,
    .address_type {
        width: 20px;
        float: left;
        padding: 0;
        margin: 0;
    }

    .add_new,
    .btn-small {
        float: right;
    }

    .btn-small {
        text-decoration: underline;
        color: #c20010;
    }

    /* List and text styles */
    .para-text ul li {
        text-align: left;
    }

    a.title {
        color: red;
    }

    .list-group-item {
        width: 100%;
        float: left;
    }

    .faq {
        text-align: left;
        padding: 5px 0 0 0;
        height: 30px;
        text-decoration: none !important;
    }

    /* Forms and input styles */
    input[type=submit] {
        color: #fff;
        border: 1px solid #c20010;
        border-radius: 10px;
        font-weight: 600;
        text-transform: uppercase;
        padding: 10px 35px;
        font-size: 16px;
        background: #c20010;
        text-align: center;
        width: auto;
    }

    /* Link and timer styles */
    #verify-link,
    .timer {
        color: #C20010;
        text-decoration: underline;
        cursor: pointer;
        padding: 0;
    }

    #verify-link {
        font-size: 13px;
    }

    .timer {
        border-bottom: 1px solid #C20010;
    }

    /* Nice-select plugin customizations */
    .nice-select.open .list {
        opacity: 1;
        z-index: 99999999999;
        pointer-events: auto;
        transform: scale(1) translateY(0);
        cursor: pointer;
        border: 1px solid #cacaca;
    }

    .nice-select.option,
    .nice-select.select-bar1.list.option {
        z-index: 9000;
    }

    .nice-select.select-bar1.list.option {
        z-index: 90000;
    }

    /* Loading spinner */
    #loading-spinner {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 9999;
    }

    #loading-spinner img {
        width: 200px;
        height: 200px;
    }

    /* General element overrides */
    span {
        background-color: transparent;
        font-family: Arial !important;
    }

    p {
        width: 100% !important;
        font-weight: normal !important;
        font-family: Arial !important;
        /* line-height: 1.5px; */
        text-align: left;
    }

    div {
        text-align: left;
    }

    .title {
        text-align: center;
    }
</style>
<section class="page-header bg_img">
    <div class="container">
        <div class="page-header-content cl-white">
            <h1 style="font-size:40px" class="title">Book Your Service</h1>
        </div>
    </div>
</section>
<div class="container">
    <div class="row   mb-5 mt-5 pt-3">
        <div class="col-lg-12">

            <div class="card1 px-0  4 pb-0  mb-3">
                <h4></h4>

                <div class="row">
                    <div class="col-md-9">
                        <form id="msform">
                            <ul id="progressbar">
                                <li class="active" id="personal"><strong></strong></li>
                                <li id="account"><strong></strong></li>
                                <li id="confirm"><strong></strong></li>
                            </ul>


                            <img class="img-fluid" style="position: absolute;
  z-index: 9;
  width: 160px;
  left: -40px;
  top: -40px;" src="{{ secure_image_url('assets/images/tabby.gif', ['source'=>'public','format' => 'gif','grayscale' => false]) }}" />

                            <fieldset id="form1" class="checkout">
                                <div class="form-card">
                                    <div class="col-12 ">

                                        <div class="card-new ">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12  address_field" id="address_field">
                                                        <div class="row">
                                                            <div class="col-12 customer_address_sectiion">
                                                                <div class="row">
                                                                    <div class="col-12 col-8 form-group">
                                                                        <label class="" style="font-size:15px"> Select
                                                                            Category</label>
                                                                        <span class="error-message"
                                                                            id="error-field1"></span>
                                                                        <select
                                                                            class="select-bar nice-select w-100 mb-2"
                                                                            name="category_id" id="category_id">
                                                                            <option disabled selected value="">Select
                                                                                one</option>
                                                                            @foreach($categories as $item)
                                                                            <option value="{{ $item->id }}"
                                                                                data-slug="{{ $item->slug }}" {{
                                                                                (isset($categorySlug) &&
                                                                                $categorySlug==$item->slug)
                                                                                ? 'selected' : '' }}>
                                                                                {{ $item->name }}
                                                                            </option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                    <div class="col-12 form-group">
                                                                        <label class="" style="font-size:15px"> Select
                                                                            Brand</label>
                                                                        <span class="error-message"
                                                                            id="error-field2"></span>
                                                                        <select
                                                                            class="select-bar nice-select w-100 mb-2"
                                                                            id="brand_id" name="brand_id">
                                                                            <option disabled selected value="">Select
                                                                                one</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="col-12 form-group" id="model">
                                                                        <textarea type="text" class="form-control"
                                                                            name="model"
                                                                            placeholder="Enter Model"></textarea>
                                                                    </div>
                                                                    <div class="col-12 form-group" id="issue">
                                                                        <textarea type="text" class="form-control"
                                                                            name="issue"
                                                                            placeholder="Enter the issue"></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <a name="next" href="#form2" class="open2 btn action-button mr-5"
                                    value="Continue">
                                    Continue</a>
                            </fieldset>


                            <fieldset id="form2" class="checkout">
                                <div class="form-card">
                                    <div class="col-12 p-0">
                                        <div class="col-md-12 form-group center_section mb-0">
                                            <b>Your Profile Details</b>
                                        </div>
                                        <div class="card-new p-3 pt-0">
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label class="" style="font-size:15px"> First Name</label>
                                                    <span class="error-message" id="error-field11"></span>
                                                    <input type="text" id="first_name" name="first_name"
                                                        class="name form-control" value="" placeholder="First Name">
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label class="" style="font-size:15px">Last Name</label>
                                                    <span class="error-message" id="error-field12"></span>
                                                    <input type="text" id="last_name" name="last_name"
                                                        class="name form-control" value="" placeholder="Last Name">
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label class="" style="font-size:15px"> Phone</label>
                                                    <span class="error-message" id="error-field22"></span>
                                                    <div class="input-group mb-6">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="basic-addon2"
                                                                style="background-color:#cacaca;">+971</span>
                                                        </div>
                                                        <input type="number" name="mobile" placeholder="Phone Number"
                                                            class="phone form-control" id="mobile">
                                                    </div>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label class="" style="font-size:15px"> Email</label>
                                                    <span class="error-message" id="error-field33"></span>
                                                    <input type="email" id="email" name="email"
                                                        class="email form-control" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="button" name="next" class="action-button open1" value="Next" />
                                <a href="#form1" class=" btn action-button back1" style="padding:7px 2px;">Back </a>
                            </fieldset>
                            <fieldset id="form3">
                                <div class="form-card">
                                    <div class="col-12">
                                        <div class="col-md-12 form-group center_section mb-0">
                                        </div>
                                        <div class="card-new p-3 pt-0">
                                            <div class="row">
                                                <span id="quote_id"
                                                    style="font-weight:bold;padding-bottom:5px;"></span></br>
                                                <p> Your request has been submitted,We will Reach you soon..</p>
                                            </div>
                                        </div>
                                    </div>
                                </div> <input type="button" name="next" class="open3 action-button" value="Back" />

                            </fieldset>
                            <fieldset id="form4">
                                <div class="form-card">
                                    <div class="row justify-content-center">
                                        <div class="col-3"> <img src="{{ asset('assets/images/icon/success.svg') }}"
                                                class="fit-image" alt="Desktop Repair service Dubai"
                                                title="Desktop Repair service Dubai"> </div><br>
                                        <h2 class="purple-text text-center"><strong>SUCCESS !</strong></h2>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-7 text-center order_no">
                                            <h5 class="purple-text1 text-center">Succefully placed your
                                                order.<strong>Order No:
                                                </strong></h5>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                    <div class="col-md-3">

                        <div id="owl-demo" class="owl-carousel owl-theme">

                            <div class="item"> <a href="https://fttuae.com/services/security-solution"
                                    target="_blank"><img class="img-fluid"
                                        src="{{secure_image_url('assets/images/adz3.jpg',['source'=>'public','format' => 'jpg','grayscale' => false])}}" /></a>
                            </div>
                            <div class="item"> <a href="https://fttuae.com/services/security-solution"
                                    target="_blank"><img class="img-fluid"
                                        src="{{secure_image_url('assets/images/cctv-adz2.jpg',['source'=>'public','format' => 'jpg','grayscale' => false])}}" /></a>
                            </div>
                            <div class="item"> <a href="https://fttuae.com/services/security-solution"
                                    target="_blank"><img class="img-fluid"
                                        src="{{secure_image_url('assets/images/cctv-adz.jpg',['source'=>'public','format' => 'jpg','grayscale' => false])}}" /></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row para-text ">
                    {!! $category->description ?? '' !!}
                    {!! $brand->description ?? '' !!}
                </div>
                @if(isset($widget) && $widget)
                <div class="row para-text ">
                    {!! $widget->description ?? '' !!}
                </div>
                @endif

            </div>
        </div>
    </div>
</div>
@if(count($faqs) > 0)
<div class="container mt-5">
    <h2>Frequently Asked Questions</h2>
    <div class="faq--wrapper" id="faqAccordion">
        <div class="faq--area mb-5">
            @foreach($faqs as $faq)
            <div class="faq--item ">
                <div class="faq-title" id="heading0">
                    <h5 class="title bold">
                        {{ $faq->question }}
                        <span class="icon"></span>
                    </h5>
                </div>
                <div class="faq-content pt-2" style="display: none;">
                    {{ $faq->answer }}
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endif
@stop
@section('scripts')
@if($faqs->isNotEmpty())
<script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
        @foreach($faqs as $index => $faq)
        {
        "@type": "Question",
        "name": {!! json_encode($faq->question) !!},
        "acceptedAnswer": {
            "@type": "Answer",
            "text": {!! json_encode($faq->answer) !!}
        }
        }@if(!$loop->last),@endif
        @endforeach
    ]
    }
</script>
@endif
<script>
    // --- Variable Declarations ---
const allBrands = {!! json_encode($brands->map(function($brand) {
    return [
        'id' => $brand->id,
        'slug' => $brand->slug,
        'name' => $brand->name,
        'categories' => $brand->categories->map(function($cat) {
            return ['id' => $cat->id];
        }),
    ];
})) !!};

$(function () {
    // --- Cache selectors to minimize DOM lookups ---
    const $categorySelect = $('#category_id');
    const $brandSelect = $('#brand_id');

    // --- Initialize dropdowns ---
    $('select').niceSelect();

    // --- Populate brands based on selected category ---
    $categorySelect.on('change', function () {
        const categoryId = $(this).val();
        $brandSelect.empty().append('<option disabled selected value="">Select Brand</option>');
        const filteredBrands = allBrands.filter(brand =>
            brand.categories.some(cat => cat.id == categoryId)
        );
        filteredBrands.forEach(brand => {
            $brandSelect.append(`<option value="${brand.id}" data-slug="${brand.slug}">${brand.name}</option>`);
        });
        $brandSelect.prop('disabled', filteredBrands.length === 0);
        $brandSelect.niceSelect('update');
    });

    // --- Pre-fill brand dropdown if slugs are passed ---
    const categorySlug = "{{ $categorySlug ?? '' }}";
    const brandSlug = "{{ $brandSlug ?? '' }}";
    if (categorySlug) {
        const selectedCategoryId = $categorySelect.find('option:selected').val();
        $brandSelect.empty().append('<option disabled selected value="">Select Brand</option>');
        const filteredBrands = allBrands.filter(brand =>
            brand.categories.some(cat => cat.id == selectedCategoryId)
        );
        filteredBrands.forEach(brand => {
            const selected = (brand.slug === brandSlug) ? 'selected' : '';
            $brandSelect.append(`<option value="${brand.id}" data-slug="${brand.slug}" ${selected}>${brand.name}</option>`);
        });
        $brandSelect.prop('disabled', filteredBrands.length === 0);
        $brandSelect.niceSelect('update');
    }

    // --- Tab navigation handlers ---
    // Next to form2
    $('.open2').click(function () {
        // Validate the form
        var validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            $.each(validationErrors, function (fieldName, errorMessage) {
                $('#error-' + fieldName).text('* ' + errorMessage);
            });
            return;
        }
        $('#form1').hide();
        $('.para-text').hide();
        $("#account").addClass("active");
        $("#personal").removeClass("active");
        $("#form2").show("slow");
    });

    // Back to form1 from form2
    $('.back1').click(function () {
        $('#form2').hide();
        $('.change-product-bar').hide();
        $("#personal").addClass("active");
        $("#account").removeClass("active");
        $("#form1").show("slow");
        $('.para-text').show();
    });

    // Next to form3 and submit second step form via AJAX
    $('.open1').click(function () {
        var validationErrors = validateForm2();
        if (Object.keys(validationErrors).length > 0) {
            $.each(validationErrors, function (fieldName, errorMessage) {
                $('#error-' + fieldName).text('* ' + errorMessage);
            });
            return;
        }
        $('.para-text').hide();
        $('#form2').hide();
        $("#confirm").addClass("active");
        $("#account").removeClass("active");
        $("#form3").show("slow");
        // Submit second step form via AJAX
        $.ajax({
            url: '{{ route("home.enquiry.store") }}',
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: $("#msform").serialize(),
            dataType: "json",
            success: function (response) {
                $('#quote_id').text('Your Enquiry id: ' + response.data)
            }
        });
    });

    // Back to form2 from form3
    $('.open3').click(function () {
        $('#form3').hide();
        $('.para-text').hide();
        $('.change-product-bar').hide();
        $("#account").addClass("active");
        $("#confirm").removeClass("active");
        $("#form2").show("slow");
    });
});

// --- Form validation functions ---
// Validate first form
function validateForm() {
    $(".error-message").text("");
    var validationErrors = {};
    var field1Value = $('#category_id').val();
    if (field1Value == '' || field1Value == null) {
        validationErrors.field1 = "Category is required.";
    }
    var field2Value = $('#brand_id').val();
    if (field2Value === '' || field2Value == null) {
        validationErrors.field2 = "Brand is required.";
    }
    return validationErrors;
}

// Validate second form
function validateForm2() {
    $(".error-message").text("");
    var validationErrors = {};
    var field1Value = $('#first_name').val();
    if (field1Value == '' || field1Value == null) {
        validationErrors.field11 = "First Name is required.";
    }
    var field2Value = $('#last_name').val();
    if (field2Value === '' || field2Value == null) {
        validationErrors.field12 = "Last Name is required.";
    }
    var field3Value = $('#mobile').val();
    if (field3Value === '' || field3Value == null) {
        validationErrors.field22 = "Phone Number is required.";
    }
    var field4Value = $('#email').val();
    if (field4Value === '' || field4Value == null) {
        validationErrors.field33 = "Email is required.";
    }
    return validationErrors;
}

// --- Carousel initialization ---
$(document).ready(function() {
    $("#owl-demo").owlCarousel({
        navigation: true,
        items: 1,
        autoplay: true,
        loop: true,
        nav: false,
        dots: false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn'
    });
});
</script>
@endsection
